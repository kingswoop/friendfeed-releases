-- The feed, pop-up toasts and the friend history window.
local _, ns = ...

local UI = {}
ns.UI = UI

-- Four looks for the feed (settings.feedStyle):
--   comfortable  "Cards": two lines, where it came from underneath, colour tints
--   compact      one-liners
--   chat         no box or border, rows sit on the world like chat text, older rows fade
--   timeline     grouped under Today / Yesterday / ... with a rail and a marker per row
local STYLES = {
  comfortable = { row = 42, icon = 30, maxRows = 20, lines = 2, box = true },
  compact     = { row = 24, icon = 18, maxRows = 30, lines = 1, box = true },
  chat        = { row = 44, icon = 26, maxRows = 20, lines = 2, box = false, fade = true },
  timeline    = { row = 40, icon = 24, maxRows = 22, lines = 2, box = true, headers = true, rail = true },
}
UI.STYLE_ORDER = { "comfortable", "compact", "chat", "timeline" }
UI.STYLE_LABELS = { comfortable = "Cards", compact = "Compact", chat = "Chat", timeline = "Timeline" }
local FEED_W, FEED_ROWS = 380, 6             -- default size (wide enough for first + last names)
local FEED_HEAD, FEED_FOOT = 34, 10          -- space above and below the rows (the grip sits in the footer)
local FEED_MIN_W, FEED_MAX_W = 340, 700 -- 340 fits the whole filter bar
local FEED_MIN_ROWS = 3
-- what an empty feed says: most players start here, and only friends and
-- guildmates who also have Friend Feed ever show up, so say so plainly
local EMPTY_TEXT = "No friend activity yet.\n"
  .. "|cffffb040Only friends and guildmates who also have Friend Feed show up here.|r\n"
  .. "Type |cffffd200/ff ping|r to find them, or |cffffd200/ff demo|r for a preview."
UI.EMPTY_TEXT = EMPTY_TEXT
-- A row counts once the feed is within this many units of fitting it. When you
-- let go of the grip the game rounds the frame to whole screen pixels, which can
-- land a hair under the line and drop the row you just dragged in (seen on 0.8.3).
local ROW_SLACK = 2
local DIM_AFTER, DIM_ALPHA = 120, 0.45       -- fade the feed after this many quiet seconds, to this alpha
local DETAIL_W, DETAIL_H = 640, 470
local LIST_W, LIST_ROW_H = 180, 22
local TOAST_W = 320
local T_IN, T_HOLD, T_OUT = 0.35, 4.5, 0.6

local function style()
  local s = ns.db and ns.db.settings and ns.db.settings.feedStyle
  return STYLES[s] or STYLES.comfortable
end
-- the history window only knows boxed rows: compact stays compact, the rest are cards
local function detailsStyle()
  return style() == STYLES.compact and STYLES.compact or STYLES.comfortable
end
function UI:RowHeight() return style().row end
-- The filter bar (small toggles for kinds and qualities) sits under the header
local FILTER_H = 22
local function filterBarOn()
  local s = ns.db and ns.db.settings
  return not (s and s.filterBar == false)
end
-- space above the rows: the header, plus the filter bar when it's on
local function headH() return FEED_HEAD + (filterBarOn() and FILTER_H or 0) end
local function feedHeight(rows) return headH() + rows * style().row + FEED_FOOT end

local BACKDROP = {
  bgFile = "Interface\\Buttons\\WHITE8x8",
  edgeFile = "Interface\\Buttons\\WHITE8x8",
  edgeSize = 1,
}

local function skin(frame, alpha)
  frame:SetBackdrop(BACKDROP)
  frame:SetBackdropColor(0.03, 0.03, 0.05, alpha or 0.8)
  frame:SetBackdropBorderColor(0.45, 0.36, 0.2, 0.85)
end

local function qualityRGB(q)
  if q and C_Item and C_Item.GetItemQualityColor then
    local r, g, b = C_Item.GetItemQualityColor(q)
    if r then return r, g, b end
  end
  return 1, 0.82, 0
end

-- the colour a milestone glows in: item quality for loot, otherwise its kind
local KIND_RGB = {
  level = { 1, 0.82, 0 }, ach = { 1, 0.9, 0.35 }, mount = { 0.64, 0.21, 0.93 },
  pet = { 0.12, 1, 0 }, toy = { 0, 0.44, 0.87 }, death = { 1, 0.32, 0.32 },
  kill = { 1, 0.5, 0.15 },
}
local function accentRGB(kind, q)
  if kind ~= "loot" and KIND_RGB[kind] then
    local c = KIND_RGB[kind]
    return c[1], c[2], c[3]
  end
  return qualityRGB(q)
end

-- a horizontal fade from a colour to nothing (older clients: a flat tint)
local function setGradient(tex, r, g, b, a)
  if CreateColor and tex.SetGradient then
    local ok = pcall(tex.SetGradient, tex, "HORIZONTAL", CreateColor(r, g, b, a), CreateColor(r, g, b, 0))
    if ok then return end
  end
  tex:SetColorTexture(r, g, b, a * 0.5)
end

local function gold(s) return "|cffffd200" .. tostring(s) .. "|r" end

-- chat-style rows have no box behind them, so their text gets a shadow
local function shadow(fs, on)
  pcall(fs.SetShadowColor, fs, 0, 0, 0, on and 1 or 0)
  pcall(fs.SetShadowOffset, fs, on and 1 or 0, on and -1 or 0)
end

-- A slightly bigger grey font for the "where from" line, made once. Falls back
-- to the game's small grey font if fonts can't be created here.
local SUB_FONT = "GameFontDisableSmall"
do
  local ok = pcall(function()
    local f = CreateFont("FriendFeedSubFont")
    f:CopyFontObject(GameFontHighlightSmall)
    local path, _, flags = f:GetFont()
    if path then f:SetFont(path, 11, flags or "") end
    f:SetTextColor(0.66, 0.66, 0.66)
    SUB_FONT = "FriendFeedSubFont"
  end)
  if not ok then SUB_FONT = "GameFontDisableSmall" end
end

-- Anchor a frame by its top-left corner where it is now (UIParent's bottom-left
-- as the origin) and return that point. After a move WoW anchors a frame by
-- whichever corner or edge is nearest (bottom-right, centre...), and sizing
-- from the bottom-right grip or snapping the height to whole rows then moves
-- the frame across the screen. Pinned by its top-left, only the bottom-right moves.
local function pinTopLeft(frame)
  local left, top = frame:GetLeft(), frame:GetTop()
  if type(left) ~= "number" or type(top) ~= "number" then return nil end
  left, top = math.floor(left + 0.5), math.floor(top + 0.5)
  frame:ClearAllPoints()
  frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
  return { "TOPLEFT", "BOTTOMLEFT", left, top }
end
UI.PinTopLeft = pinTopLeft

-- Remember where a frame is (settings[saveKey]), as its top-left corner
local function savePosition(frame, saveKey)
  local pt = pinTopLeft(frame)
  if not pt then
    local p, _, rp, x, y = frame:GetPoint()
    if p then pt = { p, rp, x, y } end
  end
  if pt then ns.db.settings[saveKey] = pt end
end

local function makeDraggable(frame, saveKey)
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:SetClampedToScreen(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self)
    if self.sizing == true then return end -- the grip is resizing it, don't move it too
    if not (saveKey and ns.db.settings.locked) then self:StartMoving() end
  end)
  frame:SetScript("OnDragStop", function(self)
    if self.sizing == true then return end
    self:StopMovingOrSizing()
    if saveKey then savePosition(self, saveKey) end
  end)
end

---------------------------------------------------------------------------
-- Days, for the timeline look's "Today / Yesterday" headers
---------------------------------------------------------------------------
local function dayOf(t)
  local ok, d = pcall(date, "*t", t)
  if ok and type(d) == "table" and d.year and d.yday then return d.year * 1000 + d.yday end
  return math.floor((t or 0) / 86400)
end

local function dayLabel(t, now)
  local d = dayOf(t)
  if d == dayOf(now) then return "Today" end
  if d == dayOf(now - 86400) then return "Yesterday" end
  local ok, s = pcall(date, "%a %d %b", t)
  if ok and type(s) == "string" and s ~= "" then return s end
  return "Earlier"
end

-- The first of these game functions the client has ("Table.func" or "global")
local function chatFn(...)
  for i = 1, select("#", ...) do
    local path = select(i, ...)
    local t, k = path:match("^([%w_]+)%.([%w_]+)$")
    local fn
    if t then fn = type(_G[t]) == "table" and _G[t][k] or nil else fn = _G[path] end
    if type(fn) == "function" then return fn end
  end
  return nil
end

local function itemLink(id)
  if not (id and id > 0 and C_Item and C_Item.GetItemInfo) then return nil end
  local _, link = C_Item.GetItemInfo(id)
  return ns.Usable(link) and link or nil
end

---------------------------------------------------------------------------
-- Rows (shared by the feed and the history window)
---------------------------------------------------------------------------
local function Row_OnEnter(self)
  UI:Touch()
  local ev = self.ev
  if not ev then return end
  -- hovering a milestone in the feed counts as seeing it (its yellow dot goes,
  -- and the history window fades it)
  if self.inFeed == true and ns:MarkViewed(ev) then UI:RequestRefresh() end
  GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
  local shown = false
  if ev.k == "loot" and ev.v > 0 then
    shown = pcall(GameTooltip.SetItemByID, GameTooltip, ev.v)
  end
  local _, desc, _, sub = ns:Describe(ev)
  if not shown then
    GameTooltip:SetText(ns.Label(ev, true) .. " " .. desc, 1, 1, 1, 1, true)
  end
  if sub then GameTooltip:AddLine(sub, 0.75, 0.75, 0.75, true) end
  -- how rare it is among the people you know
  local others, first = ns:HowMany(ev)
  if others then
    if others == 0 then
      GameTooltip:AddLine("Nobody else you know has this yet", 1, 0.5, 0)
    elseif first then
      GameTooltip:AddLine("First to get it. " .. others .. " other" .. (others == 1 and " has" or "s have") .. " it now", 1, 0.82, 0)
    else
      GameTooltip:AddLine(others .. " other" .. (others == 1 and " person you know has" or " people you know have") .. " this too", 0.7, 0.7, 0.7)
    end
  end
  GameTooltip:AddLine(" ")
  GameTooltip:AddLine(ns.Label(ev) .. "  -  " .. date("%a %d %b, %I:%M %p", ev.t), 0.7, 0.7, 0.7)
  GameTooltip:AddLine("Click: " .. ev.who .. "'s history", 0.5, 0.8, 1)
  if UI:PreviewKind(ev) then GameTooltip:AddLine("Ctrl+click: see it on your character", 0.5, 0.8, 1) end
  if UI:ChatLink(ev) then GameTooltip:AddLine("Shift+click: link it in chat", 0.5, 0.8, 1) end
  GameTooltip:Show()
end

---------------------------------------------------------------------------
-- Seeing it on your character: gear in the dressing room (what Ctrl+click
-- does on any item in the game), mounts and battle pets in its model view.
---------------------------------------------------------------------------
local LOOK_ICON = "Interface\\Common\\UI-Searchbox-Icon"

local function modified(kind)
  if IsModifiedClick then
    local ok, yes = pcall(IsModifiedClick, kind)
    if ok then return yes and true or false end
  end
  if kind == "DRESSUP" then return IsControlKeyDown and IsControlKeyDown() or false end
  if kind == "CHATLINK" then return IsShiftKeyDown and IsShiftKeyDown() or false end
  return false
end

-- "item", "mount" or "pet" when this milestone can be previewed, else nil
function UI:PreviewKind(ev)
  if not ev then return nil end
  local v = tonumber(ev.v) or 0
  if v <= 0 then return nil end
  if ev.k == "mount" then return "mount" end
  if ev.k == "pet" then return "pet" end
  if ev.k ~= "loot" and ev.k ~= "toy" then return nil end
  if C_Item and C_Item.IsDressableItemByID then
    local ok, yes = pcall(C_Item.IsDressableItemByID, v)
    if ok and yes then return "item" end
  end
  -- items that teach a mount or a pet show that instead
  if C_MountJournal and C_MountJournal.GetMountFromItem then
    local ok, m = pcall(C_MountJournal.GetMountFromItem, v)
    if ok and m then return "item" end
  end
  if C_PetJournal and C_PetJournal.GetPetInfoByItemID then
    local ok, p = pcall(C_PetJournal.GetPetInfoByItemID, v)
    if ok and p then return "item" end
  end
  return nil
end

-- Open the preview. Returns true if the game showed something.
function UI:Preview(ev)
  local kind = self:PreviewKind(ev)
  if not kind then return false end
  local v = tonumber(ev.v)
  if kind == "mount" then
    local fn = chatFn("DressUpMount")
    if fn then return (pcall(fn, v)) end
  elseif kind == "pet" then
    local fn = chatFn("DressUpBattlePet")
    if fn and C_PetJournal and C_PetJournal.GetPetInfoBySpeciesID then
      local ok, _, _, _, creatureID, _, _, _, _, _, _, _, displayID = pcall(C_PetJournal.GetPetInfoBySpeciesID, v)
      if ok and creatureID then return (pcall(fn, creatureID, displayID, v)) end
    end
  else
    local link = itemLink(v) or ("item:" .. v)
    local fn = chatFn("DressUpLink", "DressUpItemLink")
    if fn then return (pcall(fn, link)) end
  end
  return false
end

-- A chat link for the milestone (gear, toys, achievements), or nil
function UI:ChatLink(ev)
  if not ev then return nil end
  local v = tonumber(ev.v) or 0
  if v <= 0 then return nil end
  if ev.k == "loot" or ev.k == "toy" then return itemLink(v) end
  if ev.k == "ach" and GetAchievementLink then
    local ok, link = pcall(GetAchievementLink, v)
    if ok and ns.Usable(link) then return link end
  end
  return nil
end

-- Click on a row: Ctrl previews, Shift links it in chat, otherwise the friend's history
function UI:RowClicked(ev)
  if not ev then return end
  if modified("DRESSUP") and self:Preview(ev) then return "preview" end
  if modified("CHATLINK") then
    local link = self:ChatLink(ev)
    local insert = link and chatFn("ChatFrameUtil.InsertLink", "ChatEdit_InsertLink")
    if insert and pcall(insert, link) then return "link" end
  end
  self:OpenDetails((not ev.self) and ev.id or nil) -- history lists friends only
  return "history"
end

---------------------------------------------------------------------------
-- Messaging a friend about a milestone: the speech bubble on each row opens
-- a whisper (a Battle.net whisper for Battle.net friends, which also works
-- across rulesets) with a short starter and the item or achievement linked.
-- Nothing is sent: the player edits it and presses Enter.
---------------------------------------------------------------------------
local MSG_ICON = "Interface\\GossipFrame\\GossipGossipIcon"

-- "Gz on [Thunderfury]!" and the like, with a real link where the game has one
-- link: an item link already in hand (from WhisperTextAsync once the item loaded)
function UI:WhisperText(ev, link)
  local k, v = ev.k, tonumber(ev.v) or 0
  local plain = ev.n and ("[" .. ev.n .. "]") or nil
  if k == "loot" or k == "toy" then
    return "Gz on " .. ((ns.Usable(link) and link) or itemLink(v) or plain or "that") .. "!"
  elseif k == "ach" then
    local ok, alink = false, nil
    if GetAchievementLink and v > 0 then ok, alink = pcall(GetAchievementLink, v) end
    return "Gz on " .. ((ok and ns.Usable(alink)) and alink or plain or "the achievement") .. "!"
  elseif k == "level" then
    return "Gz on level " .. v .. "!"
  elseif k == "mount" then
    local name, spellID = ev.n, nil
    if v > 0 and C_MountJournal and C_MountJournal.GetMountInfoByID then
      local ok, n, sid = pcall(C_MountJournal.GetMountInfoByID, v)
      if ok and ns.Usable(n) then name = n end
      if ok then spellID = tonumber(sid) end
    end
    -- the mount's spell as a link, like the mount journal's Shift+click
    if spellID and spellID > 0 then
      local fn = chatFn("C_Spell.GetSpellLink", "GetSpellLink")
      local ok, slink = false, nil
      if fn then ok, slink = pcall(fn, spellID) end
      if ok and ns.Usable(slink) then return "Gz on " .. slink .. "!" end
    end
    return name and ("Gz on the " .. name .. "!") or "Gz on the new mount!"
  elseif k == "pet" then
    return ev.n and ("Gz on the " .. ev.n .. "!") or "Gz on the new pet!"
  elseif k == "death" then
    return v > 0 and ("Oof, RIP at level " .. v .. ".") or "Oof, RIP."
  elseif k == "kill" then
    return v > 1 and ("Nice, " .. v .. " kills!") or "Nice kill!"
  end
  return ""
end

-- The game only makes an item link for items it has loaded, and a friend's
-- new sword usually isn't (you've never seen one). Ask for it and hand fn
-- the starter once it arrives, so the whisper gets a real, clickable link
-- instead of "[Sword]" as plain text. Gives up waiting after 2 seconds.
local ITEM_WAIT = 2
function UI:WhisperTextAsync(ev, fn)
  local v = tonumber(ev.v) or 0
  if (ev.k == "loot" or ev.k == "toy") and v > 0 and not itemLink(v) and Item and Item.CreateFromItemID then
    local ok, item = pcall(Item.CreateFromItemID, Item, v)
    if ok and type(item) == "table" and item.ContinueOnItemLoad then
      local done = false
      local function finish()
        if done then return end
        done = true
        local lok, link = false, nil
        if item.GetItemLink then lok, link = pcall(item.GetItemLink, item) end
        fn(self:WhisperText(ev, lok and link or nil))
      end
      pcall(item.ContinueOnItemLoad, item, finish)
      if not done then C_Timer.After(ITEM_WAIT, finish) end
      return
    end
  end
  fn(self:WhisperText(ev))
end

-- A Battle.net friend's account name (what Battle.net whispers need), by BattleTag
function UI:BnAccountFor(id)
  if type(id) ~= "string" or not id:find("#", 1, true) or id:find(":", 1, true) then return nil end
  if not (BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo) then return nil end
  for i = 1, (BNGetNumFriends()) do
    local acc = C_BattleNet.GetFriendAccountInfo(i)
    if acc and acc.battleTag == id and acc.accountName then return acc.accountName end
  end
  return nil
end

-- The chat box the whisper just opened. Clients name the helpers differently
-- (12.x moved many ChatEdit_ functions to ChatFrameUtil), so try them all,
-- then the globals the chat code keeps, then the first chat window's own box.
local function isBox(eb) return type(eb) == "table" and type(eb.Insert) == "function" end
local function boxShown(eb)
  if not isBox(eb) then return false end
  if type(eb.IsShown) ~= "function" then return true end
  local ok, shown = pcall(eb.IsShown, eb)
  return ok and shown and true or false
end
function UI:ChatBox()
  local active = chatFn("ChatFrameUtil.GetActiveWindow", "ChatEdit_GetActiveWindow")
  if active then
    local ok, eb = pcall(active)
    if ok and isBox(eb) then return eb end
  end
  if boxShown(ACTIVE_CHAT_EDIT_BOX) then return ACTIVE_CHAT_EDIT_BOX end
  local choose = chatFn("ChatFrameUtil.ChooseBoxForSend", "ChatEdit_ChooseBoxForSend")
  if choose then
    local ok, eb = pcall(choose)
    if ok and boxShown(eb) then return eb end
  end
  if boxShown(LAST_ACTIVE_CHAT_EDIT_BOX) then return LAST_ACTIVE_CHAT_EDIT_BOX end
  local first = DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.editBox
  if boxShown(first) then return first end
  if boxShown(ChatFrame1EditBox) then return ChatFrame1EditBox end
  return nil
end

-- Put text in the chat box that's open (the whisper just opened), and check it
-- went in. The box can take a moment to open, so a few more tries shortly after.
local INSERT_TRIES = 4
local function insertInChat(text, tries)
  if text == "" then return true end
  tries = tries or 1
  -- the game's own "put this in the open chat box" (what Shift+click on a row
  -- uses, which works in game); it returns true once it went in
  local insert = chatFn("ChatFrameUtil.InsertLink", "ChatEdit_InsertLink")
  if insert then
    local ok, done = pcall(insert, text)
    if ok and done then return true end
  end
  local eb = UI:ChatBox()
  if eb then
    pcall(eb.Insert, eb, text)
    -- some boxes ignore Insert while they're still opening: set it directly
    if type(eb.GetText) == "function" and type(eb.SetText) == "function" then
      local ok, cur = pcall(eb.GetText, eb)
      if ok and type(cur) == "string" and not cur:find(text, 1, true) then
        pcall(eb.SetText, eb, cur .. text)
      end
    end
    return true
  end
  if tries < INSERT_TRIES then
    C_Timer.After(0.1, function() insertInChat(text, tries + 1) end)
  else
    ns.Print("couldn't put the message in the chat box. Type it in the whisper that opened.")
  end
  return false
end

function UI:MessageAbout(ev)
  if not ev or ev.self then return false end
  local opened = false
  local acc = self:BnAccountFor(ev.id)
  if acc then
    local tell = chatFn("ChatFrameUtil.SendBNetTell", "ChatFrame_SendBNetTell")
    if tell then opened = pcall(tell, acc) end
  end
  if not opened and ns.Usable(ev.who) then
    local tell = chatFn("ChatFrameUtil.SendTell", "ChatFrame_SendTell")
    if tell then opened = pcall(tell, ev.who) end
  end
  if not opened then
    -- last resort: a /w line in the chat box
    local open = chatFn("ChatFrameUtil.OpenChat", "ChatFrame_OpenChat")
    if not (open and ns.Usable(ev.who)) then return false end
    self:WhisperTextAsync(ev, function(text) pcall(open, "/w " .. ev.who .. " " .. text) end)
    return true
  end
  -- the starter, with the item, mount or achievement linked, once its link is ready
  self:WhisperTextAsync(ev, function(text) insertInChat(text) end)
  return true
end

local function MsgButton_OnEnter(self)
  self:SetAlpha(1)
  UI:Touch()
  local ev = self.row.ev
  if not ev then return end
  local name = ns.NameParts(ev)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  GameTooltip:SetText("Message " .. tostring(name))
  GameTooltip:AddLine("Opens a whisper with this linked, ready for you to send.", 1, 1, 1, true)
  GameTooltip:Show()
end

---------------------------------------------------------------------------
-- The heart on each row
---------------------------------------------------------------------------
-- the heart from the pet battle stat icons (health); unverified in game
local LIKE_ICON = "Interface\\PetBattles\\PetBattle-StatIcons"
local LIKE_COORDS = { 0.5, 1, 0.5, 1 }
local LIKE_SIZE = 12
local LIKE_RGB = { 1, 0.35, 0.45 }

-- show the heart and count for the row's milestone: friends' milestones
-- always have a heart to click; yours show one only once someone liked it
function UI:PaintLike(row)
  local b, ev = row.like, row.ev
  if not (b and ev) then return end
  local n, liked = ns:LikeCount(ev), ns:Liked(ev)
  if ev.self and n == 0 then b:Hide(); return end
  b.count:SetText(n > 0 and tostring(n) or "")
  b:SetWidth(n > 0 and (LIKE_SIZE + 4 + 6 * #tostring(n)) or LIKE_SIZE)
  local lit = liked or (ev.self and n > 0)
  pcall(b.tex.SetDesaturated, b.tex, not lit)
  if lit then
    b.tex:SetVertexColor(LIKE_RGB[1], LIKE_RGB[2], LIKE_RGB[3])
    b.count:SetTextColor(LIKE_RGB[1], LIKE_RGB[2], LIKE_RGB[3])
  else
    b.tex:SetVertexColor(1, 1, 1)
    b.count:SetTextColor(0.75, 0.75, 0.75)
  end
  b:SetAlpha((lit or n > 0) and 1 or 0.5)
  b:Show()
end

local function LikeButton_OnEnter(self)
  UI:Touch()
  local ev = self.row.ev
  if not ev then return end
  self:SetAlpha(1)
  local n = ns:LikeCount(ev)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  if ev.self then
    GameTooltip:SetText(n .. (n == 1 and " person likes" or " people like") .. " this")
    local by = ns:LikedBy(ev)
    for i = 1, math.min(#by, 10) do GameTooltip:AddLine(by[i].n, 1, 1, 1) end
    if #by > 10 then GameTooltip:AddLine("and " .. (#by - 10) .. " more", 0.7, 0.7, 0.7) end
  else
    local liked = ns:Liked(ev)
    GameTooltip:SetText(liked and "You like this" or "Like")
    if n > 0 then
      local others = liked and (n - 1) or n
      if others > 0 then
        GameTooltip:AddLine(others .. (others == 1 and " other person likes" or " other people like") .. " it too", 1, 1, 1)
      end
    end
    GameTooltip:AddLine(liked and "Click to take your like back." or ("Click to let " .. tostring(ns.NameParts(ev)) .. " know you like it."), 0.5, 0.8, 1, true)
  end
  GameTooltip:Show()
end

local function Row_OnLeave(self)
  GameTooltip_Hide()
  -- chat look: older rows fade again once the mouse has left the feed
  C_Timer.After(0.3, function() UI:CheckHover() end)
end

local function CreateRow(parent, st)
  local row = CreateFrame("Button", nil, parent)

  -- soft tint in the milestone's colour, fading out to the right
  row.bg = row:CreateTexture(nil, "BACKGROUND")
  row.bg:SetPoint("TOPLEFT", 0, -1)
  row.bg:SetPoint("BOTTOMRIGHT", 0, 1)
  row.bg:SetColorTexture(1, 1, 1, 1) -- a gradient needs something to shade

  -- bright flash when a milestone lands in the feed
  row.flash = row:CreateTexture(nil, "BACKGROUND", nil, 1)
  row.flash:SetAllPoints()
  row.flash:SetAlpha(0)
  local ag = row.flash:CreateAnimationGroup()
  local a = ag:CreateAnimation("Alpha")
  a:SetFromAlpha(1); a:SetToAlpha(0); a:SetDuration(1.8); a:SetSmoothing("OUT")
  row.flashAnim = ag

  -- thin bar on the left in the milestone's colour
  row.accent = row:CreateTexture(nil, "ARTWORK")
  row.accent:SetWidth(3)
  row.accent:SetPoint("TOPLEFT", 0, -3)
  row.accent:SetPoint("BOTTOMLEFT", 0, 3)

  -- timeline look: a rail down the left with a diamond per row
  row.rail = row:CreateTexture(nil, "ARTWORK")
  row.rail:SetWidth(2)
  row.rail:SetPoint("TOP", row, "TOPLEFT", 16, 0)
  row.rail:SetPoint("BOTTOM", row, "BOTTOMLEFT", 16, 0)
  row.rail:SetColorTexture(1, 1, 1, 0.08)
  row.diamond = row:CreateTexture(nil, "OVERLAY")
  row.diamond:SetSize(7, 7)
  row.diamond:SetPoint("CENTER", row, "LEFT", 16, 0)
  row.diamond:SetColorTexture(1, 1, 1, 1)
  pcall(row.diamond.SetRotation, row.diamond, math.rad(45))

  row.iconBorder = row:CreateTexture(nil, "BORDER")
  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  row.iconBorder:SetPoint("TOPLEFT", row.icon, -1, 1)
  row.iconBorder:SetPoint("BOTTOMRIGHT", row.icon, 1, -1)

  row.time = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")

  -- heart: like it, and how many people did (everyone sees the same count)
  row.like = CreateFrame("Button", nil, row)
  row.like:SetSize(LIKE_SIZE, LIKE_SIZE)
  row.like:SetPoint("RIGHT", row.time, "LEFT", -4, 0)
  row.like.row = row
  row.like.tex = row.like:CreateTexture(nil, "ARTWORK")
  row.like.tex:SetSize(LIKE_SIZE, LIKE_SIZE)
  row.like.tex:SetPoint("LEFT")
  row.like.tex:SetTexture(LIKE_ICON)
  row.like.tex:SetTexCoord(LIKE_COORDS[1], LIKE_COORDS[2], LIKE_COORDS[3], LIKE_COORDS[4])
  row.like.count = row.like:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  row.like.count:SetPoint("LEFT", row.like.tex, "RIGHT", 2, 0)
  row.like.count:SetJustifyH("LEFT")
  row.like:SetScript("OnEnter", LikeButton_OnEnter)
  row.like:SetScript("OnLeave", function(self) UI:PaintLike(self.row); GameTooltip_Hide() end)
  row.like:SetScript("OnClick", function(self)
    local ev = self.row.ev
    if ev and not ev.self then
      ns:ToggleLike(ev)
      UI:PaintLike(self.row)
      LikeButton_OnEnter(self)
    end
  end)

  -- speech bubble: whisper this player about it, with the milestone linked
  row.msg = CreateFrame("Button", nil, row)
  row.msg:SetSize(14, 14)
  row.msg:SetPoint("RIGHT", row.like, "LEFT", -3, 0)
  row.msg.row = row
  row.msg.tex = row.msg:CreateTexture(nil, "ARTWORK")
  row.msg.tex:SetAllPoints()
  row.msg.tex:SetTexture(MSG_ICON)
  local mhl = row.msg:CreateTexture(nil, "HIGHLIGHT")
  mhl:SetAllPoints()
  mhl:SetTexture(MSG_ICON)
  pcall(mhl.SetBlendMode, mhl, "ADD")
  row.msg:SetAlpha(0.55)
  row.msg:SetScript("OnEnter", MsgButton_OnEnter)
  row.msg:SetScript("OnLeave", function(self) self:SetAlpha(0.55); GameTooltip_Hide() end)
  row.msg:SetScript("OnClick", function(self) if self.row.ev then UI:MessageAbout(self.row.ev) end end)

  -- magnifier: see it on your character (gear, mounts, pets), like Ctrl+click
  row.look = CreateFrame("Button", nil, row)
  row.look:SetSize(13, 13)
  row.look:SetPoint("RIGHT", row.msg, "LEFT", -3, 0)
  row.look.row = row
  row.look.tex = row.look:CreateTexture(nil, "ARTWORK")
  row.look.tex:SetAllPoints()
  row.look.tex:SetTexture(LOOK_ICON)
  local lhl = row.look:CreateTexture(nil, "HIGHLIGHT")
  lhl:SetAllPoints()
  lhl:SetTexture(LOOK_ICON)
  pcall(lhl.SetBlendMode, lhl, "ADD")
  row.look:SetAlpha(0.55)
  row.look:SetScript("OnEnter", function(self)
    self:SetAlpha(1)
    UI:Touch()
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("See it on your character")
    GameTooltip:AddLine("Opens the dressing room, the same as Ctrl+click.", 1, 1, 1, true)
    GameTooltip:Show()
  end)
  row.look:SetScript("OnLeave", function(self) self:SetAlpha(0.55); GameTooltip_Hide() end)
  row.look:SetScript("OnClick", function(self) if self.row.ev then UI:Preview(self.row.ev) end end)

  -- yellow dot: new since you were last on
  row.dot = row:CreateTexture(nil, "OVERLAY")
  row.dot:SetSize(10, 10)
  row.dot:SetTexture("Interface\\COMMON\\Indicator-Yellow")
  row.dot:SetPoint("RIGHT", row.msg, "LEFT", -2, 0)

  row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  row.text:SetJustifyH("LEFT")
  row.text:SetWordWrap(false)

  -- second line: where it came from, and the ruleset on the right
  row.meta = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  row.sub = row:CreateFontString(nil, "OVERLAY", SUB_FONT)
  row.sub:SetJustifyH("LEFT")
  row.sub:SetWordWrap(false)

  -- hairline between rows
  row.line = row:CreateTexture(nil, "ARTWORK")
  row.line:SetHeight(1)
  row.line:SetPoint("BOTTOMLEFT", 8, 0)
  row.line:SetPoint("BOTTOMRIGHT", -8, 0)
  row.line:SetColorTexture(1, 1, 1, 0.05)

  -- timeline look: this row is a day header ("Today")
  row.header = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  row.header:SetPoint("LEFT", 10, 0)
  row.headerLine = row:CreateTexture(nil, "ARTWORK")
  row.headerLine:SetHeight(1)
  row.headerLine:SetPoint("LEFT", row.header, "RIGHT", 8, 0)
  row.headerLine:SetPoint("RIGHT", -10, 0)
  row.headerLine:SetColorTexture(0.79, 0.66, 0.3, 0.35)

  local hl = row:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(1, 1, 1, 0.06)

  -- the icon pops when a pop-up lands on this row
  row.popAnim = row.icon:CreateAnimationGroup()
  local pop = row.popAnim:CreateAnimation("Scale")
  if not pcall(pop.SetScaleFrom, pop, 1.6, 1.6) then pcall(pop.SetFromScale, pop, 1.6, 1.6) end
  if not pcall(pop.SetScaleTo, pop, 1, 1) then pcall(pop.SetToScale, pop, 1, 1) end
  pop:SetDuration(0.35)
  pop:SetSmoothing("OUT")
  pcall(pop.SetOrigin, pop, "CENTER", 0, 0)

  row:SetScript("OnEnter", Row_OnEnter)
  row:SetScript("OnLeave", Row_OnLeave)
  row:SetScript("OnClick", function(self)
    if self.ev then UI:RowClicked(self.ev) end
  end)
  UI:StyleRow(row, st)
  return row
end

-- Size and place a row's parts for a style (called again when it changes)
function UI:StyleRow(row, st)
  st = st or style()
  local compact = st.lines == 1
  row.st = st
  row:SetHeight(st.row)
  row.icon:SetSize(st.icon, st.icon)
  row.icon:ClearAllPoints()
  row.time:ClearAllPoints()
  row.text:ClearAllPoints()
  row.sub:ClearAllPoints()
  row.meta:ClearAllPoints()
  local iconX = st.rail and 28 or (st.box and 9 or 2)
  if compact then
    row.icon:SetPoint("LEFT", 8, 0)
    row.time:SetPoint("RIGHT", -6, 0)
    row.text:SetPoint("LEFT", row.icon, "RIGHT", 7, 0)
    row.text:SetPoint("RIGHT", row.dot, "LEFT", -4, 0)
    row.sub:Hide()
    row.meta:Hide()
  else
    row.icon:SetPoint("LEFT", iconX, 0)
    row.time:SetPoint("TOPRIGHT", -8, -9)
    row.text:SetPoint("TOPLEFT", row.icon, "RIGHT", 9, 11)
    row.text:SetPoint("RIGHT", row.dot, "LEFT", -6, 0)
    row.meta:SetPoint("BOTTOMRIGHT", -8, 7)
    row.sub:SetPoint("TOPLEFT", row.text, "BOTTOMLEFT", 0, -3)
    row.sub:SetPoint("RIGHT", row.meta, "LEFT", -6, 0)
    row.sub:Show()
    row.meta:Show()
  end
  for _, fs in ipairs({ row.text, row.sub, row.meta, row.time }) do shadow(fs, not st.box) end
  row.compact = compact
end

-- Fill a row with an event, or a day header ({ header = "Today" })
local function SetRow(row, item, showName)
  local st = row.st or style()
  if not item then row.ev = nil; row:Hide(); return end
  if item.header then
    row.ev = nil
    for _, part in ipairs({ row.bg, row.accent, row.iconBorder, row.icon, row.time, row.dot, row.msg, row.like, row.look, row.text, row.sub, row.meta, row.line, row.diamond }) do part:Hide() end
    row.rail:SetShown(st.rail)
    row.header:SetText("|cffc9a84c" .. item.header:upper() .. "|r")
    row.header:Show()
    row.headerLine:Show()
    row:Show()
    return
  end
  local ev = item
  row.ev = ev
  row.header:Hide()
  row.headerLine:Hide()
  local icon, desc, q, sub = ns:Describe(ev)
  local r, g, b = accentRGB(ev.k, q)
  row.icon:SetTexture(icon)
  row.icon:Show()
  row.iconBorder:SetColorTexture(r, g, b, 0.9)
  row.iconBorder:Show()
  row.accent:SetColorTexture(r, g, b, 0.9)
  row.accent:SetShown(st.box and not st.rail)
  setGradient(row.bg, r, g, b, 0.13)
  row.bg:SetShown(st.box and not st.rail)
  row.line:SetShown(st.box)
  row.rail:SetShown(st.rail)
  row.diamond:SetColorTexture(r, g, b, 1)
  row.diamond:SetShown(st.rail)
  row.flash:SetColorTexture(r, g, b, 0.5)
  row.time:SetText(ns.Ago(ev.t))
  row.time:Show()
  row.dot:SetShown(ns:IsNew(ev))
  row.msg:SetShown(not ev.self) -- no messaging yourself
  UI:PaintLike(row)
  -- the magnifier sits left of the bubble when there's something to look at
  local canLook = UI:PreviewKind(ev) ~= nil
  row.look:SetShown(canLook)
  row.dot:ClearAllPoints()
  row.dot:SetPoint("RIGHT", canLook and row.look or row.msg, "LEFT", -2, 0)
  row.text:Show()
  if row.compact then
    -- one line, no subtext: a death's or kill's counter goes on the end ("Total deaths: 37")
    local line = showName and (ns.Label(ev, true) .. " " .. desc) or desc
    local total, hex = ns:TotalText(ev)
    row.text:SetText(total and (line .. "  |cff" .. hex .. total .. "|r") or line)
  else
    local name, meta = ns.NameParts(ev)
    row.text:SetText(showName and (gold(name) .. " " .. desc) or desc)
    row.sub:SetText(sub or "") -- where it came from, and a death's counter
    row.meta:SetText((showName and meta) and ("|cff6a6a6a" .. meta .. "|r") or "")
    row.sub:Show()
    row.meta:Show()
  end
  row:Show()
end

---------------------------------------------------------------------------
-- Feed (top left)
---------------------------------------------------------------------------
function UI:FeedList()
  local list, showSelf, log = {}, ns.db.settings.showSelf, ns.db.log
  local clearedAt = ns.db.feedClearedAt or 0
  local hidden = 0 -- wanted, but hidden by the filter bar
  for i = #log, 1, -1 do
    local e = log[i]
    if (showSelf or not e.self) and ns:Wants(e) and (e.recv or e.t) > clearedAt then
      if self:FilterPasses(e) then list[#list + 1] = e else hidden = hidden + 1 end
    end
  end
  return list, hidden
end

-- What the feed's rows show: the events, with a day header before each new
-- day in the timeline look.
function UI:FeedItems()
  local list, hidden = self:FeedList()
  if not style().headers then return list, hidden end
  local items, lastDay, now = {}, nil, ns.Now()
  for _, e in ipairs(list) do
    local d = dayOf(e.t)
    if d ~= lastDay then
      items[#items + 1] = { header = dayLabel(e.t, now) }
      lastDay = d
    end
    items[#items + 1] = e
  end
  return items, hidden
end

local function headerButton(f, size, texture, tooltip, onClick)
  local b = CreateFrame("Button", nil, f)
  b:SetSize(size, size)
  b:SetNormalTexture(texture)
  b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
  b:SetScript("OnClick", onClick)
  b:SetScript("OnEnter", function(s)
    UI:Touch()
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
    GameTooltip:SetText(tooltip[1])
    if tooltip[2] then GameTooltip:AddLine(tooltip[2], 1, 1, 1, true) end
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", GameTooltip_Hide)
  return b
end

---------------------------------------------------------------------------
-- Filter bar: small toggles under the feed's header that hide kinds of
-- milestones and gear qualities from the feed. They only change what the
-- feed shows; pop-ups and sounds follow the Notify settings, and the history
-- window always shows everything. settings.feedFilter = { kinds = { k = false },
-- quality = { [3|4|5] = false } }; a missing entry means shown.
---------------------------------------------------------------------------
local FILTER_KINDS = {
  { k = "loot",  icon = "Interface\\Icons\\INV_Sword_04", label = "Gear & items" },
  { k = "level", icon = "Interface\\Icons\\Spell_Holy_SurgeOfLight", label = "Levels" },
  { k = "ach",   icon = "Interface\\Icons\\Achievement_General", label = "Achievements" },
  { k = "mount", icon = "Interface\\Icons\\Ability_Mount_RidingHorse", label = "Mounts" },
  { k = "pet",   icon = "Interface\\Icons\\INV_Box_PetCarrier_01", label = "Battle pets" },
  { k = "toy",   icon = "Interface\\Icons\\INV_Misc_Toy_10", label = "Toys" },
  { k = "death", icon = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_01", label = "Deaths" },
  { k = "kill",  icon = "Interface\\Icons\\Ability_DualWield", label = "World PvP kills" },
}
-- who: you (settings.showSelf, which also covers your own pop-ups; your
-- portrait when the game has one) and guildmates who aren't friends (their
-- events are tagged ev.guild)
local FILTER_SELF = { me = true, icon = "Interface\\Icons\\Achievement_Character_Human_Male", label = "My own milestones" }
local FILTER_GUILD = { g = "guild", icon = "Interface\\Icons\\INV_Shirt_GuildTabard_01", label = "Guildmates" }
local FILTER_QUALITIES = {
  { q = 2, label = "Green (uncommon) gear" },
  { q = 3, label = "Blue (rare) gear" },
  { q = 4, label = "Purple (epic) gear" },
  { q = 5, label = "Orange (legendary) gear" },
}
UI.FILTER_KINDS, UI.FILTER_SELF, UI.FILTER_GUILD, UI.FILTER_QUALITIES = FILTER_KINDS, FILTER_SELF, FILTER_GUILD, FILTER_QUALITIES

local function filters()
  local s = ns.db.settings
  s.feedFilter = s.feedFilter or {}
  local ff = s.feedFilter
  ff.kinds = ff.kinds or {}
  ff.quality = ff.quality or {}
  return ff
end

local function eventQuality(e)
  local q = tonumber(e.q)
  if not q and e.v and e.v > 0 and C_Item and C_Item.GetItemInfo then q = select(3, C_Item.GetItemInfo(e.v)) end
  return q
end

-- Is this from a guildmate who isn't a friend?
local function fromGuild(e)
  return e.guild == true or ns:IsGuildmate(e.id)
end

-- Does an event get past the filter bar? (grey and white gear is only
-- covered by the Gear toggle; orange covers legendary and above)
function UI:FilterPasses(e)
  local ff = filters()
  if ff.kinds[e.k] == false then return false end
  if ff.guild == false and fromGuild(e) then return false end
  if e.k == "loot" then
    local q = eventQuality(e)
    if q and q >= 2 and ff.quality[math.min(q, 5)] == false then return false end
  end
  return true
end

function UI:IsFilterOn(def)
  local ff = filters()
  if def.q then return ff.quality[def.q] ~= false end
  if def.me then return ns.db.settings.showSelf == true end
  if def.g then return ff.guild ~= false end
  return ff.kinds[def.k] ~= false
end

function UI:ToggleFilter(def)
  local ff = filters()
  if def.q then
    -- hidden is stored as false; shown is no entry at all
    if ff.quality[def.q] == false then ff.quality[def.q] = nil else ff.quality[def.q] = false end
  elseif def.me then
    ns.db.settings.showSelf = not ns.db.settings.showSelf
  elseif def.g then
    if ff.guild == false then ff.guild = nil else ff.guild = false end
  else
    if ff.kinds[def.k] == false then ff.kinds[def.k] = nil else ff.kinds[def.k] = false end
  end
  if self.feed then self.feed.offset = 0 end
  self:Touch()
  self:RefreshFeed()
end

function UI:ResetFilters()
  local ff = filters()
  wipe(ff.kinds)
  wipe(ff.quality)
  ff.guild = nil
  ns.db.settings.showSelf = true
  if self.feed then self.feed.offset = 0 end
  self:RefreshFeed()
end

local function FilterButton_OnEnter(self)
  UI:Touch()
  local on = UI:IsFilterOn(self.def)
  GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT")
  GameTooltip:SetText(self.def.label)
  GameTooltip:AddLine(on and "Shown in the feed. Click to hide." or "Hidden from the feed. Click to show.", 1, 1, 1, true)
  GameTooltip:AddLine("Right click: show everything again", 0.6, 0.6, 0.6)
  if self.def.me then
    GameTooltip:AddLine("Your own milestones, with a pop-up, so you can see who liked them. Hiding them here also stops their pop-ups.", 0.6, 0.6, 0.6, true)
    GameTooltip:Show()
    return
  end
  GameTooltip:AddLine("Only the feed is filtered. Pop-ups follow your Notify settings, and More details shows everything.", 0.6, 0.6, 0.6, true)
  GameTooltip:Show()
end

function UI:CreateFilterBar(f)
  local bar = CreateFrame("Frame", nil, f)
  bar:SetHeight(FILTER_H)
  bar:SetPoint("TOPLEFT", 9, -FEED_HEAD + 1)
  bar:SetPoint("TOPRIGHT", -9, -FEED_HEAD + 1)
  bar.buttons = {}
  local x = 0
  local function add(def)
    local b = CreateFrame("Button", nil, bar)
    b:SetSize(16, 16)
    b:SetPoint("LEFT", x, 0)
    b.border = b:CreateTexture(nil, "BACKGROUND")
    b.border:SetPoint("TOPLEFT", -1, 1)
    b.border:SetPoint("BOTTOMRIGHT", 1, -1)
    b.tex = b:CreateTexture(nil, "ARTWORK")
    b.tex:SetAllPoints()
    if def.q then
      local r, g, bl = qualityRGB(def.q)
      b.rgb = { r, g, bl }
    else
      b.tex:SetTexture(def.icon)
      b.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    end
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.25)
    b.def = def
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:SetScript("OnClick", function(self, button)
      if button == "RightButton" then UI:ResetFilters() else UI:ToggleFilter(self.def) end
      if GameTooltip:IsOwned(self) then FilterButton_OnEnter(self) end
    end)
    b:SetScript("OnEnter", FilterButton_OnEnter)
    b:SetScript("OnLeave", GameTooltip_Hide)
    bar.buttons[#bar.buttons + 1] = b
    x = x + 18
  end
  bar.dividers = {}
  local function divider()
    local d = bar:CreateTexture(nil, "ARTWORK")
    d:SetSize(1, 14)
    d:SetPoint("LEFT", x + 2, 0)
    d:SetColorTexture(1, 1, 1, 0.18)
    bar.dividers[#bar.dividers + 1] = d
    x = x + 8
  end
  -- what | who | gear quality
  for _, def in ipairs(FILTER_KINDS) do add(def) end
  divider()
  add(FILTER_SELF)
  add(FILTER_GUILD)
  divider()
  for _, def in ipairs(FILTER_QUALITIES) do add(def) end
  bar.note = bar:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  bar.note:SetPoint("RIGHT", 0, 0)
  f.filterBar = bar
  bar:SetShown(filterBarOn())
end

-- Paint the toggles on or off, and say how many rows they're hiding
function UI:UpdateFilterBar(hidden)
  local bar = self.feed and self.feed.filterBar
  if not bar then return end
  for _, b in ipairs(bar.buttons) do
    local on = self:IsFilterOn(b.def)
    b.on = on
    if b.def.q then
      local c = b.rgb
      b.tex:SetColorTexture(c[1], c[2], c[3], on and 1 or 0.12)
      b.border:SetColorTexture(on and c[1] or 0.35, on and c[2] or 0.35, on and c[3] or 0.35, on and 1 or 0.7)
    else
      -- your portrait once the game can draw it (tried until it works)
      if b.def.me and not b.portrait and SetPortraitTexture and UnitExists and UnitExists("player") then
        b.portrait = pcall(SetPortraitTexture, b.tex, "player") and true or false
      end
      pcall(b.tex.SetDesaturated, b.tex, not on)
      b.tex:SetAlpha(on and 1 or 0.3)
      b.border:SetColorTexture(on and 0.8 or 0.3, on and 0.66 or 0.3, on and 0.3 or 0.3, on and 0.8 or 0.6)
    end
  end
  bar.note:SetText((hidden or 0) > 0 and ("|cff888888" .. hidden .. " hidden|r") or "")
end

-- Show or hide the filter bar (settings), keeping the same number of rows
function UI:ApplyFilterBar()
  local f = self.feed
  if not f then return end
  local rows = f.numRows
  f.filterBar:SetShown(filterBarOn())
  f:SetHeight(feedHeight(rows))
  ns.db.settings.feedSize = { math.floor(f:GetWidth() + 0.5), feedHeight(rows) }
  f.numRows = 0 -- force a re-layout
  self:LayoutFeed()
  self:RequestRefresh()
end

function UI:CreateFeed()
  local f = CreateFrame("Frame", "FriendFeedFrame", UIParent, "BackdropTemplate")
  local size = ns.db.settings.feedSize
  -- sizes saved before the filter bar existed: make room for it so no row is lost
  if ns.db.settings.feedSize and not ns.db.settings.feedSizeHasFilterBar and filterBarOn() then
    ns.db.settings.feedSize[2] = (tonumber(ns.db.settings.feedSize[2]) or 0) + FILTER_H
  end
  ns.db.settings.feedSizeHasFilterBar = true
  size = ns.db.settings.feedSize
  local w = (size and tonumber(size[1])) or FEED_W
  local h = (size and tonumber(size[2])) or feedHeight(FEED_ROWS)
  -- a size saved with another look (or version) may not be whole rows: snap it
  local st = style()
  local rows = math.max(FEED_MIN_ROWS, math.min(st.maxRows, math.floor((h - headH() - FEED_FOOT + ROW_SLACK) / st.row)))
  f:SetSize(math.max(FEED_MIN_W, math.min(FEED_MAX_W, w)), feedHeight(rows))
  skin(f, 0.72)
  makeDraggable(f, "feedPoint")
  local pt = ns.db.settings.feedPoint
  if pt then
    f:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
  else
    f:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -140)
  end
  f:SetScript("OnEnter", function() UI:Touch() end)
  f:SetScript("OnLeave", function() C_Timer.After(0.3, function() UI:CheckHover() end) end)

  -- header band
  f.band = f:CreateTexture(nil, "BACKGROUND", nil, 1)
  f.band:SetPoint("TOPLEFT", 1, -1)
  f.band:SetPoint("TOPRIGHT", -1, -1)
  f.band:SetHeight(FEED_HEAD - 5)
  f.band:SetColorTexture(1, 1, 1, 1)
  setGradient(f.band, 1, 0.82, 0, 0.09)
  f.bandLine = f:CreateTexture(nil, "ARTWORK")
  f.bandLine:SetHeight(1)
  f.bandLine:SetPoint("TOPLEFT", 1, -(FEED_HEAD - 4))
  f.bandLine:SetPoint("TOPRIGHT", -1, -(FEED_HEAD - 4))
  f.bandLine:SetColorTexture(0.45, 0.36, 0.2, 0.6)

  f.logo = f:CreateTexture(nil, "ARTWORK")
  f.logo:SetSize(18, 18)
  f.logo:SetPoint("TOPLEFT", 6, -6)
  f.logo:SetTexture(ns.LOGO_SMALL)
  -- the logo is a button: the Friend Feed app and where to get it
  local lb = CreateFrame("Button", nil, f)
  lb:SetSize(22, 22)
  lb:SetPoint("CENTER", f.logo, "CENTER", 0, 0)
  lb:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
  lb:SetScript("OnClick", function() UI:ToggleAppPanel() end)
  lb:SetScript("OnEnter", function(s) UI:Touch(); UI:AppTooltip(s) end)
  lb:SetScript("OnLeave", GameTooltip_Hide)
  -- a small dot while the app isn't set up (or hasn't synced for days)
  lb.dot = lb:CreateTexture(nil, "OVERLAY")
  lb.dot:SetSize(7, 7)
  lb.dot:SetPoint("TOPRIGHT", 2, 1)
  lb.dot:SetColorTexture(0.56, 0.82, 1, 1)
  pcall(lb.dot.SetMask, lb.dot, "Interface\\CharacterFrame\\TempPortraitAlphaMask")
  lb.dot:Hide()
  f.logoBtn = lb

  f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.title:SetPoint("TOPLEFT", f.logo, "TOPRIGHT", 4, 2)
  f.title:SetText("Friend Feed")

  -- under the title, small: whether the Friend Feed app is connected. Red
  -- "App not connected" makes people wonder; hovering says what it is and
  -- where to get it, clicking opens the panel with the address to copy.
  local sl = CreateFrame("Button", nil, f)
  sl:SetSize(110, 11)
  sl:SetPoint("TOPLEFT", f.title, "BOTTOMLEFT", 0, -1)
  sl.text = sl:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  sl.text:SetPoint("LEFT", 0, 0)
  sl:SetScript("OnClick", function() UI:ToggleAppPanel() end)
  sl:SetScript("OnEnter", function(s) UI:Touch(); s.text:SetAlpha(1); UI:AppTooltip(s) end)
  sl:SetScript("OnLeave", function(s) s.text:SetAlpha(0.85); GameTooltip_Hide() end)
  sl.text:SetAlpha(0.85)
  f.appLine = sl

  f.count = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.count:SetPoint("LEFT", f.title, "RIGHT", 8, 0)

  -- minimise: the feed tucks into the minimap button (a plain bar, drawn, so it always shows)
  local mini = CreateFrame("Button", nil, f)
  mini:SetSize(14, 14)
  mini:SetPoint("TOPRIGHT", -7, -9)
  mini.bar = mini:CreateTexture(nil, "ARTWORK")
  mini.bar:SetSize(9, 2)
  mini.bar:SetPoint("CENTER", 0, -3)
  mini.bar:SetColorTexture(0.85, 0.85, 0.85, 0.9)
  mini:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
  mini:SetScript("OnClick", function() UI:Minimize() end)
  mini:SetScript("OnEnter", function(s)
    UI:Touch()
    s.bar:SetColorTexture(1, 0.82, 0, 1)
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
    GameTooltip:SetText("Minimise to the minimap")
    GameTooltip:AddLine("Pop-ups still show, and the minimap button counts what arrives. Click it to bring the feed back.", 1, 1, 1, true)
    GameTooltip:Show()
  end)
  mini:SetScript("OnLeave", function(s) s.bar:SetColorTexture(0.85, 0.85, 0.85, 0.9); GameTooltip_Hide() end)
  f.minimize = mini

  local gear = headerButton(f, 14, "Interface\\Buttons\\UI-OptionsButton",
    { "Friend Feed settings" }, function() ns.Settings:Toggle() end)
  gear:SetPoint("RIGHT", mini, "LEFT", -6, 0)

  -- "More details" in the header, next to the gear: opens the friend history window
  local details = headerButton(f, 14, "Interface\\Icons\\INV_Misc_Book_09",
    { "More details", "Each friend's full history." }, function() UI:ToggleDetails() end)
  details:GetNormalTexture():SetTexCoord(0.08, 0.92, 0.08, 0.92)
  details:SetPoint("RIGHT", gear, "LEFT", -6, 0)
  f.detailsButton = details

  -- "Clear" in the header: empties the feed, keeps the history
  local btn = CreateFrame("Button", nil, f)
  btn:SetSize(34, 16)
  btn:SetPoint("RIGHT", details, "LEFT", -7, 0)
  btn.text = btn:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  btn.text:SetPoint("RIGHT")
  btn.text:SetText("Clear")
  btn:SetScript("OnClick", function() UI:ClearFeed() end)
  btn:SetScript("OnEnter", function(s)
    UI:Touch()
    s.text:SetTextColor(1, 0.82, 0)
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
    GameTooltip:SetText("Clear the feed")
    GameTooltip:AddLine("Your friends' full history stays in More details (the book icon).", 1, 1, 1, true)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function(s) s.text:SetTextColor(0.5, 0.5, 0.5); GameTooltip:Hide() end)

  f.more = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.more:SetPoint("RIGHT", btn, "LEFT", -8, 0)

  self:CreateFilterBar(f)

  f.rows = {}      -- created as needed when the feed gets taller
  f.numRows = 0

  f.empty = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.empty:SetPoint("LEFT", 15, -10)
  f.empty:SetPoint("RIGHT", -15, -10)
  f.empty:SetText(EMPTY_TEXT)

  f.offset = 0
  f:EnableMouseWheel(true)
  f:SetScript("OnMouseWheel", function(self, delta) self.offset = self.offset - delta * 2; UI:RefreshFeed() end)

  -- resize grip in the bottom right corner
  f:SetResizable(true)
  if f.SetResizeBounds then
    f:SetResizeBounds(FEED_MIN_W, feedHeight(FEED_MIN_ROWS), FEED_MAX_W, feedHeight(style().maxRows))
  end
  local grip = CreateFrame("Button", nil, f)
  grip:SetSize(12, 12)
  grip:SetPoint("BOTTOMRIGHT", -2, 2)
  grip:SetFrameLevel(f:GetFrameLevel() + 10)
  grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
  grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
  grip:SetScript("OnMouseDown", function(_, button)
    if button == "LeftButton" and not ns.db.settings.locked then
      f.sizing = true
      pinTopLeft(f) -- so only the bottom-right corner follows the mouse
      f:StartSizing("BOTTOMRIGHT")
    end
  end)
  grip:SetScript("OnMouseUp", function() UI:StopFeedSizing() end)
  grip:SetScript("OnHide", function() UI:StopFeedSizing() end)
  grip:SetScript("OnEnter", function(s)
    UI:Touch()
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:SetText("Drag to resize"); GameTooltip:Show()
  end)
  grip:SetScript("OnLeave", GameTooltip_Hide)
  f.grip = grip

  f:SetScript("OnSizeChanged", function() UI:LayoutFeed() end)

  f.lastActivity = GetTime()
  f.targetAlpha = 1
  self.feed = f
  self:ApplyBox()
  self:LayoutFeed()
  self:ApplyLock()
  f:SetShown(ns.db.settings.feedShown)
end

-- Box or no box, for the current look, and how solid the box is (settings.feedAlpha, percent)
function UI:ApplyBox()
  local f = self.feed
  if not f then return end
  local box = style().box
  local a = box and math.max(0, math.min(100, tonumber(ns.db.settings.feedAlpha) or 70)) / 100 or 0
  f:SetBackdrop(BACKDROP)
  f:SetBackdropColor(0.03, 0.03, 0.05, a)
  f:SetBackdropBorderColor(0.45, 0.36, 0.2, 0.85 * math.sqrt(a)) -- the border fades more slowly than the fill
  f.band:SetShown(box)
  f.bandLine:SetShown(box)
  f.boxless = not box
  f.bgAlpha = a
  self:UpdateAppDot() -- the status line gets a shadow in the boxless look
end

-- How many whole rows fit in a feed this tall
local function rowsFor(height)
  local st = style()
  return math.max(FEED_MIN_ROWS, math.min(st.maxRows, math.floor(((height or 0) - headH() - FEED_FOOT + ROW_SLACK) / st.row)))
end

-- Fit as many rows as the feed's height allows, creating rows on demand.
function UI:LayoutFeed()
  local f = self.feed
  if not f then return end
  -- a pop-up on screen follows the feed's width as it's resized
  local t = self.toast
  if t and t:IsShown() and not t.flying then t:SetWidth(self:ToastWidth()) end
  local n = rowsFor(f:GetHeight())
  local rowH = style().row
  for i = #f.rows + 1, n do
    local r = CreateRow(f)
    r.inFeed = true
    r:EnableMouseWheel(true)
    r:SetScript("OnMouseWheel", function(_, delta) f.offset = f.offset - delta * 2; UI:RefreshFeed() end)
    f.rows[i] = r
  end
  for i, r in ipairs(f.rows) do
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", 4, -headH() - (i - 1) * rowH)
    r:SetPoint("TOPRIGHT", -4, -headH() - (i - 1) * rowH) -- rows stretch with the width
    if i > n then r:Hide() end
  end
  if n ~= f.numRows then
    f.numRows = n
    self:RefreshFeed()
  end
end

-- Finish a resize: snap the height to whole rows and remember the size.
function UI:StopFeedSizing()
  local f = self.feed
  if not (f and f.sizing) then return end
  f.sizing = false
  f:StopMovingOrSizing()
  -- the size as it was let go, before anything re-anchors the frame
  local h, rawW = f:GetHeight(), f:GetWidth()
  -- pin the top-left, so snapping the height to whole rows only moves the bottom
  savePosition(f, "feedPoint")
  local rows = rowsFor(h)
  local w = math.floor(math.max(FEED_MIN_W, math.min(FEED_MAX_W, rawW)) + 0.5)
  f:SetSize(w, feedHeight(rows))
  ns.db.settings.feedSize = { w, feedHeight(rows) }
  self:LayoutFeed()
end

-- The look changed (settings): restyle every row and keep the feed at whole rows.
function UI:ApplyStyle()
  local f = self.feed
  if not f then return end
  for _, r in ipairs(f.rows) do self:StyleRow(r) end
  if self.details then
    for _, r in ipairs(self.details.histRows) do self:StyleRow(r, detailsStyle()) end
  end
  self:ApplyBox()
  if f.SetResizeBounds then
    f:SetResizeBounds(FEED_MIN_W, feedHeight(FEED_MIN_ROWS), FEED_MAX_W, feedHeight(style().maxRows))
  end
  local rows = rowsFor(f:GetHeight())
  f:SetHeight(feedHeight(rows))
  ns.db.settings.feedSize = { math.floor(f:GetWidth() + 0.5), feedHeight(rows) }
  f.numRows = 0 -- force a re-layout even if the count didn't change
  self:LayoutFeed()
  self:LayoutDetails()
  self:RequestRefresh()
end

-- Locking the feed stops both dragging and resizing.
function UI:ApplyLock()
  local f = self.feed
  if not f then return end
  local locked = ns.db.settings.locked
  if locked then self:StopFeedSizing() end
  f.grip:SetShown(not locked)
end

-- chat look: the newest rows are solid, older ones fade, unless the mouse is on the feed
local function rowAlpha(i, st, hovered)
  if not (st.fade and not hovered) then return 1 end
  return math.max(0.35, 1 - 0.14 * math.max(0, i - 2))
end
UI.RowAlpha = rowAlpha

function UI:RefreshFeed(flashEv)
  local f = self.feed
  if not f then return end
  local st = style()
  local list, hidden = self:FeedItems()
  local rows = f.numRows
  local maxOff = math.max(0, #list - rows)
  f.offset = math.max(0, math.min(f.offset or 0, maxOff))
  for i = 1, rows do
    local r = f.rows[i]
    SetRow(r, list[i + f.offset], true)
    r:SetAlpha(rowAlpha(i, st, f.hovered))
  end
  f.empty:SetShown(#list == 0)
  if (hidden or 0) > 0 then
    f.empty:SetText("Everything here is hidden by the filters above.\nRight click a filter to show everything again.")
  else
    f.empty:SetText(EMPTY_TEXT)
  end
  self:UpdateFilterBar(hidden)

  local newCount = 0
  for _, e in ipairs(list) do if not e.header and ns:IsNew(e) then newCount = newCount + 1 end end
  local count = newCount > 0 and gold(newCount .. " new") or ""
  if ns:IsDemoRunning() then count = count .. (count ~= "" and "  " or "") .. "|cff8fd0ffdemo|r" end
  f.count:SetText(count)

  if #list > rows then
    f.more:SetText(format("%d-%d of %d", f.offset + 1, math.min(f.offset + rows, #list), #list))
  else
    f.more:SetText("")
  end

  if flashEv then
    self:Touch()
    local r = self:FeedRowFor(flashEv)
    if r then r.flashAnim:Stop(); r.flashAnim:Play() end
  end
end

-- The visible feed row showing this event, if any
function UI:FeedRowFor(ev)
  local f = self.feed
  if not (ev and f and f:IsShown()) then return nil end
  for i = 1, f.numRows do
    local r = f.rows[i]
    if r and r:IsShown() and rawget(r, "ev") == ev then return r end
  end
  return nil
end

-- A pop-up just swooped into the feed: light its row up
function UI:Landed(ev)
  local r = self:FeedRowFor(ev)
  if not r then return end
  r.flashAnim:Stop(); r.flashAnim:Play()
  if r.popAnim then r.popAnim:Stop(); r.popAnim:Play() end
  self:Touch()
end

---------------------------------------------------------------------------
-- Idle dimming: the feed fades down when nothing new has happened for a
-- while, and comes back when something lands or the mouse is over it.
---------------------------------------------------------------------------
function UI:Touch()
  local f = self.feed
  if not f then return end
  f.lastActivity = GetTime()
  if f:IsMouseOver() and not f.hovered then
    f.hovered = true
    if style().fade then self:RefreshFeed() end
  end
  self:UpdateFeedDim()
end

-- The mouse may have left the feed: let chat-style rows fade again
function UI:CheckHover()
  local f = self.feed
  if f and f.hovered and not f:IsMouseOver() then
    f.hovered = false
    if style().fade then self:RefreshFeed() end
  end
end

local function fadeStep(self, dt)
  local a, target = self:GetAlpha(), self.targetAlpha
  local step = dt * 1.6
  if math.abs(a - target) <= step then
    self:SetAlpha(target)
    self:SetScript("OnUpdate", nil)
  else
    self:SetAlpha(a + (target > a and step or -step))
  end
end

-- What alpha the feed should be heading for right now
function UI:FeedDimTarget(now)
  local f = self.feed
  if not (f and ns.db.settings.feedDim) then return 1 end
  now = now or GetTime()
  if f:IsMouseOver() then f.lastActivity = now; return 1 end
  if now - (f.lastActivity or 0) < DIM_AFTER then return 1 end
  return DIM_ALPHA
end

function UI:UpdateFeedDim(now)
  local f = self.feed
  if not f then return end
  local target = self:FeedDimTarget(now)
  if target ~= f.targetAlpha then
    f.targetAlpha = target
    f:SetScript("OnUpdate", fadeStep)
  end
  return target
end

function UI:ClearFeed()
  ns.db.feedClearedAt = ns.Now()
  if self.feed then self.feed.offset = 0 end
  self:RequestRefresh()
  ns.Print("Feed cleared. Everything is still in More details (the book icon on the feed).")
end

-- Show the feed, or hide it (minimised into the minimap button, or pop-ups only)
function UI:ShowFeed(on)
  local s = ns.db.settings
  s.feedShown = on and true or false
  if not self.feed then return end
  self.feed:SetShown(s.feedShown)
  if s.feedShown then
    self:ClearUnseen()
    self:Touch()
    self:RefreshFeed()
  end
  self:UpdateMinimapButton()
end

function UI:ToggleFeed()
  self:ShowFeed(not ns.db.settings.feedShown)
end

-- The minimise button on the feed: hide it and show where it went
function UI:Minimize()
  self:ShowFeed(false)
  local s = ns.db.settings
  if s.minimap.hide then
    ns.Print("Feed hidden. Type |cffffd200/ff|r to bring it back.")
  else
    self:PingMinimap()
    if not s.minimizeTipShown then
      s.minimizeTipShown = true
      ns.Print("The feed is now in the Friend Feed button on your minimap. Click it to bring the feed back; drag it to move it round the edge.")
    end
  end
end

---------------------------------------------------------------------------
-- Toasts (animated pop-ups)
---------------------------------------------------------------------------
local toastQueue = {}
function UI:PendingToasts() return toastQueue end -- for tests

local function easeOut(x) return 1 - (1 - x) ^ 3 end

function UI:CreateToast()
  local t = CreateFrame("Button", "FriendFeedToast", UIParent, "BackdropTemplate")
  t:SetSize(TOAST_W, 56)
  t:SetFrameStrata("HIGH")
  t:Hide()
  skin(t, 0.93)

  t.glow = t:CreateTexture(nil, "BACKGROUND", nil, 1)
  t.glow:SetPoint("TOPLEFT", 1, -1)
  t.glow:SetPoint("BOTTOMRIGHT", -1, 1)
  t.glow:SetColorTexture(1, 1, 1, 1)
  local pulse = t.glow:CreateAnimationGroup()
  pulse:SetLooping("BOUNCE")
  local pa = pulse:CreateAnimation("Alpha")
  pa:SetFromAlpha(1); pa:SetToAlpha(0.3); pa:SetDuration(0.7)
  t.pulse = pulse

  t.iconBorder = t:CreateTexture(nil, "BORDER")
  t.icon = t:CreateTexture(nil, "ARTWORK")
  t.icon:SetPoint("CENTER", t, "LEFT", 29, 0)
  t.icon:SetSize(40, 40)
  t.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  t.iconBorder:SetPoint("TOPLEFT", t.icon, -1, 1)
  t.iconBorder:SetPoint("BOTTOMRIGHT", t.icon, 1, -1)

  t.who = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  t.who:SetPoint("TOPLEFT", t, "TOPLEFT", 58, -10)
  t.who:SetPoint("RIGHT", -10, 0)
  t.who:SetJustifyH("LEFT")
  t.who:SetWordWrap(false)

  t.body = t:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  t.body:SetPoint("TOPLEFT", t.who, "BOTTOMLEFT", 0, -4)
  t.body:SetPoint("RIGHT", -10, 0)
  t.body:SetJustifyH("LEFT")
  t.body:SetWordWrap(false)

  -- where it came from
  t.sub = t:CreateFontString(nil, "OVERLAY", SUB_FONT)
  t.sub:SetPoint("TOPLEFT", t.body, "BOTTOMLEFT", 0, -3)
  t.sub:SetPoint("RIGHT", -10, 0)
  t.sub:SetJustifyH("LEFT")
  t.sub:SetWordWrap(false)

  t:SetScript("OnEnter", function(self) self.hover = true end)
  t:SetScript("OnLeave", function(self) self.hover = false end)
  t:SetScript("OnClick", function(self)
    if self.ev and modified("DRESSUP") and UI:Preview(self.ev) then return end
    if self.sample then UI:MoveToasts() else UI:OpenDetails(self.target) end
    self.elapsed = math.max(self.elapsed, T_IN + T_HOLD)
  end)

  t:SetScript("OnUpdate", function(self, dt)
    local e = self.elapsed
    local holding = e > T_IN and e < T_IN + T_HOLD
    if not (self.hover and holding) then self.elapsed = e + dt end
    e = self.elapsed

    local x, y, alpha, scale = 0, 0, 1, 1
    if e < T_IN then
      local p = easeOut(e / T_IN)
      x, alpha, scale = -60 * (1 - p), p, 1.6 - 0.6 * p
    elseif e < T_IN + T_HOLD then
      -- hold
    elseif e < T_IN + T_HOLD + T_OUT then
      local p = (e - T_IN - T_HOLD) / T_OUT
      if not self.flyChecked then
        self.flyChecked = true
        self.fly = UI:ToastFlightPlan(self)
        self.flying = self.fly ~= nil -- LayoutFeed leaves a flying pop-up alone
      end
      local fl = self.fly
      if fl then
        -- swoop into the feed row that now shows this milestone: slide,
        -- shrink to the row's size, then let the row's flash take over
        local q = p * p * (3 - 2 * p)
        self:ClearAllPoints()
        self:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", fl.x0 + (fl.x1 - fl.x0) * q, fl.y0 + (fl.y1 - fl.y0) * q)
        self:SetSize(fl.w0 + (fl.w1 - fl.w0) * q, fl.h0 + (fl.h1 - fl.h0) * q)
        self.icon:SetSize(40 - 16 * q, 40 - 16 * q)
        self:SetAlpha(p < 0.55 and 1 or (1 - (p - 0.55) / 0.45))
        return
      end
      alpha, y = 1 - p, 12 * p
    else
      self:Hide()
      self.pulse:Stop()
      if self.fly then
        if self.fly.mini then UI:PingMinimap(self.fly.ev) else UI:Landed(self.fly.ev) end
      end
      self.fly, self.flyChecked, self.flying = nil, nil, false
      UI:NextToast()
      return
    end
    self:SetAlpha(alpha)
    self:ClearAllPoints()
    self:SetPoint(self.ap[1], self.ap[2], self.ap[3], self.ap[4] + x, self.ap[5] + y)
    self.icon:SetSize(40 * scale, 40 * scale)
  end)

  self.toast = t
end

-- A frame's scale on screen, or 1 where the client can't say
local function scaleOf(fr)
  local ok, s = pcall(fr.GetEffectiveScale, fr)
  if ok and type(s) == "number" and s > 0 then return s end
  return 1
end

-- Where a finishing pop-up should fly to: the feed row showing its event, or
-- the minimap button while the feed is minimised. Screen positions in
-- UIParent coordinates; nil means just fade out.
function UI:ToastFlightPlan(t)
  local ev = t.ev
  if not ev then return nil end
  local target, mini = self:FeedRowFor(ev), false
  if not target and self:MinimapButtonShown() and not (self.feed and self.feed:IsShown()) then
    target, mini = self.mini, true
  end
  if not target then return nil end
  local x0, y0, x1, y1 = t:GetLeft(), t:GetTop(), target:GetLeft(), target:GetTop()
  local w0, h0, w1, h1 = t:GetWidth(), t:GetHeight(), target:GetWidth(), target:GetHeight()
  for _, v in ipairs({ x0, y0, x1, y1, w0, h0, w1, h1 }) do
    if type(v) ~= "number" then return nil end
  end
  -- the minimap may be scaled differently from the rest of the UI
  local k = scaleOf(target) / scaleOf(UIParent)
  x1, y1, w1, h1 = x1 * k, y1 * k, w1 * k, h1 * k
  return { ev = ev, mini = mini or nil, x0 = x0, y0 = y0, x1 = x1, y1 = y1, w0 = w0, h0 = h0, w1 = w1, h1 = h1 }
end

-- Pop-ups are always the feed's width (even while the feed is hidden), so the two line up
function UI:ToastWidth()
  local w = self.feed and tonumber(self.feed:GetWidth())
  if w and w > 0 then return w end
  return TOAST_W
end

function UI:ToastFromEvent(ev)
  local icon, desc, q, sub = ns:Describe(ev)
  local r, g, b = accentRGB(ev.k, q)
  -- your own: silent (the game already plays its own fanfare), and clicking
  -- it opens All friends, since history only lists friends
  return { icon = icon, title = ns.Label(ev), body = desc, sub = sub, q = q, color = { r, g, b },
           target = (not ev.self) and ev.id or nil, sound = (not ev.self) and ev.k or nil,
           ev = ev, demo = ev.demo or nil }
end

---------------------------------------------------------------------------
-- Where pop-ups appear. Under the feed to start with (or where the feed
-- would be while it's hidden); once the player drags them somewhere else
-- (settings, /ff popups) they stay there: settings.toastPoint.
---------------------------------------------------------------------------
function UI:ToastAnchor()
  local p = ns.db.settings.toastPoint
  if type(p) == "table" and type(p[1]) == "string" then
    return { p[1], UIParent, p[2] or p[1], tonumber(p[3]) or 0, tonumber(p[4]) or 0 }
  end
  -- under the feed, whether it's showing or minimised, so pop-ups never jump
  -- when the feed is minimised (0.8.0 moved them up to the hidden feed's top)
  if self.feed then return { "TOPLEFT", self.feed, "BOTTOMLEFT", 0, -6 } end
  return { "TOPLEFT", UIParent, "TOPLEFT", 20, -140 }
end

-- Remember where the blue box is, as its top-left corner on screen (UIParent's
-- bottom-left origin). GetPoint isn't used: after a drag it can still be
-- relative to the feed, and the game may pick another corner of the box.
function UI:SaveToastPoint(m)
  local left, top = m:GetLeft(), m:GetTop()
  if type(left) ~= "number" or type(top) ~= "number" then return false end
  local k = scaleOf(m) / scaleOf(UIParent)
  ns.db.settings.toastPoint = { "TOPLEFT", "BOTTOMLEFT", math.floor(left * k + 0.5), math.floor(top * k + 0.5) }
  ns.db.settings.toastPointV = 2 -- saved this way (see the 0.8.1 note in Core.lua)
  return true
end

function UI:CreateToastMover()
  local m = CreateFrame("Frame", "FriendFeedToastMover", UIParent, "BackdropTemplate")
  m:SetSize(TOAST_W, 68)
  m:SetFrameStrata("DIALOG")
  m:Hide()
  m:SetBackdrop(BACKDROP)
  m:SetBackdropColor(0.06, 0.12, 0.2, 0.92)
  m:SetBackdropBorderColor(0.56, 0.82, 1, 1)
  m:SetMovable(true)
  m:EnableMouse(true)
  m:SetClampedToScreen(true)
  m:RegisterForDrag("LeftButton")
  m:SetScript("OnDragStart", function(self) self:StartMoving() end)
  m:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    UI:SaveToastPoint(self)
    -- pin the box to exactly what was saved, so it shows where pop-ups will go
    UI:PlaceToastMover()
  end)
  tinsert(UISpecialFrames, "FriendFeedToastMover") -- Esc finishes

  m.title = m:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  m.title:SetPoint("TOPLEFT", 10, -9)
  m.title:SetText("|cff8fd0ffPop-ups appear here|r")
  m.text = m:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  m.text:SetPoint("TOPLEFT", m.title, "BOTTOMLEFT", 0, -3)
  m.text:SetPoint("RIGHT", -10, 0)
  m.text:SetJustifyH("LEFT")
  m.text:SetText("Drag this box where you want them.")

  local function button(label, w, onClick)
    local b = CreateFrame("Button", nil, m, "UIPanelButtonTemplate")
    b:SetSize(w, 20)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return b
  end
  m.done = button("Done", 60, function() m:Hide() end)
  m.done:SetPoint("BOTTOMRIGHT", -6, 6)
  m.test = button("Test", 56, function()
    UI:QueueToast({ icon = ns.LOGO_SMALL, title = "Friend Feed", body = "Pop-ups will show up here.", q = 4, sound = "summary", sample = true }, true)
  end)
  m.test:SetPoint("RIGHT", m.done, "LEFT", -4, 0)
  m.reset = button("Under the feed", 110, function()
    ns.db.settings.toastPoint = nil
    UI:PlaceToastMover()
  end)
  m.reset:SetPoint("RIGHT", m.test, "LEFT", -4, 0)
  self.toastMover = m
end

function UI:PlaceToastMover()
  local m = self.toastMover
  if not m then return end
  local ap = self:ToastAnchor()
  m:ClearAllPoints()
  m:SetPoint(ap[1], ap[2], ap[3], ap[4], ap[5])
  m:SetWidth(math.max(300, self:ToastWidth()))
end

-- Show the box that sets where pop-ups appear
function UI:MoveToasts()
  if not self.toastMover then return end
  if ns.Settings and ns.Settings.frame then ns.Settings.frame:Hide() end
  self:PlaceToastMover()
  self.toastMover:Show()
  ns.Print("Drag the blue box to where pop-ups should appear, then click Done.")
end

---------------------------------------------------------------------------
-- Minimap button. The feed minimises into it; while the feed is hidden it
-- counts the milestones that arrive and pings (a ring in the milestone's
-- colour) as each one lands, and pop-ups fly into it. Left click shows or
-- minimises the feed, Shift+click opens the history, right click the
-- settings. Drag it round the minimap's edge: settings.minimap.angle.
---------------------------------------------------------------------------
local atan2 = math.atan2 or math.atan
local MINI_RING = "Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"

local function miniSettings()
  local s = ns.db.settings
  if type(s.minimap) ~= "table" then s.minimap = {} end
  s.minimap.angle = tonumber(s.minimap.angle) or 215
  return s.minimap
end

-- Offset from the minimap's centre for an angle in degrees (0 = right, 90 = top).
-- Round minimaps put it on the circle; square ones (some UI addons) on the edge.
function UI:MinimapOffset(angle)
  local a = math.rad(angle or 215)
  local x, y = math.cos(a), math.sin(a)
  local mw = Minimap and tonumber(Minimap:GetWidth()) or 0
  local mh = Minimap and tonumber(Minimap:GetHeight()) or 0
  local w = (mw > 0 and mw or 140) / 2 + 5
  local h = (mh > 0 and mh or 140) / 2 + 5
  local shape = GetMinimapShape and GetMinimapShape() or "ROUND"
  if shape == "SQUARE" then
    return math.max(-w, math.min(w, x * w * 1.42)), math.max(-h, math.min(h, y * h * 1.42))
  end
  return x * w, y * h
end

-- The angle (degrees, 0-360) of a screen point around the minimap's centre
function UI:MinimapAngleAt(px, py)
  local mx, my = Minimap:GetCenter()
  if type(mx) ~= "number" or type(my) ~= "number" then return miniSettings().angle end
  return math.deg(atan2(py - my, px - mx)) % 360
end

function UI:PlaceMinimapButton()
  local b = self.mini
  if not b then return end
  local x, y = self:MinimapOffset(miniSettings().angle)
  b:ClearAllPoints()
  b:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function MiniButton_OnEnter(self)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  GameTooltip:SetText("Friend Feed")
  local n = UI.unseen or 0
  if n > 0 then GameTooltip:AddLine(n .. " new while the feed was minimised", 1, 0.82, 0) end
  local shown = UI.feed and UI.feed:IsShown()
  GameTooltip:AddLine((shown and "Click: minimise the feed" or "Click: show the feed"), 0.5, 0.8, 1)
  GameTooltip:AddLine("Shift+click: friend history", 0.5, 0.8, 1)
  GameTooltip:AddLine("Right click: settings", 0.5, 0.8, 1)
  GameTooltip:AddLine("Ctrl+click: the Friend Feed app", 0.5, 0.8, 1)
  if ns:AppStatus() ~= "connected" then GameTooltip:AddLine(UI:AppStatusText(), 1, 1, 1, true) end
  GameTooltip:AddLine("Drag: move it round the minimap", 0.6, 0.6, 0.6)
  GameTooltip:Show()
end

function UI:CreateMinimapButton()
  if not Minimap then return end
  local b = CreateFrame("Button", "FriendFeedMinimapButton", Minimap)
  b:SetSize(31, 31)
  b:SetFrameStrata("MEDIUM")
  b:SetFrameLevel(8)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:RegisterForDrag("LeftButton")
  b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

  -- the usual round minimap button: dark disc, the logo, the gold ring
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetSize(24, 24)
  b.bg:SetPoint("CENTER", 0, 0)
  b.bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetSize(20, 20)
  b.icon:SetPoint("CENTER", 0, 0)
  b.icon:SetTexture(ns.LOGO_SMALL)
  b.border = b:CreateTexture(nil, "OVERLAY")
  b.border:SetSize(53, 53)
  b.border:SetPoint("TOPLEFT", 0, 0)
  b.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

  -- the ping: a ring in the milestone's colour that flares out a few times
  b.ring = b:CreateTexture(nil, "OVERLAY", nil, 2)
  b.ring:SetSize(46, 46)
  b.ring:SetPoint("CENTER", 0, 0)
  b.ring:SetTexture(MINI_RING)
  pcall(b.ring.SetBlendMode, b.ring, "ADD")
  b.ring:SetAlpha(0)
  local ping = b.ring:CreateAnimationGroup()
  ping:SetLooping("REPEAT")
  local up = ping:CreateAnimation("Alpha")
  up:SetFromAlpha(0); up:SetToAlpha(1); up:SetDuration(0.2); up:SetOrder(1)
  local grow = ping:CreateAnimation("Scale")
  if not pcall(grow.SetScaleFrom, grow, 0.7, 0.7) then pcall(grow.SetFromScale, grow, 0.7, 0.7) end
  if not pcall(grow.SetScaleTo, grow, 1.35, 1.35) then pcall(grow.SetToScale, grow, 1.35, 1.35) end
  grow:SetDuration(0.6); grow:SetOrder(1)
  local down = ping:CreateAnimation("Alpha")
  down:SetFromAlpha(1); down:SetToAlpha(0); down:SetDuration(0.4); down:SetOrder(2)
  b.ping = ping

  -- how many arrived while the feed was hidden
  b.badge = CreateFrame("Frame", nil, b)
  b.badge:SetSize(16, 16)
  b.badge:SetPoint("TOPRIGHT", 3, 3)
  b.badge:SetFrameLevel(b:GetFrameLevel() + 3)
  b.badge.bg = b.badge:CreateTexture(nil, "ARTWORK")
  b.badge.bg:SetAllPoints()
  b.badge.bg:SetColorTexture(0.8, 0.1, 0.1, 1)
  pcall(b.badge.bg.SetMask, b.badge.bg, "Interface\\CharacterFrame\\TempPortraitAlphaMask") -- round, where it works
  b.badge.text = b.badge:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.badge.text:SetPoint("CENTER", 0, 0)
  b.badge:Hide()

  b:SetScript("OnClick", function(_, button)
    if button == "RightButton" then
      ns.Settings:Toggle()
    elseif IsControlKeyDown and IsControlKeyDown() then
      UI:ToggleAppPanel()
    elseif IsShiftKeyDown and IsShiftKeyDown() then
      UI:ToggleDetails()
    else
      UI:ToggleFeed()
    end
    if GameTooltip:IsOwned(b) then MiniButton_OnEnter(b) end
  end)
  b:SetScript("OnEnter", MiniButton_OnEnter)
  b:SetScript("OnLeave", GameTooltip_Hide)
  b:SetScript("OnDragStart", function(self)
    self.dragging = true
    GameTooltip_Hide()
    self:SetScript("OnUpdate", function()
      local px, py = GetCursorPosition()
      local scale = scaleOf(Minimap)
      miniSettings().angle = math.floor(UI:MinimapAngleAt(px / scale, py / scale) + 0.5)
      UI:PlaceMinimapButton()
    end)
  end)
  b:SetScript("OnDragStop", function(self)
    self.dragging = false
    self:SetScript("OnUpdate", nil)
  end)

  self.mini = b
  self.unseen = 0
  self:PlaceMinimapButton()
  self:ApplyMinimapButton()
end

function UI:MinimapButtonShown()
  return self.mini ~= nil and self.mini:IsShown()
end

-- Show or hide the button (settings.minimap.hide)
function UI:ApplyMinimapButton()
  if not self.mini then return end
  self.mini:SetShown(not miniSettings().hide)
  self:PlaceMinimapButton()
  self:UpdateMinimapButton()
end

function UI:UpdateMinimapButton()
  local b = self.mini
  if not b then return end
  local n = self.unseen or 0
  b.badge:SetShown(n > 0)
  b.badge.text:SetText(n > 99 and "99+" or tostring(n))
end

-- A milestone arrived while the feed is hidden: count it, and ping now
-- unless a pop-up is about to fly into the button (it pings on landing)
function UI:NoteUnseen(ev, pingNow)
  self.unseen = (self.unseen or 0) + 1
  if ev and ev.demo then self.unseenDemo = (self.unseenDemo or 0) + 1 end
  self:UpdateMinimapButton()
  if pingNow then self:PingMinimap(ev) end
end

function UI:ClearUnseen()
  self.unseen = 0
  self.unseenDemo = 0
  self:UpdateMinimapButton()
end

-- Flash the ring a few times, in the milestone's colour (gold without one)
function UI:PingMinimap(ev)
  local b = self.mini
  if not (b and b:IsShown()) then return end
  local r, g, bl = 1, 0.82, 0
  if ev then
    local _, _, q = ns:Describe(ev)
    r, g, bl = accentRGB(ev.k, q)
  end
  pcall(b.ring.SetVertexColor, b.ring, r, g, bl)
  b.ping:Stop()
  b.ping:Play()
  self.pingGen = (self.pingGen or 0) + 1
  local gen = self.pingGen
  C_Timer.After(3, function()
    if UI.pingGen == gen then b.ping:Stop(); b.ring:SetAlpha(0) end
  end)
end

---------------------------------------------------------------------------
-- Sounds. A palette of named sounds the player can pick from for each kind
-- of alert (settings.sounds). Each entry lists what to try in order: sound
-- kit names the client may know, then raw sound kit numbers, so a missing
-- name falls back safely. "Test sounds" prints what was actually played.
---------------------------------------------------------------------------
local SOUND_OPTIONS = {
  { value = "epic",        label = "Epic loot",        kit = { "UI_EPICLOOT_TOAST", 31578 } },
  { value = "legendary",   label = "Legendary loot",   kit = { "UI_LEGENDARY_LOOT_TOAST", 63971 } },
  { value = "levelup",     label = "Level up",         kit = { "LEVELUP", "UI_LEVELUP", 888 } },
  { value = "achievement", label = "Achievement",      kit = { "UI_ACHIEVEMENT_TOAST", "ACHIEVEMENT_TOAST", "ACHIEVEMENT_MENU_OPEN", 857 } },
  { value = "mission",     label = "Mission complete", kit = { "UI_GARRISON_TOAST_MISSION_COMPLETE", 44294 } },
  { value = "questdone",   label = "Quest complete",   kit = { "IG_QUEST_LIST_COMPLETE", 878 } },
  { value = "questfailed", label = "Quest failed",     kit = { "IG_QUEST_FAILED", "IG_QUEST_LOG_ABANDON_QUEST", 846 } },
  { value = "questlog",    label = "Quest log",        kit = { "IG_QUEST_LOG_OPEN", "IG_QUEST_LIST_OPEN", 844, 875 } },
  { value = "raidwarning", label = "Raid warning",     kit = { "RAID_WARNING", 8959 } },
  { value = "readycheck",  label = "Ready check",      kit = { "READY_CHECK", 8960 } },
  { value = "whisper",     label = "Whisper",          kit = { "TELL_MESSAGE", 3081 } },
  { value = "mapping",     label = "Map ping",         kit = { "MAP_PING", 3175 } },
  { value = "alarm",       label = "Alarm clock",      kit = { "ALARM_CLOCK_WARNING_3", "ALARM_CLOCK_WARNING_2", 12889 } },
  { value = "pvpqueue",    label = "PvP queue",        kit = { "PVP_THROUGH_QUEUE", 8458 } },
  { value = "auction",     label = "Auction house",    kit = { "AUCTION_WINDOW_OPEN", 5864 } },
  { value = "petbattle",   label = "Pet battle",       kit = { "UI_PET_BATTLE_START", "UI_PET_BATTLES_START", "IG_QUEST_LIST_OPEN", 875 } },
  { value = "toybox",      label = "Toy box",          kit = { "UI_TOYBOX_TABS", "IG_BACKPACK_OPEN", 862 } },
  { value = "none",        label = "No sound",         kit = {} },
}
UI.SOUND_OPTIONS = SOUND_OPTIONS
local soundByValue = {}
for _, o in ipairs(SOUND_OPTIONS) do soundByValue[o.value] = o end

-- what each kind of alert plays unless the player picks something else
UI.DEFAULT_SOUNDS = {
  loot = "epic", level = "levelup", ach = "achievement", mount = "legendary",
  pet = "petbattle", toy = "toybox", death = "petbattle", kill = "pvpqueue", catchup = "questlog",
}
UI.SOUND_ORDER = { "loot", "level", "ach", "mount", "pet", "toy", "death", "kill", "catchup" }
UI.SOUND_KIND_LABELS = {
  loot = "Gear & items", level = "Levels", ach = "Achievements", mount = "Mounts",
  pet = "Battle pets", toy = "Toys", death = "Deaths", kill = "World PvP kills", catchup = "While you were away",
}
local SUMMARY_SOUND = { "IG_MAINMENU_OPTION_CHECKBOX_ON", 856 } -- "+N more" and pings, not configurable

-- Which sound a kind of alert is set to (a SOUND_OPTIONS value)
function UI:SoundFor(kind)
  local s = ns.db and ns.db.settings and ns.db.settings.sounds
  local v = s and s[kind]
  if v and soundByValue[v] then return v end
  return self.DEFAULT_SOUNDS[kind] or "epic"
end

function UI:SoundLabel(value)
  local o = soundByValue[value]
  return o and o.label or tostring(value)
end

-- The first sound in a list the client can play: its id and a name for it
local function resolveSound(kit)
  for _, c in ipairs(kit) do
    if type(c) == "number" then return c, "#" .. c end
    local id = SOUNDKIT and SOUNDKIT[c]
    if id then return id, c end
  end
  return nil
end

---------------------------------------------------------------------------
-- Volume. Addons can't set a sound's volume directly, so:
--   100%       plays on the Master channel, exactly like the game's own sounds.
--   below 100% plays on the Dialog channel with that channel's volume lowered
--              for a few seconds, then put back.
--   above 100% plays 2 or 3 copies at once, which is louder.
-- The original Dialog volume is saved first (soundRestore) so it's put back
-- on the next login even if the game closes mid-sound.
---------------------------------------------------------------------------
local VOL_CHANNEL, VOL_CVAR, VOL_HOLD = "Dialog", "Sound_DialogVolume", 4
local volActive = 0

local function cvar(name)
  local ok, v = pcall(GetCVar, name)
  return ok and v or nil
end

local function setCVar(name, value)
  pcall(SetCVar, name, value)
end

local function canLowerVolume()
  return GetCVar ~= nil and SetCVar ~= nil and cvar(VOL_CVAR) ~= nil and cvar("Sound_EnableDialog") ~= "0"
end

local function restoreVolume()
  local db = ns.db
  if db and db.soundRestore then
    setCVar(VOL_CVAR, db.soundRestore)
    db.soundRestore = nil
  end
end
UI.RestoreVolume = restoreVolume

local function lowerVolumeFor(level)
  if volActive == 0 then ns.db.soundRestore = ns.db.soundRestore or cvar(VOL_CVAR) end
  volActive = volActive + 1
  setCVar(VOL_CVAR, format("%.2f", level))
  C_Timer.After(VOL_HOLD, function()
    volActive = math.max(0, volActive - 1)
    if volActive == 0 then restoreVolume() end
  end)
end

-- How a volume (percent) is played: number of copies, per-copy level, channel.
function UI:VolumePlan(pct)
  local scale = (pct or 100) / 100
  if scale <= 0 then return 0 end
  local copies = math.max(1, math.min(3, math.ceil(scale - 0.001)))
  local level = scale / copies
  if level > 0.99 then return copies, 1, "Master" end
  if not canLowerVolume() then return copies, 1, "Master" end -- can't go quieter, play normally
  return copies, level, VOL_CHANNEL
end

-- Play a list of sound kit candidates at a volume; returns the name played
local function playKit(kit, pct)
  local id, name = resolveSound(kit)
  if not id then return nil end
  local copies, level, channel = UI:VolumePlan(pct)
  if copies == 0 then return name end
  if channel ~= "Master" then lowerVolumeFor(level) end
  for _ = 1, copies do pcall(PlaySound, id, channel) end
  return name
end

-- Play one of the palette's sounds (settings preview). Returns what was played.
function UI:PlaySoundOption(value, pct)
  local o = soundByValue[value]
  if not o then return nil end
  if value == "none" then return "none" end
  return playKit(o.kit, pct or ns.db.settings.soundVolume or 100)
end

function UI:PlayKindSound(kind, pct)
  pct = pct or ns.db.settings.soundVolume or 100
  if kind == "summary" then return playKit(SUMMARY_SOUND, pct) end
  return self:PlaySoundOption(self:SoundFor(kind), pct)
end

-- force: show it even with pop-ups turned off (the sample when moving them)
function UI:QueueToast(data, force)
  if not (ns.db.settings.toasts or force) then return end
  -- don't let a burst bury the screen: fold the backlog into one summary
  if #toastQueue >= 4 then
    local last = toastQueue[#toastQueue]
    if last.summary then
      last.count = last.count + 1
      if data.demo then last.demoCount = (last.demoCount or 0) + 1 end
    else
      toastQueue[#toastQueue + 1] = { summary = true, count = 1, demoCount = data.demo and 1 or 0, icon = ns.ICONS.ach, title = "Friend Feed", q = 4, sound = "summary" }
    end
  else
    toastQueue[#toastQueue + 1] = data
  end
  if not self.toast:IsShown() then self:NextToast() end
end

function UI:NextToast()
  local data = table.remove(toastQueue, 1)
  if not data then return end
  if data.summary then data.body = "+" .. data.count .. " more - check your feed" end

  local t = self.toast
  local r, g, b
  if data.color then r, g, b = data.color[1], data.color[2], data.color[3] else r, g, b = qualityRGB(data.q) end
  setGradient(t.glow, r, g, b, 0.45)
  t.iconBorder:SetColorTexture(r, g, b, 1)
  t.icon:SetTexture(data.icon)
  t.who:SetText(data.title)
  t.body:SetText(data.body)
  t.sub:SetText(data.sub or "")
  t.target = data.target
  t.ev = data.ev
  t.sample = data.sample
  t.demo = data.demo and true or false
  t.fly, t.flyChecked, t.flying = nil, nil, false
  -- a third line when we know where it came from
  t.who:ClearAllPoints()
  t.who:SetPoint("TOPLEFT", t, "TOPLEFT", 58, data.sub and -8 or -10)
  t.who:SetPoint("RIGHT", -10, 0)

  -- where the player put pop-ups, else under the feed; as wide as the feed
  -- (LayoutFeed keeps it matched on resize)
  t.ap = self:ToastAnchor()
  t:SetSize(self:ToastWidth(), data.sub and 68 or 56)

  local big = (data.q or 0) >= 4
  if big then t.pulse:Play() else t.pulse:Stop() end
  if data.sound then self:PlayKindSound(data.sound) end

  t.elapsed = 0
  t.hover = false
  t:SetAlpha(0)
  t:Show()
end

-- "While you were away" summary, batched over a few seconds
local catchup = { total = 0, who = {} } -- who: friend id -> display label

function UI:QueueCatchup(ev)
  catchup.total = catchup.total + 1
  if ev.demo then catchup.demo = (catchup.demo or 0) + 1 end
  catchup.who[ev.id] = ns.Label(ev)
  if not catchup.timer then
    catchup.timer = C_Timer.NewTimer(3, function() UI:FlushCatchup() end)
  end
end

function UI:FlushCatchup()
  catchup.timer = nil
  if catchup.total <= 0 then -- everything in it was the demo, now gone
    catchup.total, catchup.demo = 0, 0
    wipe(catchup.who)
    return
  end
  local names, onlyID = {}, nil
  for id, label in pairs(catchup.who) do names[#names + 1] = label; onlyID = id end
  table.sort(names)
  local who
  if #names == 1 then who = names[1]
  elseif #names == 2 then who = names[1] .. " and " .. names[2]
  else who = names[1] .. " and " .. (#names - 1) .. " others" end
  local body = who .. ": " .. catchup.total .. " new milestone" .. (catchup.total == 1 and "" or "s")
  local allDemo = (catchup.demo or 0) >= catchup.total
  catchup.total, catchup.demo = 0, 0
  wipe(catchup.who)
  catchup.timer = nil
  self:QueueToast({
    demo = allDemo or nil,
    icon = "Interface\\Icons\\INV_Misc_Book_09",
    title = "While you were away",
    body = body,
    q = 4,
    sound = "catchup",
    target = (#names == 1) and onlyID or nil,
  })
end

---------------------------------------------------------------------------
-- Friend history window
---------------------------------------------------------------------------
local HIST_TOP = 84 -- where the history rows start
local SEEN_ALPHA = 0.5 -- history rows you've already seen

function UI:CreateDetails()
  local d = CreateFrame("Frame", "FriendFeedDetails", UIParent, "BackdropTemplate")
  d:SetSize(DETAIL_W, DETAIL_H)
  d:SetPoint("CENTER")
  d:SetFrameStrata("DIALOG")
  d:SetToplevel(true)
  d:Hide()
  skin(d, 0.96)
  makeDraggable(d)
  tinsert(UISpecialFrames, "FriendFeedDetails") -- Esc closes it

  d.logo = d:CreateTexture(nil, "ARTWORK")
  d.logo:SetSize(26, 26)
  d.logo:SetPoint("TOPLEFT", 6, -4)
  d.logo:SetTexture(ns.LOGO_SMALL)

  d.title = d:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  d.title:SetPoint("TOPLEFT", 34, -11)
  d.title:SetText("Friend Feed")

  local close = CreateFrame("Button", nil, d, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)

  local div = d:CreateTexture(nil, "ARTWORK")
  div:SetColorTexture(0.45, 0.36, 0.2, 0.9)
  div:SetWidth(1)
  div:SetPoint("TOPLEFT", 12 + LIST_W, -40)
  div:SetPoint("BOTTOMLEFT", 12 + LIST_W, 10)

  -- left: friends
  d.listOffset = 0
  d.friendRows = {}
  local listRows = math.floor((DETAIL_H - 52) / LIST_ROW_H)
  for i = 1, listRows do
    local b = CreateFrame("Button", nil, d)
    b:SetSize(LIST_W - 6, LIST_ROW_H)
    b:SetPoint("TOPLEFT", 10, -40 - (i - 1) * LIST_ROW_H)
    b.sel = b:CreateTexture(nil, "BACKGROUND")
    b.sel:SetAllPoints()
    b.sel:SetColorTexture(1, 0.82, 0, 0.16)
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.07)
    b.badge = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.badge:SetPoint("RIGHT", -4, 0)
    b.name = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.name:SetPoint("LEFT", 6, 0)
    b.name:SetPoint("RIGHT", b.badge, "LEFT", -4, 0)
    b.name:SetJustifyH("LEFT")
    b.name:SetWordWrap(false)
    b:SetScript("OnClick", function(self) UI:OpenDetails(self.id) end)
    b:EnableMouseWheel(true)
    b:SetScript("OnMouseWheel", function(_, delta) d.listOffset = d.listOffset - delta; UI:RefreshDetails() end)
    d.friendRows[i] = b
  end

  -- right: history
  local rx = 24 + LIST_W
  d.rx = rx
  d.header = d:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  d.header:SetPoint("TOPLEFT", rx, -42)
  d.sub = d:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  d.sub:SetPoint("TOPLEFT", d.header, "BOTTOMLEFT", 0, -4)

  d.histOffset = 0
  d.histRows = {}

  d.empty = d:CreateFontString(nil, "OVERLAY", "GameFontDisable")
  d.empty:SetPoint("TOPLEFT", rx, -96)
  d.empty:SetText("Nothing here yet.")

  d:SetScript("OnHide", function(self) ns:MarkRead(self.selected or nil); UI:RequestRefresh() end)
  self.details = d
  self:LayoutDetails()
end

-- History rows for the current row style, created on demand.
function UI:LayoutDetails()
  local d = self.details
  if not d then return end
  local st = detailsStyle()
  local rowH = st.row
  local n = math.floor((DETAIL_H - HIST_TOP - 12) / rowH)
  for i = #d.histRows + 1, n do
    local r = CreateRow(d, st)
    r:EnableMouseWheel(true)
    r:SetScript("OnMouseWheel", function(_, delta) d.histOffset = d.histOffset - delta * 3; UI:RefreshDetails() end)
    d.histRows[i] = r
  end
  for i, r in ipairs(d.histRows) do
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", d.rx - 4, -HIST_TOP - (i - 1) * rowH)
    r:SetPoint("TOPRIGHT", -10, -HIST_TOP - (i - 1) * rowH)
    if i > n then r:Hide() end
  end
  d.numRows = n
end

-- One entry per friend (Battle.net account), labelled with the character
-- they were last seen on, e.g. "Grommash (RP-PvP)".
function UI:FriendSummaries()
  local by, order = {}, {}
  for _, e in ipairs(ns.db.log) do
    if not e.self then
      local s = by[e.id]
      if not s then
        s = { id = e.id, count = 0, new = 0, last = 0 }
        by[e.id] = s
        order[#order + 1] = s
      end
      s.count = s.count + 1
      if not ns:IsSeen(e) then s.new = s.new + 1 end
      if e.t >= s.last then s.last = e.t; s.label = ns.Label(e) end
    end
  end
  table.sort(order, function(a, b)
    if (a.new > 0) ~= (b.new > 0) then return a.new > 0 end
    return a.last > b.last
  end)
  return order
end

function UI:RefreshDetails()
  local d = self.details
  if not d or not d:IsShown() then return end
  local sel = d.selected or nil -- false = All friends

  local all = { label = "All friends", count = 0, new = 0 }
  local entries = { all }
  local selectedLabel
  for _, s in ipairs(self:FriendSummaries()) do
    all.count = all.count + s.count
    all.new = all.new + s.new
    entries[#entries + 1] = s
    if s.id == sel then selectedLabel = s.label end
  end

  d.listOffset = math.max(0, math.min(d.listOffset, #entries - #d.friendRows))
  for i, b in ipairs(d.friendRows) do
    local s = entries[i + d.listOffset]
    if s then
      b.id = s.id
      b.name:SetText(s.label)
      b.badge:SetText(s.new > 0 and gold(s.new .. " new") or ("|cff888888" .. s.count .. "|r"))
      b.sel:SetShown(s.id == sel)
      b:Show()
    else
      b:Hide()
    end
  end

  -- what arrived since you last looked at this history goes on top, then an
  -- "Already seen" divider, then the rest; seen rows (including ones you
  -- hovered in the feed) are faded
  local fresh, earlier, events, newCount, log = {}, {}, {}, 0, ns.db.log
  for i = #log, 1, -1 do
    local e = log[i]
    if not e.self and (sel == nil or e.id == sel) then
      events[#events + 1] = e
      if ns:SinceLastLook(e) then fresh[#fresh + 1] = e else earlier[#earlier + 1] = e end
      if not ns:IsSeen(e) then newCount = newCount + 1 end
    end
  end
  local hist = {}
  for _, e in ipairs(fresh) do hist[#hist + 1] = e end
  if #fresh > 0 and #earlier > 0 then hist[#hist + 1] = { header = "Already seen", divider = true } end
  for _, e in ipairs(earlier) do hist[#hist + 1] = e end
  d.items = hist
  local rows = d.numRows or #d.histRows
  d.histOffset = math.max(0, math.min(d.histOffset, #hist - rows))
  -- one friend can play several characters, so show names unless they're all the same
  local showNames = sel == nil
  for i = 2, #events do
    if events[i].who ~= events[1].who or events[i].rs ~= events[1].rs then showNames = true; break end
  end
  for i = 1, rows do
    local item = hist[i + d.histOffset]
    local r = d.histRows[i]
    SetRow(r, item, showNames)
    r:SetAlpha((item and not item.header and ns:IsSeen(item)) and SEEN_ALPHA or 1)
  end

  d.header:SetText(sel and (selectedLabel or "Friend") or "All friends")
  local sub = #events .. " milestone" .. (#events == 1 and "" or "s")
  if newCount > 0 then sub = sub .. "   " .. gold(newCount .. " you haven't seen") end
  if #hist > rows then sub = sub .. "   |cff888888(scroll for more)|r" end
  d.sub:SetText(sub)
  d.empty:SetShown(#events == 0)
end

function UI:OpenDetails(who)
  local d = self.details
  who = who or false -- false = All friends
  if d:IsShown() and d.selected ~= who then ns:MarkRead(d.selected or nil) end
  d.selected = who
  d.histOffset = 0
  d:Show()
  self:RefreshDetails()
end

function UI:ToggleDetails()
  if self.details:IsShown() then self.details:Hide() else self:OpenDetails(nil) end
end

---------------------------------------------------------------------------
-- The Friend Feed app: steering players who got the addon on its own
-- (CurseForge, the website zip) to the website. Whether the app is set up
-- comes from Inbox.lua (ns:AppStatus). Players without it, or whose app
-- hasn't synced for days, get a dot on the feed's logo and at most one chat
-- line a week; the logo, Ctrl+click on the minimap button and the chat
-- line's link open a small panel with the address to copy (the game can't
-- open web pages). Plain facts only: never prices or paying.
---------------------------------------------------------------------------
local APP_NUDGE_EVERY = 7 * 86400
local APP_LINK = "addon:FriendFeed:app"

-- the website as a chat link that opens the app panel
function UI:AppLinkText()
  return "|cff8fd0ff|H" .. APP_LINK .. "|h[" .. ns.SITE .. "]|h|r"
end

local function agoText(t)
  local a = ns.Ago(t)
  return a == "now" and "just now" or (a .. " ago")
end

-- One line saying how the app is doing, coloured
function UI:AppStatusText()
  local status, t = ns:AppStatus()
  if status == "connected" then
    return "|cff40ff40The Friend Feed app is connected.|r Last sync " .. agoText(t) .. "."
  elseif status == "stale" then
    return "|cffff9933The Friend Feed app hasn't synced for " .. ns.Ago(t) .. ".|r Make sure it's running; it should start with your computer."
  end
  return "|cff8fd0ffThe Friend Feed app isn't set up on this computer yet.|r"
end

-- Should the logo carry the dot? Not while the app is fine, and not for a
-- week after the player last opened the panel.
function UI:AppDotWanted()
  if ns:AppStatus() == "connected" then return false end
  return ns.Now() - (tonumber(ns.db.appPanelSeenAt) or 0) > APP_NUDGE_EVERY
end

-- The short status under the feed's title
local APP_LINE = {
  connected = "|cff40ff40App connected|r",
  stale = "|cffff9933App not syncing|r",
  none = "|cffff4040App not connected|r",
}
function UI:AppLineText()
  return APP_LINE[(ns:AppStatus())] or APP_LINE.none
end

-- The logo's dot and the status line under the title
function UI:UpdateAppDot()
  local f = self.feed
  if not f then return end
  if f.logoBtn then f.logoBtn.dot:SetShown(self:AppDotWanted()) end
  local sl = f.appLine
  if sl then
    sl.text:SetText(self:AppLineText())
    local ok, w = pcall(sl.text.GetStringWidth, sl.text)
    if ok and type(w) == "number" and w > 0 then sl:SetWidth(w + 2) end
    shadow(sl.text, f.boxless)
  end
end

function UI:AppTooltip(owner)
  GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
  GameTooltip:SetText("Friend Feed app")
  GameTooltip:AddLine(self:AppStatusText(), 1, 1, 1, true)
  if ns:AppStatus() ~= "connected" then
    -- what they're missing, and where to get it
    GameTooltip:AddLine(" ")
    for _, line in ipairs(ns.APP_BENEFITS) do GameTooltip:AddLine("- " .. line, 0.85, 0.85, 0.85, true) end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Get the app at |cffffd200" .. ns.SITE .. "|r", 1, 1, 1)
    GameTooltip:AddLine("Click to copy the address", 0.5, 0.8, 1)
  else
    GameTooltip:AddLine("Click for more about the app", 0.5, 0.8, 1)
  end
  GameTooltip:Show()
end

-- A font string's height once laid out, or a guess where the client can't say yet
local function textHeight(fs, guess)
  local ok, h = pcall(fs.GetStringHeight, fs)
  h = ok and tonumber(h) or nil
  if not h or h <= 0 then return guess end
  return h
end

local APP_W = 320
function UI:CreateAppPanel()
  local p = CreateFrame("Frame", "FriendFeedAppPanel", UIParent, "BackdropTemplate")
  p:SetWidth(APP_W)
  p:SetFrameStrata("DIALOG")
  p:SetToplevel(true)
  p:Hide()
  skin(p, 0.96)
  makeDraggable(p)
  tinsert(UISpecialFrames, "FriendFeedAppPanel") -- Esc closes it
  local inner = APP_W - 24
  local function text(font, w)
    local fs = p:CreateFontString(nil, "OVERLAY", font)
    fs:SetWidth(w or inner)
    fs:SetJustifyH("LEFT")
    return fs
  end

  p.logo = p:CreateTexture(nil, "ARTWORK")
  p.logo:SetSize(26, 26)
  p.logo:SetPoint("TOPLEFT", 8, -6)
  p.logo:SetTexture(ns.LOGO_SMALL)
  p.title = text("GameFontNormalLarge", inner - 50)
  p.title:SetPoint("LEFT", p.logo, "RIGHT", 6, 0)
  p.title:SetText("Never Miss The World's Big Moments")
  local close = CreateFrame("Button", nil, p, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)

  p.status = text("GameFontHighlightSmall")
  p.status:SetPoint("TOPLEFT", 12, -40)
  p.intro = text("GameFontHighlightSmall")
  p.intro:SetPoint("TOPLEFT", p.status, "BOTTOMLEFT", 0, -10)
  p.intro:SetText("The Friend Feed app for Windows and Mac picks up where the game leaves off.")
  p.bullets = {}
  local prev = p.intro
  for i, line in ipairs(ns.APP_BENEFITS) do
    local t = text("GameFontHighlightSmall", inner - 14)
    t:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", i == 1 and 14 or 0, i == 1 and -8 or -5)
    t:SetText(line)
    local dot = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dot:SetPoint("TOPRIGHT", t, "TOPLEFT", -5, 0)
    dot:SetText("|cffffd200\226\128\162|r")
    p.bullets[i] = t
    prev = t
  end
  p.label = text("GameFontNormalSmall")
  p.label:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", -14, -12)
  p.label:SetText("Get the app at")
  local box = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
  box:SetSize(160, 20)
  box:SetPoint("TOPLEFT", p.label, "BOTTOMLEFT", 6, -4)
  box:SetAutoFocus(false)
  box:SetText(ns.SITE)
  box:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
  box:SetScript("OnTextChanged", function(self, byUser)
    if byUser and self:GetText() ~= ns.SITE then self:SetText(ns.SITE); self:HighlightText() end
  end)
  box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  p.box = box
  p.hint = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  p.hint:SetPoint("LEFT", box, "RIGHT", 8, 0)
  p.hint:SetText("click it, then Ctrl+C")

  function p:Fit()
    local h = 40 + textHeight(self.status, 24) + 10 + textHeight(self.intro, 26) + 8
    for _, b in ipairs(self.bullets) do h = h + textHeight(b, 24) + 5 end
    h = h + 12 + textHeight(self.label, 12) + 4 + 20 + 14
    self:SetHeight(h)
  end
  self.appPanel = p
end

function UI:ShowAppPanel()
  local p = self.appPanel
  if not p then return end
  p.status:SetText(self:AppStatusText())
  p:ClearAllPoints()
  if self.feed and self.feed:IsShown() then
    p:SetPoint("TOPLEFT", self.feed, "TOPRIGHT", 6, 0)
  else
    p:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
  end
  p:Fit()
  p:Show()
  ns.db.appPanelSeenAt = ns.Now()
  self:UpdateAppDot()
end

function UI:ToggleAppPanel()
  if self.appPanel and self.appPanel:IsShown() then self.appPanel:Hide() else self:ShowAppPanel() end
end

-- At most once a week, a chat line for players without a working app,
-- with a link that opens the panel. Returns what was printed (for tests).
function UI:MaybeNudgeApp()
  local db = ns.db
  if not db.settings.setupDone then return nil end -- the welcome screen already shows it
  local status, t = ns:AppStatus()
  if status == "connected" then return nil end
  if ns.Now() - (tonumber(db.appNudgeAt) or 0) < APP_NUDGE_EVERY then return nil end
  db.appNudgeAt = ns.Now()
  local link = self:AppLinkText()
  local msg
  if status == "stale" then
    msg = "the Friend Feed app hasn't synced for " .. ns.Ago(t) .. ". Make sure it's running so friends see your moments while you're offline. " .. link
  else
    msg = "see what your friends got up to while you were offline with the Friend Feed app for Windows and Mac: " .. link
  end
  ns.Print(msg)
  return msg
end

-- Clicking the chat line's link opens the panel. Clients route addon links
-- through EventRegistry's "SetItemRef"; older ones through SetItemRef itself.
function UI:OnLinkClicked(link)
  if type(link) == "string" and link:sub(1, #APP_LINK) == APP_LINK then
    self:ShowAppPanel()
    return true
  end
  return false
end
if EventRegistry and EventRegistry.RegisterCallback then
  pcall(EventRegistry.RegisterCallback, EventRegistry, "SetItemRef", function(_, link) UI:OnLinkClicked(link) end, UI)
elseif hooksecurefunc and SetItemRef then
  pcall(hooksecurefunc, "SetItemRef", function(link) UI:OnLinkClicked(link) end)
end

---------------------------------------------------------------------------
-- Wiring
---------------------------------------------------------------------------
function UI:RequestRefresh(flashEv)
  if flashEv then self.pendingFlash = flashEv end
  if self.refreshPending then return end
  self.refreshPending = true
  C_Timer.After(0.05, function()
    self.refreshPending = false
    local fe = self.pendingFlash
    self.pendingFlash = nil
    self:RefreshFeed(fe)
    self:RefreshDetails()
  end)
end

ns:On("DB_READY", function()
  restoreVolume() -- in case the game closed while a quieter sound was playing
  UI:CreateFeed()
  UI:CreateToast()
  UI:CreateToastMover()
  UI:CreateDetails()
  UI:CreateMinimapButton()
  UI:CreateAppPanel()
  UI:UpdateAppDot()
  UI:RequestRefresh()
end)

ns:On("LOGIN", function()
  UI:UpdateAppDot()
  C_Timer.After(15, function() UI:MaybeNudgeApp() end) -- after the login chat has settled
  C_Timer.After(20, function() ns:TellUpdate() end) -- a newer version heard last time
end)

ns:On("LIKES_CHANGED", function() UI:RequestRefresh() end)

-- The demo ended (ns:ClearDemo has already taken its milestones and people
-- out of the log): take it off the screen too. Its pop-ups still waiting,
-- the one showing, its part of a "+N more" and of the "While you were away"
-- batch, the minimap badge's count, and a history window open on a demo friend.
function UI:ClearDemo()
  for i = #toastQueue, 1, -1 do
    local data = toastQueue[i]
    if data.summary then
      data.count = data.count - (data.demoCount or 0)
      data.demoCount = 0
      if data.count <= 0 then table.remove(toastQueue, i) end
    elseif data.demo then
      table.remove(toastQueue, i)
    end
  end
  local t = self.toast
  if t and t:IsShown() and t.demo then
    t:Hide()
    t.pulse:Stop()
    t.fly, t.flyChecked, t.flying, t.demo = nil, nil, false, nil
    self:NextToast()
  end
  -- the "While you were away" batch still being gathered
  if (catchup.demo or 0) > 0 then
    catchup.total = math.max(0, catchup.total - catchup.demo)
    catchup.demo = 0
    for id in pairs(catchup.who) do
      if ns.IsDemoID(id) then catchup.who[id] = nil end
    end
    if catchup.total == 0 and catchup.timer then
      catchup.timer:Cancel()
      catchup.timer = nil
    end
  end
  -- the minimap badge only counts what's still there
  if (self.unseenDemo or 0) > 0 then
    self.unseen = math.max(0, (self.unseen or 0) - self.unseenDemo)
    self.unseenDemo = 0
    self:UpdateMinimapButton()
  end
  -- a history window open on a demo friend goes back to All friends
  local d = self.details
  if d and type(d.selected) == "string" and ns.IsDemoID(d.selected) then
    d.selected = false
    d.histOffset = 0
  end
end

-- someone liked one of your milestones: a pop-up, unless it's turned off in
-- settings (the heart's count shows either way) or they're muted or removed
function UI:LikePopup(ev, from)
  if not ns.db.settings.likePopups then return nil end
  if ns:IsMuted(from.id) or ns:IsRemoved(from.id) then return nil end
  local icon = ns:Describe(ev)
  local data = {
    icon = icon, title = ns.Label(from), body = "liked your " .. ns:LikeWhat(ev),
    color = LIKE_RGB, sound = "summary", ev = ev,
  }
  self:QueueToast(data)
  return data
end
ns:On("LIKED", function(ev, from) UI:LikePopup(ev, from) end)

ns:On("EVENT_ADDED", function(ev, source)
  local isLive = source == "live" or source == "demo" or source == "self"
  -- your own milestones show (pop-up and feed row, so you can see the likes
  -- they get) while "My own milestones" (settings.showSelf) is on
  local wanted = ns:Wants(ev) and (not ev.self or ns.db.settings.showSelf)
  -- a live milestone that gets a pop-up lights its row up when the pop-up
  -- lands on it (UI:Landed); the others flash as soon as they appear
  local toast = isLive and wanted and ns.db.settings.toasts
  UI:RequestRefresh((isLive and not toast) and ev or nil)
  if not wanted then return end
  if ev.self then
    if isLive then UI:QueueToast(UI:ToastFromEvent(ev)) end
    return -- you know about your own: no minimap count, no "while you were away"
  end
  -- feed minimised: the minimap button counts it (and pings, or the pop-up flies in and pings)
  if not (UI.feed and UI.feed:IsShown()) and (isLive or ns:IsNew(ev)) then
    UI:NoteUnseen(ev, not toast)
  end
  if isLive then
    UI:QueueToast(UI:ToastFromEvent(ev))
  elseif (source == "catchup" or source == "inbox") and ns:IsNew(ev) then
    UI:QueueCatchup(ev)
  end
end)

local ef = CreateFrame("Frame")
ef:RegisterEvent("GET_ITEM_INFO_RECEIVED")
ef:SetScript("OnEvent", function() UI:RequestRefresh() end)

-- keep the "5m / 2h" labels current
C_Timer.NewTicker(30, function()
  if UI.feed and UI.feed:IsShown() then UI:RefreshFeed() end
  UI:RefreshDetails()
  UI:UpdateAppDot() -- "App not syncing" once the last sync gets old
end)

-- fade the feed down when it's been quiet, back up when something happens
C_Timer.NewTicker(2, function()
  if UI.feed and UI.feed:IsShown() then
    UI:CheckHover()
    UI:UpdateFeedDim()
  end
end)
