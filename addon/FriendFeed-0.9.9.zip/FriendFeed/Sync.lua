-- Live sharing between friends who are online at the same time.
-- Messages (tab separated):
--   E/C  t  k  v  q  name  who  ruleset  source   E = live milestone, C = catch-up milestone
--   H    since                                    hello: send me what I missed
--   P    version                                  ping: "are you there?" (/ff ping)
--   A    version                                  answer to a ping
--   V    version                                  "a newer version is out" (0.8.6)
--   L    t  k  v  on                              like (on = 1) or unlike (0) one of your milestones (0.8.7)
--   K    t  k  v  count                           how many people liked one of my milestones (0.8.7)
--   F    who  ruleset  t  k  v  on                I liked (1) or unliked (0) this milestone, to all my friends (0.9.5)
--   W    hi  since                                following, live (0.9.8): "I follow you and I'm online; send me what I missed since"
--   W    ok                                       "heard you" (then C catch-up messages follow)
-- "who" and "ruleset" were added in v0.4 (the event may be from one of the
-- sender's other characters). Older senders stop after "name"; the sender's
-- current character is used instead. "source" (v0.7) is where it came from,
-- e.g. "Baron Rivendare, Stratholme"; older senders leave it out.
local _, ns = ...

local Sync = {}
ns.Sync = Sync

local SEP = "\t"
local MAX_NAME = 60
local MAX_SHORT = 24 -- ruleset labels
local MAX_WHO = 48   -- character names: Forever characters have first and last names
local MAX_QUEUE = 300
local CATCHUP_LIMIT = 15
local PING_COOLDOWN = 10 -- seconds between pings shown from the same friend

local queue = {}
local friendChars = {} -- char key ("char:name-realm") -> friend id (BattleTag or the char key)
local bnByGame = {}    -- Battle.net game account ID -> { id, who, rs } for friends online in this game
local bnTargets = {}   -- Battle.net game account IDs to send to
local charTargets = {} -- character names ("Name" or "Name-Realm") to whisper
local lastRefresh = 0
local lastPing = {}    -- friend id -> GetTime() of the last ping we showed
local toldVersion = {} -- friend id -> true once we told them a newer version is out
local whispered = {}   -- lower-case name (no realm) -> GetTime() of my last whisper to them (bounce matching)
local fanOut           -- the follower lane's enqueue (defined with the lane, below)

-- Abuse limits (0.9.8 audit). A modified addon can send anything the game
-- lets it; these keep that from costing the receiver more than a dropped message.
Sync.INCOMING = { max = 60, window = 10 }   -- messages one sender may send us in a window (a table so tests can lift it)
local HELLO_COOLDOWN = 30                    -- seconds between catch-up replies to the same person
local MAX_LIVE_FOLLOWERS = 3000              -- online followers my addon will fan out to
local incoming = {}  -- sender -> { n, since }
local lastHello = {} -- sender id -> GetTime() of their last answered hello

-- true when this sender has sent more than INCOMING.max in INCOMING.window seconds
local function tooMany(sender)
  local now = GetTime()
  local c = incoming[sender]
  if not c or now - c.since > Sync.INCOMING.window then
    c = { n = 0, since = now }
    incoming[sender] = c
  end
  c.n = c.n + 1
  return c.n > Sync.INCOMING.max
end

---------------------------------------------------------------------------
-- Friend lists
---------------------------------------------------------------------------
local function eachGameAccount(i, acc, fn)
  local BN = C_BattleNet
  local n = BN.GetFriendNumGameAccounts and BN.GetFriendNumGameAccounts(i)
  if n and n > 0 and BN.GetFriendGameAccountInfo then
    for j = 1, n do
      local g = BN.GetFriendGameAccountInfo(i, j)
      if g then fn(g) end
    end
  elseif acc.gameAccountInfo then
    fn(acc.gameAccountInfo)
  end
end

function Sync:Refresh(force)
  if not force and GetTime() - lastRefresh < 5 then return end
  lastRefresh = GetTime()
  wipe(friendChars); wipe(bnByGame); wipe(bnTargets); wipe(charTargets)
  local covered = {} -- char keys we already reach over Battle.net

  -- the full Battle.net friend list (online or not) is saved for the companion
  -- app, which uploads it so the server can link friends who list each other
  local connected = BNConnected == nil or BNConnected()
  local tags = connected and {} or nil

  if BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo then
    for i = 1, (BNGetNumFriends()) do
      local acc = C_BattleNet.GetFriendAccountInfo(i)
      if acc then
        local tag = ns.Usable(acc.battleTag) and acc.battleTag or nil
        if tag and tags then tags[tag] = ns.Now() end
        eachGameAccount(i, acc, function(g)
          if g.isOnline and g.clientProgram == BNET_CLIENT_WOW
            and g.wowProjectID == WOW_PROJECT_ID and g.gameAccountID
            and ns.Usable(g.characterName) then
            local realm = ns.Usable(g.realmName) and g.realmName or nil
            local ck = realm and ns.CharKey(g.characterName, realm) or nil
            local id = tag or ck or ("bn:" .. g.gameAccountID)
            bnByGame[g.gameAccountID] = {
              id = id,
              who = g.characterName,
              rs = ns.Ruleset(g.realmDisplayName) or ns.Ruleset(realm),
            }
            -- remember which characters this friend plays (Friends tab)
            ns:NoteCharacter(id, g.characterName, bnByGame[g.gameAccountID].rs)
            bnTargets[#bnTargets + 1] = g.gameAccountID
            if ck then friendChars[ck] = id; covered[ck] = true end
          end
        end)
      end
    end
  end
  if tags and next(tags) and ns.db then
    ns.db.bnFriends = tags
    ns.db.bnFriendsComplete = true
  end

  if C_FriendList and C_FriendList.GetNumFriends then
    for i = 1, C_FriendList.GetNumFriends() do
      local info = C_FriendList.GetFriendInfoByIndex(i)
      if info and ns.Usable(info.name) then
        local ck = ns.CharKey(info.name)
        if not friendChars[ck] then friendChars[ck] = ck end
        if info.connected and not covered[ck] then
          covered[ck] = true
          charTargets[#charTargets + 1] = info.name
        end
      end
    end
  end
end

function Sync:PrintTargets()
  self:Refresh(true)
  ns.Print("Online friends Friend Feed can reach:")
  local any = false
  for gid, f in pairs(bnByGame) do
    any = true
    print("  Battle.net " .. gid .. ": " .. ns.Label(f, true) .. "  id " .. f.id)
  end
  for _, name in ipairs(charTargets) do
    any = true
    local n, realm = ns.SplitName(name)
    print("  Whisper: " .. ns.Label({ who = n, rs = ns.Ruleset(realm) }, true) .. "  id " .. friendChars[ns.CharKey(name)])
  end
  if not any then print("  nobody online right now") end
end

---------------------------------------------------------------------------
-- Sending (throttled, paused only while the game blocks addon messages)
---------------------------------------------------------------------------
-- Live milestones and ping answers jump ahead of catch-up replies, so a
-- friend logging in (up to 15 catch-up messages each) never delays them.
local bulk = {} -- catch-up ("C"), hello ("H"), version ("V") and like ("K", "F") messages
local MAX_TRIES = 10 -- attempts per message when the game says "too fast" or "not now"
local holdTicks = 0  -- ticks to wait after the game refused a message

local function enqueue(kind, target, msg)
  local tag = msg:sub(1, 1)
  -- hellos to people I follow ("W") wait behind live milestones too
  local q = (tag == "C" or tag == "H" or tag == "V" or tag == "K" or tag == "F" or tag == "W") and bulk or queue
  if #queue + #bulk >= MAX_QUEUE then return end
  q[#q + 1] = { kind, target, msg }
end

-- Midnight blocks addon messages during boss encounters (and some instanced
-- content), not in ordinary combat, so only those pause the queue.
local function busy()
  if IsEncounterInProgress and IsEncounterInProgress() then return true end
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown then
    local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
    if ok and locked == true then return true end
  end
  return false
end

-- send results that mean "try again in a moment" (names from Enum.SendAddonMessageResult)
local RETRY = {}
do
  local R = Enum and Enum.SendAddonMessageResult
  if R then
    for _, name in ipairs({ "AddonMessageThrottle", "ChannelThrottle", "AddOnMessageLockdown", "AddonMessageLockdown" }) do
      if R[name] ~= nil then RETRY[R[name]] = true end
    end
  end
end

-- returns true if the game asked us to try again later
local function sendOne(item)
  local kind, target, msg = item[1], item[2], item[3]
  local ok, res
  if kind == "bn" then
    if BNSendGameData then ok, res = pcall(BNSendGameData, target, ns.PREFIX, msg) end
  elseif kind == "w" then
    -- remembered so a "No player named X" right after can be matched to it
    local key = tostring(target or ""):lower()
    whispered[key:match("^(.-)%-") or key] = GetTime()
    ok, res = pcall(C_ChatInfo.SendAddonMessage, ns.PREFIX, msg, "WHISPER", target)
  elseif kind == "guild" then
    ok, res = pcall(C_ChatInfo.SendAddonMessage, ns.PREFIX, msg, "GUILD")
  end
  return ok and res ~= nil and RETRY[res] == true
end

C_Timer.NewTicker(0.3, function()
  if holdTicks > 0 then holdTicks = holdTicks - 1; return end
  local q = (#queue > 0) and queue or bulk
  if #q == 0 or busy() then return end
  local item = table.remove(q, 1)
  if sendOne(item) then
    item.tries = (item.tries or 0) + 1
    if item.tries < MAX_TRIES then table.insert(q, 1, item) end
    holdTicks = 3 -- about a second
  end
end)

local function clean(s, max)
  s = tostring(s or ""):gsub("[\t\r\n]", " ")
  return s:sub(1, max or MAX_NAME)
end

function Sync:Encode(ev, tag)
  local parts = {
    tag or "E", ev.t, ev.k, ev.v or 0, ev.q or 0, clean(ev.n),
    clean(ev.who, MAX_WHO), clean(ev.rs, MAX_SHORT),
  }
  -- where it came from, only when known (keeps messages short)
  if ns.Usable(ev.s) then parts[#parts + 1] = clean(ev.s, ns.MAX_SUB) end
  -- a death carries the player's total deaths as a 10th field (v0.8.4; older
  -- versions ignore it), with an empty source before it if there's none; a
  -- world PvP kill carries lifetime honorable kills the same way (v0.9.1)
  if (ev.k == "death" or ev.k == "kill" or ev.k == "duel") and tonumber(ev.d) then
    if #parts < 9 then parts[#parts + 1] = "" end
    parts[#parts + 1] = math.floor(tonumber(ev.d))
  end
  return table.concat(parts, SEP)
end

-- skipGuild: friends only (greens never go on the guild channel)
function Sync:SendToAll(msg, skipGuild)
  self:Refresh(true)
  for _, id in ipairs(bnTargets) do enqueue("bn", id, msg) end
  for _, name in ipairs(charTargets) do enqueue("w", name, msg) end
  local guild = not skipGuild and ns.db.settings.includeGuild and IsInGuild()
  if guild then enqueue("guild", nil, msg) end
  return #bnTargets + #charTargets, guild
end

-- Green gear is shared with friends only, never with the guild or followers
function Sync.IsGreen(ev)
  return ev.k == "loot" and (tonumber(ev.q) or 0) > 0 and tonumber(ev.q) < 3
end

-- Does this kind of milestone go to my followers? (Following tab: "Send to my followers")
function Sync:ForFollowers(ev)
  local s = ns.db.settings
  if s.followLive == false or Sync.IsGreen(ev) then return false end
  local share = s.followShare
  return not (share and share[ev.k] == false)
end

function Sync:Broadcast(ev)
  local msg = self:Encode(ev, "E")
  self:SendToAll(msg, Sync.IsGreen(ev))
  if self:ForFollowers(ev) then self:SendToFollowers(msg) end
end

---------------------------------------------------------------------------
-- Following, live (0.9.8): the people you follow through the app, by
-- character, on your own ruleset, no friendship needed. The app writes
-- their characters into Inbox.lua (FriendFeedInbox.following[handle].chars);
-- ns:IngestInbox hands them to Sync:SetFollowChars.
--
-- At login your addon whispers each of them "W hi since token". Bounced
-- ("No player named X is currently playing", confirmed on Forever for addon
-- whispers: they're offline) or unanswered: tried again after 1, 2, then
-- every 5 minutes, so someone who logs in after you reaches you within 5.
-- Answered ("W ok"): a hello every 30 minutes keeps you on their list (and
-- puts you back on it after their game crashed); if it bounces they've gone
-- offline and the 1/2/5-minute retries start again. Their addon drops a
-- follower when a whisper to them bounces or after 75 minutes without a
-- hello, remembers its followers across sessions, and at its next login
-- says "W back" once to those seen in the last hour, who answer with their
-- hello. The bounce lines are hidden from chat for names Friend Feed itself
-- just whispered. Hellos go on the background queue, behind friends' live
-- milestones.
--
-- The game supplies the sender's name, so nobody can pose as someone you
-- follow, and nothing passes through a third player. Addon whispers don't
-- cross rulesets, so only characters on yours are spoken to. Followers are
-- sent to on their own lane (FAN_RATE a second: the server put up with 50
-- a second for 20 seconds and kicked a 700 a second burst), so a thousand
-- online followers hear within a minute.
---------------------------------------------------------------------------
local HI_BACKOFF = { 60, 120, 300 } -- seconds before trying an unanswered hello again (the last repeats)
local HI_KEEPALIVE = 30 * 60   -- an answered hello is repeated this often
local FOLLOW_EXPIRE = 75 * 60  -- a follower not heard from for this long is dropped (two and a half missed keepalives)
local BACK_WINDOW = 3600       -- "W back" at login goes to followers seen this recently
local BOUNCE_WINDOW = 10       -- seconds after a whisper in which "No player named X" belongs to it
local FAN_RATE = 20            -- messages a second to followers
local FAN_BURST = 5            -- at most this many in one frame
local liveFollowers = {}       -- whisper target (name as the game gave it) -> GetTime() of their last hi
local heardOk = {}             -- follower -> true once we answered their hi this session
local fan = {}                 -- messages waiting for the follower lane: { "w", target, msg }
local hiState = {}             -- char key I follow -> { step, nextAt, answeredAt }

-- the part of a whisper target the game's "No player named" line will show, for matching
local function bounceKey(name)
  name = tostring(name or ""):lower()
  return (name:match("^(.-)%-") or name)
end
Sync.BounceKey = bounceKey

-- ns.db.follows[ck] = { who, rs, pub = "pub:handle" (from the app), t, ok = last answer, last = newest t heard, manual = true (/ff follow) }

-- the app's list replaces every entry it gave before; /ff follow entries stay
function Sync:SetFollowChars(list)
  local follows = ns.db.follows
  for ck, f in pairs(follows) do if not f.manual then follows[ck] = nil end end
  local mine = ns.Squash(ns.MyRuleset() or "")
  local me = ns.CharKey(ns.PlayerName(), ns.MyRealm())
  local n = 0
  for _, c in ipairs(list or {}) do
    if ns.Usable(c.who) and ns.Usable(c.pub) and ns.Squash(c.rs or "") == mine then
      local ck = ns.CharKey(c.who, ns.MyRealm())
      if ck ~= me and not follows[ck] then
        follows[ck] = { who = c.who, rs = c.rs, pub = c.pub, t = ns.Now() }
        n = n + 1
      end
    end
  end
  return n
end

function Sync:Follow(name)
  name = tostring(name or ""):gsub("%s+", " "):match("^%s*(.-)%s*$")
  if name == "" then return nil end
  local ck = ns.CharKey(name, ns.MyRealm())
  if ck == ns.CharKey(ns.PlayerName(), ns.MyRealm()) then return nil end
  ns.db.follows[ck] = ns.db.follows[ck] or { who = name, rs = ns.MyRuleset(), t = ns.Now(), manual = true }
  local hi = Sync:HiMessage(ck, ns.db.follows[ck])
  if hi then enqueue("w", name, hi) end
  return ck
end

-- The hello for one person I follow: "W hi since token". The token comes
-- from the app (ns.db.liveTokens, per person, keyed by my character); with
-- none for this character there is no hello, since it would go unanswered.
function Sync:HiMessage(ck, f)
  local mine = ns.LiveKey(ns.PlayerName(), ns.MyRuleset())
  local tokens = ns.db.liveTokens and ns.db.liveTokens[f.pub or ck]
  local token = tokens and mine and tokens[mine]
  if not token then return nil end
  return table.concat({ "W", "hi", f.last or 0, token }, SEP)
end

function Sync:Unfollow(name)
  local ck = ns.CharKey(tostring(name or ""), ns.MyRealm())
  local f = ns.db.follows[ck]
  if not f then return false end
  ns.db.follows[ck] = nil
  -- their milestones go with them (a by-name follow's events carry the char key)
  ns:ForgetFollowed(f.pub or ck)
  return true
end

-- Say hello to whoever I follow that is due one (see the notes above):
-- not yet answered and past its backoff, or answered long enough ago for
-- the keepalive. Run at login and every 15 seconds. Returns how many went.
function Sync:SayHi()
  local n, now = 0, GetTime()
  for ck, f in pairs(ns.db.follows) do
    local st = hiState[ck]
    if not st then st = { step = 0, nextAt = 0 }; hiState[ck] = st end
    local due
    if st.answeredAt then
      due = now - st.answeredAt >= HI_KEEPALIVE
    else
      due = now >= st.nextAt
    end
    if due then
      local hi = Sync:HiMessage(ck, f)
      if hi then
        enqueue("w", f.who, hi)
        n = n + 1
        if st.answeredAt then
          st.answeredAt = now -- keepalive sent; a bounce will reopen the backoff
        else
          st.step = math.min(st.step + 1, #HI_BACKOFF)
          st.nextAt = now + HI_BACKOFF[st.step]
        end
      end
    end
  end
  return n
end

-- They answered (or told us they're back): stop, or start over
local function hiAnswered(ck) local st = hiState[ck] or {}; st.answeredAt = GetTime(); hiState[ck] = st end
local function hiAgainNow(ck) hiState[ck] = { step = 0, nextAt = 0 } end
Sync.HiState = hiState -- for tests

-- followers known to be online (and forget anyone quiet for FOLLOW_EXPIRE)
function Sync:LiveFollowers()
  local now, list = GetTime(), {}
  for name, t in pairs(liveFollowers) do
    if now - t > FOLLOW_EXPIRE then
      liveFollowers[name] = nil
      if ns.db.followersLive then ns.db.followersLive[name] = nil end
    else
      list[#list + 1] = name
    end
  end
  table.sort(list)
  return list
end

-- At login: "I'm back" once to the followers I had online last time (kept
-- in the saved variables as they come and go); they answer with a hello.
function Sync:AnnounceBack()
  local saved = ns.db.followersLive or {}
  ns.db.followersLive = {}
  local n, now = 0, ns.Now()
  for name, t in pairs(saved) do
    if type(name) == "string" and now - (tonumber(t) or 0) < BACK_WINDOW and n < MAX_LIVE_FOLLOWERS then
      fanOut(name, "W" .. SEP .. "back")
      n = n + 1
    end
  end
  return n
end

-- "No player named X is currently playing" after one of my whispers: X is
-- offline. A follower is dropped (and whatever was waiting for them); a
-- person I follow goes back to the backoff. Returns true when it was one
-- of mine (so the line can be hidden).
local NOT_FOUND = {}
local function addNotFound(fmt)
  if type(fmt) ~= "string" then return end
  local p = fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%%%%s", "(.+)")
  NOT_FOUND[#NOT_FOUND + 1] = "^" .. p .. "$"
end
addNotFound(ERR_CHAT_PLAYER_NOT_FOUND_S) -- the client's own wording (any language)
addNotFound("No player named '%s' is currently playing.")
function Sync:Bounced(text)
  if type(text) ~= "string" or ns.IsSecret(text) then return false end
  local name
  for _, pat in ipairs(NOT_FOUND) do
    name = text:match(pat)
    if name then break end
  end
  if not name then return false end
  local key = bounceKey(name)
  local at = whispered[key]
  if not at or GetTime() - at > BOUNCE_WINDOW then return false end
  for target in pairs(liveFollowers) do
    if bounceKey(target) == key then
      liveFollowers[target] = nil
      heardOk[target] = nil
      if ns.db.followersLive then ns.db.followersLive[target] = nil end
    end
  end
  for i = #fan, 1, -1 do if bounceKey(fan[i][2]) == key then table.remove(fan, i) end end
  for ck, f in pairs(ns.db.follows) do
    if bounceKey(f.who) == key and hiState[ck] and hiState[ck].answeredAt then
      hiState[ck] = { step = 1, nextAt = GetTime() + HI_BACKOFF[1] }
    end
  end
  return true
end

-- the follower lane: FAN_RATE messages a second, paused like the main queue
local fanFrame = CreateFrame("Frame")
local fanBudget = 0
fanFrame:Hide()
fanFrame:SetScript("OnUpdate", function(self, dt)
  if #fan == 0 then self:Hide(); fanBudget = 0; return end
  if busy() then return end
  fanBudget = math.min(fanBudget + (tonumber(dt) or 0) * FAN_RATE, FAN_BURST)
  while fanBudget >= 1 and #fan > 0 do
    fanBudget = fanBudget - 1
    local item = table.remove(fan, 1)
    if sendOne(item) then
      item.tries = (item.tries or 0) + 1
      if item.tries < MAX_TRIES then table.insert(fan, 1, item) end
      fanBudget = -FAN_RATE -- the game said "too fast": a second's pause
      break
    end
  end
end)

fanOut = function(target, msg)
  if #fan >= MAX_QUEUE * 10 then return end
  fan[#fan + 1] = { "w", target, msg }
  fanFrame:Show()
end
Sync.FanQueue, Sync.FanFrame = fan, fanFrame -- for tests

function Sync:SendToFollowers(msg)
  local list = self:LiveFollowers()
  for _, name in ipairs(list) do fanOut(name, msg) end
  Sync.followerSends = (Sync.followerSends or 0) + #list
  return #list
end

-- a follower just said hi: what they missed since then (newest last)
function Sync:CatchUpFollower(target, since)
  local mine, log = {}, ns.db.log
  for i = #log, 1, -1 do
    local e = log[i]
    if e.self and (e.t or 0) > since and not e.demo and Sync:ForFollowers(e) then
      mine[#mine + 1] = e
      if #mine >= CATCHUP_LIMIT then break end
    end
  end
  for i = #mine, 1, -1 do fanOut(target, Sync:Encode(mine[i], "C")) end
  return #mine
end

function Sync:PrintFollowing()
  local any = false
  for ck, f in pairs(ns.db.follows) do
    any = true
    print("  " .. f.who .. (f.pub and (" (" .. (ns.db.following[f.pub] or f.pub) .. ")") or " (by name)")
      .. (f.ok and ("  |cff00ff00heard back " .. ns.Ago(f.ok) .. " ago|r") or "  |cff888888(no answer yet)|r") .. "  id " .. ck)
  end
  if not any then print("  Nobody you follow has a character on this ruleset. Follow people in the Friend Feed app.") end
  local live = self:LiveFollowers()
  if #live > 0 then
    ns.Print(#live .. " follower" .. (#live == 1 and "" or "s") .. " online now: " .. table.concat(live, ", "))
  else
    ns.Print("No followers have said hello this session.")
  end
  print(("  This session: %d milestone whispers sent to followers, %d milestones heard from people you follow."):format(
    Sync.followerSends or 0, Sync.followedHeard or 0))
  print("  What shows from them follows the Following tab in settings; the history window (book icon) shows everything.")
end

function Sync:Hello()
  -- the version rides along so friends on an older one hear there's an update
  self:SendToAll(table.concat({ "H", ns.prevLogout or 0, ns.VERSION }, SEP))
end

-- /ff ping: check the connection to every online friend who has the addon
function Sync:Ping()
  local count, guild = self:SendToAll(table.concat({ "P", ns.VERSION }, SEP))
  if count == 0 and not guild then
    ns.Print("Nobody to ping. None of your friends are online in this game right now.")
    return
  end
  local where = count .. " online friend" .. (count == 1 and "" or "s")
  if guild then where = where .. " and your guild" end
  ns.Print("Pinging " .. where .. ". Friends with Friend Feed will answer in a few seconds.")
  if busy() then ns.Print("Addon messages are paused during this fight, so the ping will go out afterwards.") end
end

---------------------------------------------------------------------------
-- Likes
---------------------------------------------------------------------------
local LIKE_OUT_MAX = 200
local LIKE_OUT_DAYS = 7 -- a like still waiting after a week is dropped
local COUNT_DELAY = 2   -- seconds: several likes in a row go out as one count

-- How to reach one friend right now: "bn", gameAccountID or "w", name; nil when offline
function Sync:RouteTo(id, who)
  if not id then return nil end
  self:Refresh()
  for gid, f in pairs(bnByGame) do
    if f.id == id then return "bn", gid end
  end
  for _, name in ipairs(charTargets) do
    if friendChars[ns.CharKey(name)] == id then return "w", name end
  end
  -- a guildmate who isn't a friend: by whisper, they're on your ruleset
  if ns.db.settings.includeGuild and ns:IsGuildmate(id) and ns.Usable(who) then return "w", who end
  return nil
end

local function likeMsg(t, k, v, on)
  return table.concat({ "L", t, k, v, on and 1 or 0 }, SEP)
end

-- Send a like (or unlike) to the milestone's owner, or keep it for when
-- they're next online. Returns true if it went out now.
-- It also goes to all my friends online (0.9.5): the ones who have the
-- milestone count it straight away, and the owner hears it even when the
-- direct message can't find them.
function Sync:SendLike(ev, on)
  if type(ev.id) ~= "string" or ev.id:find("^pub:") then return false end -- followed through the app: offline only
  self:SendToAll(table.concat({
    "F", clean(ev.who, MAX_WHO), clean(ev.rs, MAX_SHORT), ev.t, ev.k, ev.v, on and 1 or 0,
  }, SEP))
  local out = ns.db.likeOut
  for i = #out, 1, -1 do -- only the latest click on a milestone counts
    local o = out[i]
    if o.id == ev.id and o.t == ev.t and o.k == ev.k and o.v == ev.v then table.remove(out, i) end
  end
  local kind, target = self:RouteTo(ev.id, ev.who)
  if kind then
    enqueue(kind, target, likeMsg(ev.t, ev.k, ev.v, on))
    return true
  end
  if #out < LIKE_OUT_MAX then
    out[#out + 1] = { id = ev.id, who = ev.who, t = ev.t, k = ev.k, v = ev.v, on = on, at = ns.Now() }
  end
  return false
end

-- Send the likes waiting for this friend (or everyone, id nil) who's online now
function Sync:FlushLikes(id)
  local out = ns.db.likeOut
  if #out == 0 then return end
  local keep, now = {}, ns.Now()
  for _, o in ipairs(out) do
    if now - (tonumber(o.at) or now) <= LIKE_OUT_DAYS * 86400 then
      local kind, target
      if id == nil or o.id == id then kind, target = self:RouteTo(o.id, o.who) end
      if kind then enqueue(kind, target, likeMsg(o.t, o.k, o.v, o.on)) else keep[#keep + 1] = o end
    end
  end
  ns.db.likeOut = keep
end

local function countMsg(ev)
  return table.concat({ "K", ev.t, ev.k, ev.v, ns:LikeCount(ev) }, SEP)
end

-- Tell everyone how many people liked one of my milestones (a moment later,
-- so a few likes in a row are one message)
local countDue = {}
function Sync:QueueCount(ev)
  if not (ev and ev.uid) or countDue[ev.uid] then return end
  countDue[ev.uid] = true
  C_Timer.After(COUNT_DELAY, function()
    countDue[ev.uid] = nil
    Sync:SendToAll(countMsg(ev))
  end)
end

---------------------------------------------------------------------------
-- Receiving
---------------------------------------------------------------------------
local function split(s)
  local out = {}
  for part in (s .. SEP):gmatch("(.-)" .. SEP) do out[#out + 1] = part end
  return out
end

local function field(s) return (s and s ~= "") and s or nil end

-- from = { id, who, rs }: the friend who sent this and their current character
local function handle(text, from, replyKind, replyTarget)
  if type(text) ~= "string" or ns.IsSecret(text) then return end
  local p = split(text)
  local tag = p[1]
  -- someone who isn't a friend, guildmate or followed: only the follow
  -- handshake is heard from them
  if from.stranger and tag ~= "W" then return end
  if tag == "W" then
    if p[2] == "hi" then
      -- a follower is online: whisper them my milestones until they go quiet,
      -- starting with what they missed (unless live following is off for me)
      if ns.db.settings.followLive == false then return end
      -- the token: made by the server from my secret (which only my app has)
      -- and the sender's character as the game names it. No app on my side,
      -- or no token on theirs, and the hello goes unanswered: that is how
      -- live following stays a feature of the app, not of a changed addon.
      local secret = ns.db.liveSecret
      if not ns.Usable(secret) then return end
      local expected = ns.LiveToken(secret, ns.LiveKey(from.who, from.rs))
      if not expected or p[4] ~= expected then return end
      local first = not liveFollowers[replyTarget]
      if first then
        -- a flood of hellos from made-up characters can't make my addon send without end
        local n = 0
        for _ in pairs(liveFollowers) do n = n + 1 end
        if n >= MAX_LIVE_FOLLOWERS then
          local oldest, when = nil, math.huge
          for name, t in pairs(liveFollowers) do if t < when then oldest, when = name, t end end
          if oldest then liveFollowers[oldest] = nil end
        end
      end
      liveFollowers[replyTarget] = GetTime()
      -- kept across sessions, so my next login can tell them I'm back
      ns.db.followersLive = ns.db.followersLive or {}
      ns.db.followersLive[replyTarget] = ns.Now()
      if not heardOk[replyTarget] then
        heardOk[replyTarget] = true
        fanOut(replyTarget, "W" .. SEP .. "ok")
      end
      if first then Sync:CatchUpFollower(replyTarget, tonumber(p[3]) or 0) end
    elseif p[2] == "ok" then
      -- someone I follow heard me: no more hellos until they go offline
      local ck = from.followKey
      local fl = ck and ns.db.follows[ck]
      if fl then
        hiAnswered(ck)
        local first = not fl.ok
        fl.ok = ns.Now()
        if first then ns.Print(ns.Label(from, true) .. " has Friend Feed. You'll see their milestones live while you're both online.") end
      end
    elseif p[2] == "back" then
      -- someone I follow just logged in and had me as a follower: say hello now
      local ck = from.followKey
      if ck and ns.db.follows[ck] then
        hiAgainNow(ck)
        Sync:SayHi()
      end
    end
    return
  end
  if tag == "E" or tag == "C" then
    -- greens are for friends only (an older sender may still send them on the guild channel)
    if (from.guild or from.follow) and p[3] == "loot" and (tonumber(p[5]) or 0) > 0 and tonumber(p[5]) < 3 then return end
    if from.follow then
      Sync.followedHeard = (Sync.followedHeard or 0) + 1
      -- the next hello asks for what came after this
      local fl = ns.db.follows[from.followKey or ""]
      if fl then fl.last = math.max(fl.last or 0, tonumber(p[2]) or 0) end
    end
    local q = tonumber(p[5])
    local who = field(p[7]) or from.who
    local rs = field(p[8])
    if not rs and who == from.who then rs = from.rs end
    ns:AddEvent({
      id = from.id, who = who, rs = rs,
      t = tonumber(p[2]), k = p[3], v = tonumber(p[4]),
      q = (q and q > 0) and q or nil,
      n = field(p[6]), s = field(p[9]), d = tonumber(p[10]),
      guild = from.guild or nil, -- from a guildmate who isn't a friend: the Guild tab's settings apply
      follow = from.follow or nil, -- from someone you follow (test build)
    }, tag == "E" and "live" or "catchup")
  elseif tag == "H" then
    -- a friend just came online: send them our own milestones they missed
    -- (a hello every second from the same person would be a flood; one answer per HELLO_COOLDOWN)
    local lastH = lastHello[from.id]
    local answer = not (lastH and GetTime() - lastH < HELLO_COOLDOWN)
    if answer then lastHello[from.id] = GetTime() end
    local since = tonumber(p[2]) or 0
    local theirs = field(p[3]) -- nil from versions before 0.8.6
    ns:NoteVersion(theirs)
    -- they're on an older version: tell them ours, once per session
    if not toldVersion[from.id] and (not theirs or ns.NewerVersion(ns.VERSION, theirs)) then
      toldVersion[from.id] = true
      enqueue(replyKind, replyTarget, table.concat({ "V", ns.VERSION }, SEP))
    end
    local log = ns.db.log
    if answer then
      local mine = {}
      for i = #log, 1, -1 do
        local e = log[i]
        if e.self and e.t > since then
          mine[#mine + 1] = e
          if #mine >= CATCHUP_LIMIT then break end
        end
      end
      for i = #mine, 1, -1 do enqueue(replyKind, replyTarget, Sync:Encode(mine[i], "C")) end
      -- and the like counts that changed since then (after the milestones, so they exist)
      local counts = 0
      for i = #log, 1, -1 do
        local e = log[i]
        local list = e.self and e.uid and ns.db.likes[e.uid]
        if list then
          local newest = 0
          for _, l in pairs(list) do newest = math.max(newest, tonumber(l.t) or 0) end
          if newest > since then
            enqueue(replyKind, replyTarget, countMsg(e))
            counts = counts + 1
            if counts >= CATCHUP_LIMIT then break end
          end
        end
      end
    end
    -- they're online now: likes we kept for them go out (cheap and bounded, so always)
    Sync:FlushLikes(from.id)
  elseif tag == "L" then
    -- a friend liked (or unliked) one of my milestones
    local t, v, k = tonumber(p[2]), tonumber(p[4]), field(p[3])
    if t and v and k then
      local ev = ns:ReceiveLike(from, t, k, v, p[5] ~= "0")
      if ev then Sync:QueueCount(ev) end
    end
  elseif tag == "K" then
    local t, v, k = tonumber(p[2]), tonumber(p[4]), field(p[3])
    if t and v and k then ns:SetLikeCount(from.id, t, k, v, p[5], from.who, from.rs) end
  elseif tag == "F" then
    -- a friend liked (or unliked) a milestone: mine, or one I have too
    local who, t, k, v = field(p[2]), tonumber(p[4]), field(p[5]), tonumber(p[6])
    if who and t and k and v then
      local ev = ns:HearLike(from, who, field(p[3]), t, k, v, p[7] ~= "0")
      if ev and ev.self then Sync:QueueCount(ev) end
    end
  elseif tag == "V" then
    ns:NoteVersion(field(p[2]))
  elseif tag == "P" then
    ns:NoteVersion(field(p[2]))
    -- answer every ping, but only pop up once per friend every few seconds
    enqueue(replyKind, replyTarget, table.concat({ "A", ns.VERSION }, SEP))
    local now = GetTime()
    if now - (lastPing[from.id] or -PING_COOLDOWN) < PING_COOLDOWN then return end
    lastPing[from.id] = now
    ns.Print(ns.Label(from, true) .. " pinged you. Friend Feed is connected.")
    if ns.UI then
      ns.UI:QueueToast({
        icon = "Interface\\Icons\\INV_Misc_Note_02", title = ns.Label(from),
        body = "pinged you. Friend Feed is connected!", q = 2, sound = "summary", target = from.id,
      })
    end
  elseif tag == "A" then
    local version = field(p[2]) or "?"
    ns:NoteVersion(version)
    local note = (version ~= ns.VERSION) and ("  |cffff8040(they have v" .. version .. ", you have v" .. ns.VERSION .. ")|r") or ""
    ns.Print("|cff00ff00Connected:|r " .. ns.Label(from, true) .. " has Friend Feed v" .. version .. note)
  end
end

local function isGuildMember(fullName)
  if not IsInGuild() then return false end
  if C_GuildInfo and C_GuildInfo.MemberExistsByName then
    local ok, yes = pcall(C_GuildInfo.MemberExistsByName, fullName)
    if ok and yes then return true end
    local short = Ambiguate(fullName, "short")
    ok, yes = pcall(C_GuildInfo.MemberExistsByName, short)
    return ok and yes or false
  end
  return false
end

local function lookupChar(ck)
  Sync:Refresh()
  if not friendChars[ck] then Sync:Refresh(true) end -- they may have just been added or come online
  return friendChars[ck]
end

local function lookupGame(gameAccountID)
  Sync:Refresh()
  if not bnByGame[gameAccountID] then Sync:Refresh(true) end
  return bnByGame[gameAccountID]
end

local f = CreateFrame("Frame")
f:SetScript("OnEvent", function(_, event, ...)
  if event == "CHAT_MSG_ADDON" then
    local prefix, text, channel, sender = ...
    if ns.IsSecret(prefix) or ns.IsSecret(sender) or prefix ~= ns.PREFIX then return end
    Sync.lastSender = sender -- shown by /ff names, to see how the game writes two-part names
    local name, realm = ns.SplitName(sender)
    local ck = ns.CharKey(name, realm)
    local from = { who = name, rs = ns.Ruleset(realm) }
    if ck == ns.CharKey(ns.PlayerName(), ns.MyRealm()) then return end -- my own
    if tooMany(sender) then return end
    if channel == "WHISPER" then
      from.id = lookupChar(ck)
      -- someone you follow: same ruleset, no friendship needed; their events
      -- carry the app's pub: id so they merge with the server's copy. Checked
      -- before the guild, so a followed guildmate gets your normal alerts,
      -- not the quiet guild ones (a death and a green went unannounced that way)
      local fl = not from.id and ns.db.follows[ck]
      if fl then
        from.id = fl.pub or ck
        from.follow = true
        from.followKey = ck
      end
      -- guildmates answer a guild "hello" by whisper, so accept them too when guild sharing is on
      if not from.id and ns.db.settings.includeGuild and isGuildMember(sender) then
        from.id = ck
        from.guild = true
      end
      -- anyone else: only the follow handshake is heard
      if not from.id then
        local tag = text:sub(1, 1)
        if tag ~= "W" then return end
        from.id = ck
        from.stranger = true
      end
      if from.guild then ns:NoteGuildmate(from.id) end
      handle(text, from, "w", sender)
    elseif channel == "GUILD" and ns.db.settings.includeGuild then
      -- a friend who is also in the guild keeps their friend settings, and so
      -- does someone you follow (their events get the pub: id either way)
      local fl = not friendChars[ck] and ns.db.follows[ck]
      if fl then
        from.id = fl.pub or ck
        from.follow = true
        from.followKey = ck
      else
        from.id = friendChars[ck] or ck
        from.guild = not friendChars[ck]
      end
      if from.guild then ns:NoteGuildmate(from.id) end
      handle(text, from, "w", sender)
    end
  elseif event == "BN_CHAT_MSG_ADDON" then
    local prefix, text, _, senderID = ...
    if ns.IsSecret(prefix) or prefix ~= ns.PREFIX then return end
    if tooMany("bn:" .. tostring(senderID)) then return end
    local from = lookupGame(senderID)
    if not from then
      -- not in our list (another game version?): fall back to the character
      local info = C_BattleNet.GetGameAccountInfoByID(senderID)
      if not (info and ns.Usable(info.characterName)) then return end
      local realm = ns.Usable(info.realmName) and info.realmName or nil
      from = {
        id = realm and ns.CharKey(info.characterName, realm) or ("bn:" .. senderID),
        who = info.characterName,
        rs = ns.Ruleset(info.realmDisplayName) or ns.Ruleset(realm),
      }
    end
    handle(text, from, "bn", senderID)
  end
end)

-- "No player named X is currently playing" after one of my whispers: handled
-- (Sync:Bounced) and kept out of the chat window. Anything else is left alone.
local bounceFrame = CreateFrame("Frame")
bounceFrame:SetScript("OnEvent", function(_, _, text) Sync:Bounced(text) end)
local function hideBounce(_, _, text)
  if type(text) ~= "string" or ns.IsSecret(text) then return false end
  for _, pat in ipairs(NOT_FOUND) do
    local name = text:match(pat)
    if name then
      local at = whispered[bounceKey(name)]
      return at ~= nil and GetTime() - at <= BOUNCE_WINDOW
    end
  end
  return false
end
Sync.HideBounce = hideBounce -- for tests

ns:On("DB_READY", function()
  C_ChatInfo.RegisterAddonMessagePrefix(ns.PREFIX)
  f:RegisterEvent("CHAT_MSG_ADDON")
  f:RegisterEvent("BN_CHAT_MSG_ADDON")
  pcall(bounceFrame.RegisterEvent, bounceFrame, "CHAT_MSG_SYSTEM")
  local addFilter = ChatFrame_AddMessageEventFilter or (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter)
  if addFilter then pcall(addFilter, "CHAT_MSG_SYSTEM", hideBounce) end
end)

ns:On("LOGIN", function()
  C_Timer.After(8, function() Sync:Hello() end)
  C_Timer.After(10, function() Sync:FlushLikes() end) -- likes for friends who were already online
  -- the people I follow: one hello each (then backoff for the offline ones),
  -- and my own followers from last time hear I'm back
  C_Timer.After(12, function() Sync:SayHi() end)
  C_Timer.After(15, function() Sync:AnnounceBack() end)
  C_Timer.NewTicker(15, function() Sync:SayHi() end)
end)
