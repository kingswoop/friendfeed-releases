# Friend Feed (v0.8.5) for WoW Forever

A live feed of your friends' rare loot, levels, mounts, pets, toys, achievements and deaths, with animated pop-ups and a scrollable history per friend. Each row also says where it came from: the boss or mob that dropped it, the vendor, the quest, the zone they levelled in, or what killed them.

## Install
1. Copy the `FriendFeed` folder into your WoW Forever install's `Interface/AddOns/` folder.
2. Restart the game and make sure Friend Feed is ticked in the AddOns list on the character screen.
3. If it shows as "out of date", tick "Load out of date AddOns" or change `## Interface:` in `FriendFeed.toc` to the current Forever number.

The `dev` folder is for development only and isn't needed in the game; leave it out when copying (it can hold a large `node_modules`).

## Sharing with friends
In the `dev` folder, run `npm run zip`. It runs the tests, then builds `dev/dist/FriendFeed-<version>.zip` with only the files the game needs. Send that zip; your friends unzip it into `Interface/AddOns` so they end up with `Interface/AddOns/FriendFeed/FriendFeed.toc`. Then log in together and type `/ff ping` to check you can see each other.

## Developing
In the `dev` folder, run `npm install` once, then `npm test`. That syntax-checks every `.lua` file as Lua 5.1 and runs simulation tests with stand-in WoW functions. Passing tests don't guarantee it works in game, but they catch typos and logic slips before you log in.

## Try it
- `/ff demo` loads fake friends so you can see the feed, a "While you were away" pop-up and three live pop-ups. The demo ends by itself after 3 minutes, is never saved, and its fake friends never appear in the Friends tab.
- `/ff cleardemo` removes them again.

## Settings
The first time you log in, a welcome screen asks what you share and what you want to be notified about. Open it again with `/ff settings` (or the gear on the feed, or Esc > Options > AddOns > Friend Feed). It has four tabs.

**Your friends need Friend Feed too.** Right under the title, both the welcome screen and the settings window say it plainly: you only see milestones from friends and guildmates who have the addon installed, so send it to the people you play with. `/ff ping` shows who already has it.

**Never Miss The World's Big Moments: stay updated while you're offline.** A panel down the right of the welcome screen and the settings window, always open, explains what the Friend Feed app adds: a one-line intro, then the benefits as bullet points (see what friends did while you were offline, your moments reach friends after you log off, follow streamers or go public, quick to set up and optional). Last, in its own blue section, it says your login stays with Battle.net: you sign in on Battle.net's own page, Friend Feed never sees or stores your password, and it keeps only your BattleTag, your characters' names, your milestones and your friend list. The address (friendfeedwow.com) is in a box you can click and copy with Ctrl+C, since the game can't open links. Nothing in game mentions prices or paying.

**General**
- **What I share with friends:** the minimum gear quality your friends see from you, whether your deaths are shared, and whether to also share with your guild. Everything starts switched on (Green+ gear, deaths, guild); untick anything you'd rather keep to yourself. Levels, achievements, mounts, pets and toys are always shared. Deaths in battlegrounds and arenas are never shared.
- **Notify me about:** gear and items (off, or green / blue / purple / orange and above), levels (off, max level only, every 10, or every level), and achievements, mounts, battle pets, toys and deaths on or off each.
- **Pop-ups & feed:** animated pop-ups, show/lock the feed, **Dim the feed when it's quiet** (fades it down after two minutes with nothing new; hovering or a new milestone brings it back), **Feed look** (see The feed below), **Feed background** (how solid the feed's box is, from see-through to 100%; it changes as you drag), plus **Clear feed** and **Delete all history**.

**Sounds**
- **Volume**: 0 to 300% of the game's volume, 100% by default, 0 turns sounds off; it plays a preview when you let go.
- A sound for each kind of alert (gear, levels, achievements, mounts, pets, toys, deaths, "While you were away"), picked from a list of the game's own sounds: epic and legendary loot, level up, achievement, mission complete, quest complete/failed, quest log, raid warning, ready check, whisper, map ping, alarm clock, PvP queue, auction house, pet battle, toy box, or no sound. Click a name to choose (right click steps back through the list), **Play** to hear it, **Test all** to hear every kind in turn, **Back to defaults** to reset.

**Guild**
- **Share with my guild** (the same switch as on the General tab) sends your milestones to guildmates who have Friend Feed and accepts theirs, live. Both of you need it on.
- **Notify me about, from guildmates:** its own set of choices for guildmates who aren't on your friends list. Out of the box only purple-and-better gear and level 60 are on; achievements, mounts, pets, toys and deaths are off until you turn them on. Guildmates who are also your friends keep your Friends settings.
- **Guildmates:** everyone whose milestones have reached you over the guild channel, with the same untick-to-mute and Default/Custom buttons as the Friends tab.

**Friends**
- Every friend Friend Feed knows about: your Battle.net and character friends, people you follow, and anyone whose activity you've seen. Untick someone to stop their pop-ups, sounds and feed rows. **All on** / **All off** for everyone at once.
- Battle.net friends show the character they were last seen on, with their BattleTag underneath and "+2" if they have more. Hover a row to see every character. Characters are picked up when a friend is online in Forever while you are, or when their activity reaches you, so a friend you've never overlapped with shows just their BattleTag at first.
- Each person has a **Default** / **Custom** button. Click it to choose what you hear about from that person only: gear quality, levels, achievements, mounts, pets, toys and deaths. For example, every level from your best friend, but only deaths from a streamer. "Use my normal settings" puts them back on the General tab's choices.

**Following streamers and other players** (needs the Friend Feed app)
- Anyone can turn on a public profile in the app and pick a public name. Others can then search for them in the app and follow them, without being friends. Their BattleTag stays hidden.
- Followed players show in the Friends tab with their public name, e.g. "StreamerName (Thrall Hellscream, RP-PvP)", and you can give them custom alerts like anyone else.
- Their milestones arrive through the app, so you see them after the app syncs and you log in or `/reload`. They aren't live pop-ups the moment they happen, the way online friends are.
- The website's **People** pages (friendfeedwow.com/people) list every public profile with follower and following counts, who they were last seen playing, their stream link and their latest milestones, searchable by handle. Go public in the app to be on it.

Filters and the Friends tab apply to the feed and pop-ups. The friend history window always shows everything.

**About the volume:** WoW doesn't let addons set a sound's volume directly. At 100% sounds play exactly like the game's own. Above 100%, Friend Feed plays two or three copies at once, which is louder. Below 100%, it plays on the game's Dialog channel and lowers that channel for a few seconds, then puts it back. NPC voices playing at that moment are quieter too. If you turned Dialog sound off in the game's options, quieter settings play at normal volume instead.

**Sharing with your guild:** when it's on, your milestones also go to everyone in your guild who has Friend Feed, and you see theirs, even if they aren't on your friends list. Guildmates appear on the Guild tab once you've seen their activity, with their own alert settings (purple+ gear and level 60 to start), so a big guild doesn't flood you. It's live only: offline sync through the app is for Battle.net friends.

## The feed
- Each row has the friend's name and what they did, with a grey line underneath saying where it came from: "Baron Rivendare, Stratholme", "Bought from Katie Hunter", "Quest: Rise, Thunderfury!", "From the mailbox", "Crafted", the zone they levelled in, or "Killed by Son of Arugal" for a death. Mounts, pets and achievements fall back to the game's own journal text when the sender didn't know. The icon frame, the bar on the left and the tint are the item's quality colour (or gold for levels, purple for mounts, red for deaths). A yellow dot marks milestones that are new since you were last online; it clears once you've viewed that friend's history.
- **Message a friend:** each row has a small speech bubble next to the time. Click it to open a whisper to that player with the item or achievement already linked and a short starter like "Gz on [Thunderfury]!". Edit it and press Enter to send, or Escape to cancel. Battle.net friends get a Battle.net whisper, which works even if they're on another ruleset.
- **Filter bar:** a row of small toggles under the feed's title. The icons hide or show gear, levels, achievements, mounts, pets, toys and deaths; the tabard hides or shows guildmates (friends in your guild aren't affected); the green, blue, purple and orange squares hide or show gear of that quality. Left click to toggle, right click to show everything again. It says how many rows it's hiding. It only filters the feed: pop-ups follow your Notify settings and More details always shows everything. Turn the bar off with **Filter bar on the feed** in settings.
- When nothing new has happened for two minutes the feed fades down so it stays out of the way; it comes back when something lands or you hover over it. Turn this off in settings if you prefer it always bright.
- **Feed look** (General tab) picks one of four: **Cards** (the default: two lines, where it came from underneath), **Compact** (one line, the source in the tooltip), **Chat** (no box or border, rows sit on the world like chat text and older rows fade until you hover) or **Timeline** (rows grouped under Today, Yesterday and earlier days, with a marker per row). The history window uses card rows (or compact ones) whatever the feed's look.
- Drag the feed by its body to move it, and drag the grip in the bottom right corner to make it bigger or smaller. It remembers its size and position. **Lock feed size & position** in settings (or `/ff lock`) stops both and hides the grip.
- The feed's header has three buttons on the right: **Clear**, **More details** (book icon) and **Settings** (gear).
- **More details** opens the friend history window.
- **Clear** empties the feed. Nothing is deleted: the full history stays in More details.
- Pop-ups sit under the feed and are always exactly as wide as it, even if you resize the feed while one is showing. When one has had its few seconds it swoops down into the feed row that now shows that milestone, and the row flashes.
- Each kind of milestone has its own sound, chosen on the Sounds tab. Out of the box, gear uses the epic loot sound, mounts the legendary one, deaths the quest failed sound. The list of sounds is the `SOUND_OPTIONS` table in `UI.lua`.

## Commands
- `/ff settings` choose what you get notified about; `/ff setup` re-runs the welcome screen
- `/ff` show the feed or minimise it into the minimap button (drag it anywhere, resize it from the bottom right corner; `/ff lock` to pin its size and position)
- `/ff minimap` show or hide the minimap button (drag the button round the minimap's edge to move it)
- `/ff popups` drag pop-ups to wherever you want them on screen
- `/ff details` open the friend history window (or click any feed row / pop-up; Ctrl+click previews gear, mounts and pets on your character, Shift+click links it in chat)
- `/ff minq 2|3|4|5` minimum loot quality you share: uncommon, rare, epic or legendary (default uncommon, so green and up)
- `/ff toasts` turn pop-ups on or off
- `/ff sound` mute or unmute sounds; `/ff sound 150` sets the volume (0 to 300%)
- `/ff self` include your own milestones in the feed
- `/ff guild` also share with your guild
- `/ff clear` clear the feed (history is kept)
- `/ff reset confirm` delete all saved history
- `/ff ping` check which online friends have Friend Feed working: each one pops up "pinged you" on their screen and answers, and you get a "Connected" line in chat per friend (with a warning if their version differs)
- `/ff whoami`, `/ff friends` show how you and your online friends are identified (BattleTag, character, ruleset)
- `/ff names` shows how the game reports first and last names (target another player first to include theirs)
- `/ff blocked` if the game warned that "FriendFeed has been blocked from an action only available to the Blizzard UI", this shows which call it was and where it came from, so it can be fixed. Clicking Ignore on that warning is safe; the addon keeps working. When the refused call was asking for a game event, Friend Feed remembers that and never asks for it again, so the warning shows once.

## How it works today
- Each player's copy records their own milestones and sends them to friends who are online (Battle.net friends and character friends) using hidden addon messages.
- When you log in, it asks online friends for anything you missed since you last logged off.
- Messages pause during combat and boss encounters and send afterwards.
- Friends are grouped by Battle.net account, so all of a friend's characters share one history, and two friends with the same character name on different rulesets stay apart. Names show their ruleset, e.g. "Grommash (RP-PvP)". Character-only friends (no Battle.net link) are grouped by name and realm.
- Where a milestone came from is worked out on the sender's side from what the game knows at that moment (the loot window plus the corpse under your mouse or your target for drops, the open vendor, mailbox, trade or quest window for "You receive item", the enemy you were targeting for deaths) and sent along with it. Forever doesn't let addons read the combat log, so a death only names a killer when you still had it targeted. Older versions of the addon simply don't send it.

## For the companion app (next step)
- **Upload:** each outbox entry has `id` (the player's BattleTag, or `char:name-realm` if Battle.net was unavailable), `who` (character), `rs` (ruleset) and, when known, `s` (where it came from). The server should trust the signed-in Battle.net account, not `id`. Read `FriendFeedDB.outbox` from `WTF/Account/<ACCOUNT>/SavedVariables/FriendFeed.lua` after the game closes or the player reloads.
- **Download:** overwrite `Interface/AddOns/FriendFeed/Inbox.lua` with friends' events in the format shown in that file (version 2: `id` = friend's BattleTag, plus `who` and `rs`). The addon reads it on login and on every `/reload`.
- Set `ackedUntil` to the newest uploaded timestamp so the addon trims its outbox.

## Disclaimer
Friend Feed is a fan project. It is not made by, affiliated with or endorsed by Blizzard Entertainment. World of Warcraft and Battle.net are trademarks of Blizzard Entertainment, Inc. The addon is free and provided as is, with no warranty: game updates may break it at any time, and you use it at your own risk under Blizzard's own rules for addons. The optional app and the offline history service are covered by the terms at https://friendfeedwow.com/terms (one-time fee, no refunds, and the service may change or stop at any time).
