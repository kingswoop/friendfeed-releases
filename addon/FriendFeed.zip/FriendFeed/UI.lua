-- The feed, pop-up toasts and the friend history window.
local _, ns = ...

local UI = {}
ns.UI = UI

-- Four looks for the feed (settings.feedStyle):
--   comfortable  "Cards": two lines, where it came from underneath, colour tints
--   compact      one-liners
--   chat         no box or border, rows sit on the world like chat text, older rows fade
--   timeline     grouped under Today / Yesterday / ... with a rail and a marker per row
local STYLES = {
  comfortable = { row = 42, icon = 30, maxRows = 20, lines = 2, box = true },
  compact     = { row = 24, icon = 18, maxRows = 30, lines = 1, box = true },
  chat        = { row = 44, icon = 26, maxRows = 20, lines = 2, box = false, fade = true },
  timeline    = { row = 40, icon = 24, maxRows = 22, lines = 2, box = true, headers = true, rail = true },
}
UI.STYLE_ORDER = { "comfortable", "compact", "chat", "timeline" }
UI.STYLE_LABELS = { comfortable = "Cards", compact = "Compact", chat = "Chat", timeline = "Timeline" }
local FEED_W, FEED_ROWS = 380, 6             -- default size (wide enough for first + last names)
local FEED_HEAD, FEED_FOOT = 34, 10          -- space above and below the rows (the grip sits in the footer)
local FEED_MIN_W, FEED_MAX_W = 300, 700 -- 300 fits the whole filter bar
local FEED_MIN_ROWS = 3
local DIM_AFTER, DIM_ALPHA = 120, 0.45       -- fade the feed after this many quiet seconds, to this alpha
local DETAIL_W, DETAIL_H = 640, 470
local LIST_W, LIST_ROW_H = 180, 22
local TOAST_W = 320
local T_IN, T_HOLD, T_OUT = 0.35, 4.5, 0.6

local function style()
  local s = ns.db and ns.db.settings and ns.db.settings.feedStyle
  return STYLES[s] or STYLES.comfortable
end
-- the history window only knows boxed rows: compact stays compact, the rest are cards
local function detailsStyle()
  return style() == STYLES.compact and STYLES.compact or STYLES.comfortable
end
function UI:RowHeight() return style().row end
-- The filter bar (small toggles for kinds and qualities) sits under the header
local FILTER_H = 22
local function filterBarOn()
  local s = ns.db and ns.db.settings
  return not (s and s.filterBar == false)
end
-- space above the rows: the header, plus the filter bar when it's on
local function headH() return FEED_HEAD + (filterBarOn() and FILTER_H or 0) end
local function feedHeight(rows) return headH() + rows * style().row + FEED_FOOT end

local BACKDROP = {
  bgFile = "Interface\\Buttons\\WHITE8x8",
  edgeFile = "Interface\\Buttons\\WHITE8x8",
  edgeSize = 1,
}

local function skin(frame, alpha)
  frame:SetBackdrop(BACKDROP)
  frame:SetBackdropColor(0.03, 0.03, 0.05, alpha or 0.8)
  frame:SetBackdropBorderColor(0.45, 0.36, 0.2, 0.85)
end

local function qualityRGB(q)
  if q and C_Item and C_Item.GetItemQualityColor then
    local r, g, b = C_Item.GetItemQualityColor(q)
    if r then return r, g, b end
  end
  return 1, 0.82, 0
end

-- the colour a milestone glows in: item quality for loot, otherwise its kind
local KIND_RGB = {
  level = { 1, 0.82, 0 }, ach = { 1, 0.9, 0.35 }, mount = { 0.64, 0.21, 0.93 },
  pet = { 0.12, 1, 0 }, toy = { 0, 0.44, 0.87 }, death = { 1, 0.32, 0.32 },
}
local function accentRGB(kind, q)
  if kind ~= "loot" and KIND_RGB[kind] then
    local c = KIND_RGB[kind]
    return c[1], c[2], c[3]
  end
  return qualityRGB(q)
end

-- a horizontal fade from a colour to nothing (older clients: a flat tint)
local function setGradient(tex, r, g, b, a)
  if CreateColor and tex.SetGradient then
    local ok = pcall(tex.SetGradient, tex, "HORIZONTAL", CreateColor(r, g, b, a), CreateColor(r, g, b, 0))
    if ok then return end
  end
  tex:SetColorTexture(r, g, b, a * 0.5)
end

local function gold(s) return "|cffffd200" .. tostring(s) .. "|r" end

-- chat-style rows have no box behind them, so their text gets a shadow
local function shadow(fs, on)
  pcall(fs.SetShadowColor, fs, 0, 0, 0, on and 1 or 0)
  pcall(fs.SetShadowOffset, fs, on and 1 or 0, on and -1 or 0)
end

-- A slightly bigger grey font for the "where from" line, made once. Falls back
-- to the game's small grey font if fonts can't be created here.
local SUB_FONT = "GameFontDisableSmall"
do
  local ok = pcall(function()
    local f = CreateFont("FriendFeedSubFont")
    f:CopyFontObject(GameFontHighlightSmall)
    local path, _, flags = f:GetFont()
    if path then f:SetFont(path, 11, flags or "") end
    f:SetTextColor(0.66, 0.66, 0.66)
    SUB_FONT = "FriendFeedSubFont"
  end)
  if not ok then SUB_FONT = "GameFontDisableSmall" end
end

local function makeDraggable(frame, saveKey)
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:SetClampedToScreen(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self)
    if not (saveKey and ns.db.settings.locked) then self:StartMoving() end
  end)
  frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    if saveKey then
      local p, _, rp, x, y = self:GetPoint()
      ns.db.settings[saveKey] = { p, rp, x, y }
    end
  end)
end

---------------------------------------------------------------------------
-- Days, for the timeline look's "Today / Yesterday" headers
---------------------------------------------------------------------------
local function dayOf(t)
  local ok, d = pcall(date, "*t", t)
  if ok and type(d) == "table" and d.year and d.yday then return d.year * 1000 + d.yday end
  return math.floor((t or 0) / 86400)
end

local function dayLabel(t, now)
  local d = dayOf(t)
  if d == dayOf(now) then return "Today" end
  if d == dayOf(now - 86400) then return "Yesterday" end
  local ok, s = pcall(date, "%a %d %b", t)
  if ok and type(s) == "string" and s ~= "" then return s end
  return "Earlier"
end

---------------------------------------------------------------------------
-- Rows (shared by the feed and the history window)
---------------------------------------------------------------------------
local function Row_OnEnter(self)
  UI:Touch()
  local ev = self.ev
  if not ev then return end
  GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
  local shown = false
  if ev.k == "loot" and ev.v > 0 then
    shown = pcall(GameTooltip.SetItemByID, GameTooltip, ev.v)
  end
  local _, desc, _, sub = ns:Describe(ev)
  if not shown then
    GameTooltip:SetText(ns.Label(ev, true) .. " " .. desc, 1, 1, 1, 1, true)
  end
  if sub then GameTooltip:AddLine(sub, 0.75, 0.75, 0.75, true) end
  GameTooltip:AddLine(" ")
  GameTooltip:AddLine(ns.Label(ev) .. "  -  " .. date("%a %d %b, %I:%M %p", ev.t), 0.7, 0.7, 0.7)
  GameTooltip:AddLine("Click to see " .. ev.who .. "'s history", 0.5, 0.8, 1)
  GameTooltip:Show()
end

---------------------------------------------------------------------------
-- Messaging a friend about a milestone: the speech bubble on each row opens
-- a whisper (a Battle.net whisper for Battle.net friends, which also works
-- across rulesets) with a short starter and the item or achievement linked.
-- Nothing is sent: the player edits it and presses Enter.
---------------------------------------------------------------------------
local MSG_ICON = "Interface\\GossipFrame\\GossipGossipIcon"

-- The first of these chat functions the client has ("Table.func" or "global")
local function chatFn(...)
  for i = 1, select("#", ...) do
    local path = select(i, ...)
    local t, k = path:match("^([%w_]+)%.([%w_]+)$")
    local fn
    if t then fn = type(_G[t]) == "table" and _G[t][k] or nil else fn = _G[path] end
    if type(fn) == "function" then return fn end
  end
  return nil
end

local function itemLink(id)
  if not (id and id > 0 and C_Item and C_Item.GetItemInfo) then return nil end
  local _, link = C_Item.GetItemInfo(id)
  return ns.Usable(link) and link or nil
end

-- "Gz on [Thunderfury]!" and the like, with a real link where the game has one
function UI:WhisperText(ev)
  local k, v = ev.k, tonumber(ev.v) or 0
  local plain = ev.n and ("[" .. ev.n .. "]") or nil
  if k == "loot" or k == "toy" then
    return "Gz on " .. (itemLink(v) or plain or "that") .. "!"
  elseif k == "ach" then
    local ok, link = false, nil
    if GetAchievementLink and v > 0 then ok, link = pcall(GetAchievementLink, v) end
    return "Gz on " .. ((ok and ns.Usable(link)) and link or plain or "the achievement") .. "!"
  elseif k == "level" then
    return "Gz on level " .. v .. "!"
  elseif k == "mount" then
    local name = ev.n
    if v > 0 and C_MountJournal and C_MountJournal.GetMountInfoByID then
      local ok, n = pcall(C_MountJournal.GetMountInfoByID, v)
      if ok and ns.Usable(n) then name = n end
    end
    return name and ("Gz on the " .. name .. "!") or "Gz on the new mount!"
  elseif k == "pet" then
    return ev.n and ("Gz on the " .. ev.n .. "!") or "Gz on the new pet!"
  elseif k == "death" then
    return v > 0 and ("Oof, RIP at level " .. v .. ".") or "Oof, RIP."
  end
  return ""
end

-- A Battle.net friend's account name (what Battle.net whispers need), by BattleTag
function UI:BnAccountFor(id)
  if type(id) ~= "string" or not id:find("#", 1, true) or id:find(":", 1, true) then return nil end
  if not (BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo) then return nil end
  for i = 1, (BNGetNumFriends()) do
    local acc = C_BattleNet.GetFriendAccountInfo(i)
    if acc and acc.battleTag == id and acc.accountName then return acc.accountName end
  end
  return nil
end

-- Open a whisper to the person behind a milestone, starter text included
function UI:MessageAbout(ev)
  if not ev or ev.self then return false end
  local text = self:WhisperText(ev)
  local opened = false
  local acc = self:BnAccountFor(ev.id)
  if acc then
    local tell = chatFn("ChatFrameUtil.SendBNetTell", "ChatFrame_SendBNetTell")
    if tell then opened = pcall(tell, acc) end
  end
  if not opened and ns.Usable(ev.who) then
    local tell = chatFn("ChatFrameUtil.SendTell", "ChatFrame_SendTell")
    if tell then opened = pcall(tell, ev.who) end
  end
  if not opened then
    -- last resort: a /w line in the chat box
    local open = chatFn("ChatFrameUtil.OpenChat", "ChatFrame_OpenChat")
    if open and ns.Usable(ev.who) then return (pcall(open, "/w " .. ev.who .. " " .. text)) end
    return false
  end
  if text ~= "" then
    local active = chatFn("ChatFrameUtil.GetActiveWindow", "ChatEdit_GetActiveWindow")
    local ok, eb = false, nil
    if active then ok, eb = pcall(active) end
    if ok and type(eb) == "table" and eb.Insert then pcall(eb.Insert, eb, text) end
  end
  return true
end

local function MsgButton_OnEnter(self)
  self:SetAlpha(1)
  UI:Touch()
  local ev = self.row.ev
  if not ev then return end
  local name = ns.NameParts(ev)
  GameTooltip:SetOwner(self, "ANCHOR_LEFT")
  GameTooltip:SetText("Message " .. tostring(name))
  GameTooltip:AddLine("Opens a whisper with this linked, ready for you to send.", 1, 1, 1, true)
  GameTooltip:Show()
end

local function Row_OnLeave(self)
  GameTooltip_Hide()
  -- chat look: older rows fade again once the mouse has left the feed
  C_Timer.After(0.3, function() UI:CheckHover() end)
end

local function CreateRow(parent, st)
  local row = CreateFrame("Button", nil, parent)

  -- soft tint in the milestone's colour, fading out to the right
  row.bg = row:CreateTexture(nil, "BACKGROUND")
  row.bg:SetPoint("TOPLEFT", 0, -1)
  row.bg:SetPoint("BOTTOMRIGHT", 0, 1)
  row.bg:SetColorTexture(1, 1, 1, 1) -- a gradient needs something to shade

  -- bright flash when a milestone lands in the feed
  row.flash = row:CreateTexture(nil, "BACKGROUND", nil, 1)
  row.flash:SetAllPoints()
  row.flash:SetAlpha(0)
  local ag = row.flash:CreateAnimationGroup()
  local a = ag:CreateAnimation("Alpha")
  a:SetFromAlpha(1); a:SetToAlpha(0); a:SetDuration(1.8); a:SetSmoothing("OUT")
  row.flashAnim = ag

  -- thin bar on the left in the milestone's colour
  row.accent = row:CreateTexture(nil, "ARTWORK")
  row.accent:SetWidth(3)
  row.accent:SetPoint("TOPLEFT", 0, -3)
  row.accent:SetPoint("BOTTOMLEFT", 0, 3)

  -- timeline look: a rail down the left with a diamond per row
  row.rail = row:CreateTexture(nil, "ARTWORK")
  row.rail:SetWidth(2)
  row.rail:SetPoint("TOP", row, "TOPLEFT", 16, 0)
  row.rail:SetPoint("BOTTOM", row, "BOTTOMLEFT", 16, 0)
  row.rail:SetColorTexture(1, 1, 1, 0.08)
  row.diamond = row:CreateTexture(nil, "OVERLAY")
  row.diamond:SetSize(7, 7)
  row.diamond:SetPoint("CENTER", row, "LEFT", 16, 0)
  row.diamond:SetColorTexture(1, 1, 1, 1)
  pcall(row.diamond.SetRotation, row.diamond, math.rad(45))

  row.iconBorder = row:CreateTexture(nil, "BORDER")
  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  row.iconBorder:SetPoint("TOPLEFT", row.icon, -1, 1)
  row.iconBorder:SetPoint("BOTTOMRIGHT", row.icon, 1, -1)

  row.time = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")

  -- speech bubble: whisper this player about it, with the milestone linked
  row.msg = CreateFrame("Button", nil, row)
  row.msg:SetSize(14, 14)
  row.msg:SetPoint("RIGHT", row.time, "LEFT", -4, 0)
  row.msg.row = row
  row.msg.tex = row.msg:CreateTexture(nil, "ARTWORK")
  row.msg.tex:SetAllPoints()
  row.msg.tex:SetTexture(MSG_ICON)
  local mhl = row.msg:CreateTexture(nil, "HIGHLIGHT")
  mhl:SetAllPoints()
  mhl:SetTexture(MSG_ICON)
  pcall(mhl.SetBlendMode, mhl, "ADD")
  row.msg:SetAlpha(0.55)
  row.msg:SetScript("OnEnter", MsgButton_OnEnter)
  row.msg:SetScript("OnLeave", function(self) self:SetAlpha(0.55); GameTooltip_Hide() end)
  row.msg:SetScript("OnClick", function(self) if self.row.ev then UI:MessageAbout(self.row.ev) end end)

  -- yellow dot: new since you were last on
  row.dot = row:CreateTexture(nil, "OVERLAY")
  row.dot:SetSize(10, 10)
  row.dot:SetTexture("Interface\\COMMON\\Indicator-Yellow")
  row.dot:SetPoint("RIGHT", row.msg, "LEFT", -2, 0)

  row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  row.text:SetJustifyH("LEFT")
  row.text:SetWordWrap(false)

  -- second line: where it came from, and the ruleset on the right
  row.meta = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  row.sub = row:CreateFontString(nil, "OVERLAY", SUB_FONT)
  row.sub:SetJustifyH("LEFT")
  row.sub:SetWordWrap(false)

  -- hairline between rows
  row.line = row:CreateTexture(nil, "ARTWORK")
  row.line:SetHeight(1)
  row.line:SetPoint("BOTTOMLEFT", 8, 0)
  row.line:SetPoint("BOTTOMRIGHT", -8, 0)
  row.line:SetColorTexture(1, 1, 1, 0.05)

  -- timeline look: this row is a day header ("Today")
  row.header = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  row.header:SetPoint("LEFT", 10, 0)
  row.headerLine = row:CreateTexture(nil, "ARTWORK")
  row.headerLine:SetHeight(1)
  row.headerLine:SetPoint("LEFT", row.header, "RIGHT", 8, 0)
  row.headerLine:SetPoint("RIGHT", -10, 0)
  row.headerLine:SetColorTexture(0.79, 0.66, 0.3, 0.35)

  local hl = row:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(1, 1, 1, 0.06)

  -- the icon pops when a pop-up lands on this row
  row.popAnim = row.icon:CreateAnimationGroup()
  local pop = row.popAnim:CreateAnimation("Scale")
  if not pcall(pop.SetScaleFrom, pop, 1.6, 1.6) then pcall(pop.SetFromScale, pop, 1.6, 1.6) end
  if not pcall(pop.SetScaleTo, pop, 1, 1) then pcall(pop.SetToScale, pop, 1, 1) end
  pop:SetDuration(0.35)
  pop:SetSmoothing("OUT")
  pcall(pop.SetOrigin, pop, "CENTER", 0, 0)

  row:SetScript("OnEnter", Row_OnEnter)
  row:SetScript("OnLeave", Row_OnLeave)
  row:SetScript("OnClick", function(self)
    if self.ev then UI:OpenDetails(self.ev.id) end
  end)
  UI:StyleRow(row, st)
  return row
end

-- Size and place a row's parts for a style (called again when it changes)
function UI:StyleRow(row, st)
  st = st or style()
  local compact = st.lines == 1
  row.st = st
  row:SetHeight(st.row)
  row.icon:SetSize(st.icon, st.icon)
  row.icon:ClearAllPoints()
  row.time:ClearAllPoints()
  row.text:ClearAllPoints()
  row.sub:ClearAllPoints()
  row.meta:ClearAllPoints()
  local iconX = st.rail and 28 or (st.box and 9 or 2)
  if compact then
    row.icon:SetPoint("LEFT", 8, 0)
    row.time:SetPoint("RIGHT", -6, 0)
    row.text:SetPoint("LEFT", row.icon, "RIGHT", 7, 0)
    row.text:SetPoint("RIGHT", row.dot, "LEFT", -4, 0)
    row.sub:Hide()
    row.meta:Hide()
  else
    row.icon:SetPoint("LEFT", iconX, 0)
    row.time:SetPoint("TOPRIGHT", -8, -9)
    row.text:SetPoint("TOPLEFT", row.icon, "RIGHT", 9, 11)
    row.text:SetPoint("RIGHT", row.dot, "LEFT", -6, 0)
    row.meta:SetPoint("BOTTOMRIGHT", -8, 7)
    row.sub:SetPoint("TOPLEFT", row.text, "BOTTOMLEFT", 0, -3)
    row.sub:SetPoint("RIGHT", row.meta, "LEFT", -6, 0)
    row.sub:Show()
    row.meta:Show()
  end
  for _, fs in ipairs({ row.text, row.sub, row.meta, row.time }) do shadow(fs, not st.box) end
  row.compact = compact
end

-- Fill a row with an event, or a day header ({ header = "Today" })
local function SetRow(row, item, showName)
  local st = row.st or style()
  if not item then row.ev = nil; row:Hide(); return end
  if item.header then
    row.ev = nil
    for _, part in ipairs({ row.bg, row.accent, row.iconBorder, row.icon, row.time, row.dot, row.msg, row.text, row.sub, row.meta, row.line, row.diamond }) do part:Hide() end
    row.rail:SetShown(st.rail)
    row.header:SetText("|cffc9a84c" .. item.header:upper() .. "|r")
    row.header:Show()
    row.headerLine:Show()
    row:Show()
    return
  end
  local ev = item
  row.ev = ev
  row.header:Hide()
  row.headerLine:Hide()
  local icon, desc, q, sub = ns:Describe(ev)
  local r, g, b = accentRGB(ev.k, q)
  row.icon:SetTexture(icon)
  row.icon:Show()
  row.iconBorder:SetColorTexture(r, g, b, 0.9)
  row.iconBorder:Show()
  row.accent:SetColorTexture(r, g, b, 0.9)
  row.accent:SetShown(st.box and not st.rail)
  setGradient(row.bg, r, g, b, 0.13)
  row.bg:SetShown(st.box and not st.rail)
  row.line:SetShown(st.box)
  row.rail:SetShown(st.rail)
  row.diamond:SetColorTexture(r, g, b, 1)
  row.diamond:SetShown(st.rail)
  row.flash:SetColorTexture(r, g, b, 0.5)
  row.time:SetText(ns.Ago(ev.t))
  row.time:Show()
  row.dot:SetShown(ns:IsNew(ev))
  row.msg:SetShown(not ev.self) -- no messaging yourself
  row.text:Show()
  if row.compact then
    row.text:SetText(showName and (ns.Label(ev, true) .. " " .. desc) or desc)
  else
    local name, meta = ns.NameParts(ev)
    row.text:SetText(showName and (gold(name) .. " " .. desc) or desc)
    row.sub:SetText(sub or "")
    row.meta:SetText((showName and meta) and ("|cff6a6a6a" .. meta .. "|r") or "")
    row.sub:Show()
    row.meta:Show()
  end
  row:Show()
end

---------------------------------------------------------------------------
-- Feed (top left)
---------------------------------------------------------------------------
function UI:FeedList()
  local list, showSelf, log = {}, ns.db.settings.showSelf, ns.db.log
  local clearedAt = ns.db.feedClearedAt or 0
  local hidden = 0 -- wanted, but hidden by the filter bar
  for i = #log, 1, -1 do
    local e = log[i]
    if (showSelf or not e.self) and ns:Wants(e) and (e.recv or e.t) > clearedAt then
      if self:FilterPasses(e) then list[#list + 1] = e else hidden = hidden + 1 end
    end
  end
  return list, hidden
end

-- What the feed's rows show: the events, with a day header before each new
-- day in the timeline look.
function UI:FeedItems()
  local list, hidden = self:FeedList()
  if not style().headers then return list, hidden end
  local items, lastDay, now = {}, nil, ns.Now()
  for _, e in ipairs(list) do
    local d = dayOf(e.t)
    if d ~= lastDay then
      items[#items + 1] = { header = dayLabel(e.t, now) }
      lastDay = d
    end
    items[#items + 1] = e
  end
  return items, hidden
end

local function headerButton(f, size, texture, tooltip, onClick)
  local b = CreateFrame("Button", nil, f)
  b:SetSize(size, size)
  b:SetNormalTexture(texture)
  b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
  b:SetScript("OnClick", onClick)
  b:SetScript("OnEnter", function(s)
    UI:Touch()
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
    GameTooltip:SetText(tooltip[1])
    if tooltip[2] then GameTooltip:AddLine(tooltip[2], 1, 1, 1, true) end
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", GameTooltip_Hide)
  return b
end

---------------------------------------------------------------------------
-- Filter bar: small toggles under the feed's header that hide kinds of
-- milestones and gear qualities from the feed. They only change what the
-- feed shows; pop-ups and sounds follow the Notify settings, and the history
-- window always shows everything. settings.feedFilter = { kinds = { k = false },
-- quality = { [3|4|5] = false } }; a missing entry means shown.
---------------------------------------------------------------------------
local FILTER_KINDS = {
  { k = "loot",  icon = "Interface\\Icons\\INV_Sword_04", label = "Gear & items" },
  { k = "level", icon = "Interface\\Icons\\Spell_Holy_SurgeOfLight", label = "Levels" },
  { k = "ach",   icon = "Interface\\Icons\\Achievement_General", label = "Achievements" },
  { k = "mount", icon = "Interface\\Icons\\Ability_Mount_RidingHorse", label = "Mounts" },
  { k = "pet",   icon = "Interface\\Icons\\INV_Box_PetCarrier_01", label = "Battle pets" },
  { k = "toy",   icon = "Interface\\Icons\\INV_Misc_Toy_10", label = "Toys" },
  { k = "death", icon = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_01", label = "Deaths" },
}
-- who: guildmates who aren't friends (their events are tagged ev.guild)
local FILTER_GUILD = { g = "guild", icon = "Interface\\Icons\\INV_Shirt_GuildTabard_01", label = "Guildmates" }
local FILTER_QUALITIES = {
  { q = 2, label = "Green (uncommon) gear" },
  { q = 3, label = "Blue (rare) gear" },
  { q = 4, label = "Purple (epic) gear" },
  { q = 5, label = "Orange (legendary) gear" },
}
UI.FILTER_KINDS, UI.FILTER_GUILD, UI.FILTER_QUALITIES = FILTER_KINDS, FILTER_GUILD, FILTER_QUALITIES

local function filters()
  local s = ns.db.settings
  s.feedFilter = s.feedFilter or {}
  local ff = s.feedFilter
  ff.kinds = ff.kinds or {}
  ff.quality = ff.quality or {}
  return ff
end

local function eventQuality(e)
  local q = tonumber(e.q)
  if not q and e.v and e.v > 0 and C_Item and C_Item.GetItemInfo then q = select(3, C_Item.GetItemInfo(e.v)) end
  return q
end

-- Is this from a guildmate who isn't a friend?
local function fromGuild(e)
  return e.guild == true or ns:IsGuildmate(e.id)
end

-- Does an event get past the filter bar? (grey and white gear is only
-- covered by the Gear toggle; orange covers legendary and above)
function UI:FilterPasses(e)
  local ff = filters()
  if ff.kinds[e.k] == false then return false end
  if ff.guild == false and fromGuild(e) then return false end
  if e.k == "loot" then
    local q = eventQuality(e)
    if q and q >= 2 and ff.quality[math.min(q, 5)] == false then return false end
  end
  return true
end

function UI:IsFilterOn(def)
  local ff = filters()
  if def.q then return ff.quality[def.q] ~= false end
  if def.g then return ff.guild ~= false end
  return ff.kinds[def.k] ~= false
end

function UI:ToggleFilter(def)
  local ff = filters()
  if def.q then
    -- hidden is stored as false; shown is no entry at all
    if ff.quality[def.q] == false then ff.quality[def.q] = nil else ff.quality[def.q] = false end
  elseif def.g then
    if ff.guild == false then ff.guild = nil else ff.guild = false end
  else
    if ff.kinds[def.k] == false then ff.kinds[def.k] = nil else ff.kinds[def.k] = false end
  end
  if self.feed then self.feed.offset = 0 end
  self:Touch()
  self:RefreshFeed()
end

function UI:ResetFilters()
  local ff = filters()
  wipe(ff.kinds)
  wipe(ff.quality)
  ff.guild = nil
  if self.feed then self.feed.offset = 0 end
  self:RefreshFeed()
end

local function FilterButton_OnEnter(self)
  UI:Touch()
  local on = UI:IsFilterOn(self.def)
  GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT")
  GameTooltip:SetText(self.def.label)
  GameTooltip:AddLine(on and "Shown in the feed. Click to hide." or "Hidden from the feed. Click to show.", 1, 1, 1, true)
  GameTooltip:AddLine("Right click: show everything again", 0.6, 0.6, 0.6)
  GameTooltip:AddLine("Only the feed is filtered. Pop-ups follow your Notify settings, and More details shows everything.", 0.6, 0.6, 0.6, true)
  GameTooltip:Show()
end

function UI:CreateFilterBar(f)
  local bar = CreateFrame("Frame", nil, f)
  bar:SetHeight(FILTER_H)
  bar:SetPoint("TOPLEFT", 9, -FEED_HEAD + 1)
  bar:SetPoint("TOPRIGHT", -9, -FEED_HEAD + 1)
  bar.buttons = {}
  local x = 0
  local function add(def)
    local b = CreateFrame("Button", nil, bar)
    b:SetSize(16, 16)
    b:SetPoint("LEFT", x, 0)
    b.border = b:CreateTexture(nil, "BACKGROUND")
    b.border:SetPoint("TOPLEFT", -1, 1)
    b.border:SetPoint("BOTTOMRIGHT", 1, -1)
    b.tex = b:CreateTexture(nil, "ARTWORK")
    b.tex:SetAllPoints()
    if def.q then
      local r, g, bl = qualityRGB(def.q)
      b.rgb = { r, g, bl }
    else
      b.tex:SetTexture(def.icon)
      b.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    end
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.25)
    b.def = def
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:SetScript("OnClick", function(self, button)
      if button == "RightButton" then UI:ResetFilters() else UI:ToggleFilter(self.def) end
      if GameTooltip:IsOwned(self) then FilterButton_OnEnter(self) end
    end)
    b:SetScript("OnEnter", FilterButton_OnEnter)
    b:SetScript("OnLeave", GameTooltip_Hide)
    bar.buttons[#bar.buttons + 1] = b
    x = x + 18
  end
  bar.dividers = {}
  local function divider()
    local d = bar:CreateTexture(nil, "ARTWORK")
    d:SetSize(1, 14)
    d:SetPoint("LEFT", x + 2, 0)
    d:SetColorTexture(1, 1, 1, 0.18)
    bar.dividers[#bar.dividers + 1] = d
    x = x + 8
  end
  -- what | who | gear quality
  for _, def in ipairs(FILTER_KINDS) do add(def) end
  divider()
  add(FILTER_GUILD)
  divider()
  for _, def in ipairs(FILTER_QUALITIES) do add(def) end
  bar.note = bar:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  bar.note:SetPoint("RIGHT", 0, 0)
  f.filterBar = bar
  bar:SetShown(filterBarOn())
end

-- Paint the toggles on or off, and say how many rows they're hiding
function UI:UpdateFilterBar(hidden)
  local bar = self.feed and self.feed.filterBar
  if not bar then return end
  for _, b in ipairs(bar.buttons) do
    local on = self:IsFilterOn(b.def)
    b.on = on
    if b.def.q then
      local c = b.rgb
      b.tex:SetColorTexture(c[1], c[2], c[3], on and 1 or 0.12)
      b.border:SetColorTexture(on and c[1] or 0.35, on and c[2] or 0.35, on and c[3] or 0.35, on and 1 or 0.7)
    else
      pcall(b.tex.SetDesaturated, b.tex, not on)
      b.tex:SetAlpha(on and 1 or 0.3)
      b.border:SetColorTexture(on and 0.8 or 0.3, on and 0.66 or 0.3, on and 0.3 or 0.3, on and 0.8 or 0.6)
    end
  end
  bar.note:SetText((hidden or 0) > 0 and ("|cff888888" .. hidden .. " hidden|r") or "")
end

-- Show or hide the filter bar (settings), keeping the same number of rows
function UI:ApplyFilterBar()
  local f = self.feed
  if not f then return end
  local rows = f.numRows
  f.filterBar:SetShown(filterBarOn())
  f:SetHeight(feedHeight(rows))
  ns.db.settings.feedSize = { math.floor(f:GetWidth() + 0.5), feedHeight(rows) }
  f.numRows = 0 -- force a re-layout
  self:LayoutFeed()
  self:RequestRefresh()
end

function UI:CreateFeed()
  local f = CreateFrame("Frame", "FriendFeedFrame", UIParent, "BackdropTemplate")
  local size = ns.db.settings.feedSize
  -- sizes saved before the filter bar existed: make room for it so no row is lost
  if ns.db.settings.feedSize and not ns.db.settings.feedSizeHasFilterBar and filterBarOn() then
    ns.db.settings.feedSize[2] = (tonumber(ns.db.settings.feedSize[2]) or 0) + FILTER_H
  end
  ns.db.settings.feedSizeHasFilterBar = true
  size = ns.db.settings.feedSize
  local w = (size and tonumber(size[1])) or FEED_W
  local h = (size and tonumber(size[2])) or feedHeight(FEED_ROWS)
  -- a size saved with another look (or version) may not be whole rows: snap it
  local st = style()
  local rows = math.max(FEED_MIN_ROWS, math.min(st.maxRows, math.floor((h - headH() - FEED_FOOT) / st.row)))
  f:SetSize(math.max(FEED_MIN_W, math.min(FEED_MAX_W, w)), feedHeight(rows))
  skin(f, 0.72)
  makeDraggable(f, "feedPoint")
  local pt = ns.db.settings.feedPoint
  if pt then
    f:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
  else
    f:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 20, -140)
  end
  f:SetScript("OnEnter", function() UI:Touch() end)
  f:SetScript("OnLeave", function() C_Timer.After(0.3, function() UI:CheckHover() end) end)

  -- header band
  f.band = f:CreateTexture(nil, "BACKGROUND", nil, 1)
  f.band:SetPoint("TOPLEFT", 1, -1)
  f.band:SetPoint("TOPRIGHT", -1, -1)
  f.band:SetHeight(FEED_HEAD - 5)
  f.band:SetColorTexture(1, 1, 1, 1)
  setGradient(f.band, 1, 0.82, 0, 0.09)
  f.bandLine = f:CreateTexture(nil, "ARTWORK")
  f.bandLine:SetHeight(1)
  f.bandLine:SetPoint("TOPLEFT", 1, -(FEED_HEAD - 4))
  f.bandLine:SetPoint("TOPRIGHT", -1, -(FEED_HEAD - 4))
  f.bandLine:SetColorTexture(0.45, 0.36, 0.2, 0.6)

  f.logo = f:CreateTexture(nil, "ARTWORK")
  f.logo:SetSize(18, 18)
  f.logo:SetPoint("TOPLEFT", 6, -6)
  f.logo:SetTexture(ns.LOGO_SMALL)

  f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.title:SetPoint("LEFT", f.logo, "RIGHT", 4, 0)
  f.title:SetText("Friend Feed")

  f.count = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  f.count:SetPoint("LEFT", f.title, "RIGHT", 8, 0)

  local gear = headerButton(f, 14, "Interface\\Buttons\\UI-OptionsButton",
    { "Friend Feed settings" }, function() ns.Settings:Toggle() end)
  gear:SetPoint("TOPRIGHT", -7, -9)

  -- "More details" in the header, next to the gear: opens the friend history window
  local details = headerButton(f, 14, "Interface\\Icons\\INV_Misc_Book_09",
    { "More details", "Each friend's full history." }, function() UI:ToggleDetails() end)
  details:GetNormalTexture():SetTexCoord(0.08, 0.92, 0.08, 0.92)
  details:SetPoint("RIGHT", gear, "LEFT", -6, 0)
  f.detailsButton = details

  -- "Clear" in the header: empties the feed, keeps the history
  local btn = CreateFrame("Button", nil, f)
  btn:SetSize(34, 16)
  btn:SetPoint("RIGHT", details, "LEFT", -7, 0)
  btn.text = btn:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  btn.text:SetPoint("RIGHT")
  btn.text:SetText("Clear")
  btn:SetScript("OnClick", function() UI:ClearFeed() end)
  btn:SetScript("OnEnter", function(s)
    UI:Touch()
    s.text:SetTextColor(1, 0.82, 0)
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
    GameTooltip:SetText("Clear the feed")
    GameTooltip:AddLine("Your friends' full history stays in More details (the book icon).", 1, 1, 1, true)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function(s) s.text:SetTextColor(0.5, 0.5, 0.5); GameTooltip:Hide() end)

  f.more = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.more:SetPoint("RIGHT", btn, "LEFT", -8, 0)

  self:CreateFilterBar(f)

  f.rows = {}      -- created as needed when the feed gets taller
  f.numRows = 0

  f.empty = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.empty:SetPoint("LEFT", 15, -10)
  f.empty:SetPoint("RIGHT", -15, -10)
  f.empty:SetText("No friend activity yet.\nType /ff demo to preview the feed.")

  f.offset = 0
  f:EnableMouseWheel(true)
  f:SetScript("OnMouseWheel", function(self, delta) self.offset = self.offset - delta * 2; UI:RefreshFeed() end)

  -- resize grip in the bottom right corner
  f:SetResizable(true)
  if f.SetResizeBounds then
    f:SetResizeBounds(FEED_MIN_W, feedHeight(FEED_MIN_ROWS), FEED_MAX_W, feedHeight(style().maxRows))
  end
  local grip = CreateFrame("Button", nil, f)
  grip:SetSize(12, 12)
  grip:SetPoint("BOTTOMRIGHT", -2, 2)
  grip:SetFrameLevel(f:GetFrameLevel() + 10)
  grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
  grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
  grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
  grip:SetScript("OnMouseDown", function(_, button)
    if button == "LeftButton" and not ns.db.settings.locked then
      f.sizing = true
      f:StartSizing("BOTTOMRIGHT")
    end
  end)
  grip:SetScript("OnMouseUp", function() UI:StopFeedSizing() end)
  grip:SetScript("OnHide", function() UI:StopFeedSizing() end)
  grip:SetScript("OnEnter", function(s)
    UI:Touch()
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT"); GameTooltip:SetText("Drag to resize"); GameTooltip:Show()
  end)
  grip:SetScript("OnLeave", GameTooltip_Hide)
  f.grip = grip

  f:SetScript("OnSizeChanged", function() UI:LayoutFeed() end)

  f.lastActivity = GetTime()
  f.targetAlpha = 1
  self.feed = f
  self:ApplyBox()
  self:LayoutFeed()
  self:ApplyLock()
  f:SetShown(ns.db.settings.feedShown)
end

-- Box or no box, for the current look, and how solid the box is (settings.feedAlpha, percent)
function UI:ApplyBox()
  local f = self.feed
  if not f then return end
  local box = style().box
  local a = box and math.max(0, math.min(100, tonumber(ns.db.settings.feedAlpha) or 70)) / 100 or 0
  f:SetBackdrop(BACKDROP)
  f:SetBackdropColor(0.03, 0.03, 0.05, a)
  f:SetBackdropBorderColor(0.45, 0.36, 0.2, 0.85 * math.sqrt(a)) -- the border fades more slowly than the fill
  f.band:SetShown(box)
  f.bandLine:SetShown(box)
  f.boxless = not box
  f.bgAlpha = a
end

-- How many whole rows fit in a feed this tall
local function rowsFor(height)
  local st = style()
  return math.max(FEED_MIN_ROWS, math.min(st.maxRows, math.floor(((height or 0) - headH() - FEED_FOOT) / st.row)))
end

-- Fit as many rows as the feed's height allows, creating rows on demand.
function UI:LayoutFeed()
  local f = self.feed
  if not f then return end
  -- a pop-up on screen follows the feed's width as it's resized
  local t = self.toast
  if t and t:IsShown() and not t.flying then t:SetWidth(self:ToastWidth()) end
  local n = rowsFor(f:GetHeight())
  local rowH = style().row
  for i = #f.rows + 1, n do
    local r = CreateRow(f)
    r:EnableMouseWheel(true)
    r:SetScript("OnMouseWheel", function(_, delta) f.offset = f.offset - delta * 2; UI:RefreshFeed() end)
    f.rows[i] = r
  end
  for i, r in ipairs(f.rows) do
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", 4, -headH() - (i - 1) * rowH)
    r:SetPoint("TOPRIGHT", -4, -headH() - (i - 1) * rowH) -- rows stretch with the width
    if i > n then r:Hide() end
  end
  if n ~= f.numRows then
    f.numRows = n
    self:RefreshFeed()
  end
end

-- Finish a resize: snap the height to whole rows and remember the size.
function UI:StopFeedSizing()
  local f = self.feed
  if not (f and f.sizing) then return end
  f.sizing = false
  f:StopMovingOrSizing()
  local rows = rowsFor(f:GetHeight())
  local w = math.floor(math.max(FEED_MIN_W, math.min(FEED_MAX_W, f:GetWidth())) + 0.5)
  f:SetSize(w, feedHeight(rows))
  ns.db.settings.feedSize = { w, feedHeight(rows) }
  -- sizing can re-anchor the frame, so save the position too
  local p, _, rp, x, y = f:GetPoint()
  if p then ns.db.settings.feedPoint = { p, rp, x, y } end
  self:LayoutFeed()
end

-- The look changed (settings): restyle every row and keep the feed at whole rows.
function UI:ApplyStyle()
  local f = self.feed
  if not f then return end
  for _, r in ipairs(f.rows) do self:StyleRow(r) end
  if self.details then
    for _, r in ipairs(self.details.histRows) do self:StyleRow(r, detailsStyle()) end
  end
  self:ApplyBox()
  if f.SetResizeBounds then
    f:SetResizeBounds(FEED_MIN_W, feedHeight(FEED_MIN_ROWS), FEED_MAX_W, feedHeight(style().maxRows))
  end
  local rows = rowsFor(f:GetHeight())
  f:SetHeight(feedHeight(rows))
  ns.db.settings.feedSize = { math.floor(f:GetWidth() + 0.5), feedHeight(rows) }
  f.numRows = 0 -- force a re-layout even if the count didn't change
  self:LayoutFeed()
  self:LayoutDetails()
  self:RequestRefresh()
end

-- Locking the feed stops both dragging and resizing.
function UI:ApplyLock()
  local f = self.feed
  if not f then return end
  local locked = ns.db.settings.locked
  if locked then self:StopFeedSizing() end
  f.grip:SetShown(not locked)
end

-- chat look: the newest rows are solid, older ones fade, unless the mouse is on the feed
local function rowAlpha(i, st, hovered)
  if not (st.fade and not hovered) then return 1 end
  return math.max(0.35, 1 - 0.14 * math.max(0, i - 2))
end
UI.RowAlpha = rowAlpha

function UI:RefreshFeed(flashEv)
  local f = self.feed
  if not f then return end
  local st = style()
  local list, hidden = self:FeedItems()
  local rows = f.numRows
  local maxOff = math.max(0, #list - rows)
  f.offset = math.max(0, math.min(f.offset or 0, maxOff))
  for i = 1, rows do
    local r = f.rows[i]
    SetRow(r, list[i + f.offset], true)
    r:SetAlpha(rowAlpha(i, st, f.hovered))
  end
  f.empty:SetShown(#list == 0)
  if (hidden or 0) > 0 then
    f.empty:SetText("Everything here is hidden by the filters above.\nRight click a filter to show everything again.")
  else
    f.empty:SetText("No friend activity yet.\nType /ff demo to preview the feed.")
  end
  self:UpdateFilterBar(hidden)

  local newCount = 0
  for _, e in ipairs(list) do if not e.header and ns:IsNew(e) then newCount = newCount + 1 end end
  f.count:SetText(newCount > 0 and gold(newCount .. " new") or "")

  if #list > rows then
    f.more:SetText(format("%d-%d of %d", f.offset + 1, math.min(f.offset + rows, #list), #list))
  else
    f.more:SetText("")
  end

  if flashEv then
    self:Touch()
    local r = self:FeedRowFor(flashEv)
    if r then r.flashAnim:Stop(); r.flashAnim:Play() end
  end
end

-- The visible feed row showing this event, if any
function UI:FeedRowFor(ev)
  local f = self.feed
  if not (ev and f and f:IsShown()) then return nil end
  for i = 1, f.numRows do
    local r = f.rows[i]
    if r and r:IsShown() and rawget(r, "ev") == ev then return r end
  end
  return nil
end

-- A pop-up just swooped into the feed: light its row up
function UI:Landed(ev)
  local r = self:FeedRowFor(ev)
  if not r then return end
  r.flashAnim:Stop(); r.flashAnim:Play()
  if r.popAnim then r.popAnim:Stop(); r.popAnim:Play() end
  self:Touch()
end

---------------------------------------------------------------------------
-- Idle dimming: the feed fades down when nothing new has happened for a
-- while, and comes back when something lands or the mouse is over it.
---------------------------------------------------------------------------
function UI:Touch()
  local f = self.feed
  if not f then return end
  f.lastActivity = GetTime()
  if f:IsMouseOver() and not f.hovered then
    f.hovered = true
    if style().fade then self:RefreshFeed() end
  end
  self:UpdateFeedDim()
end

-- The mouse may have left the feed: let chat-style rows fade again
function UI:CheckHover()
  local f = self.feed
  if f and f.hovered and not f:IsMouseOver() then
    f.hovered = false
    if style().fade then self:RefreshFeed() end
  end
end

local function fadeStep(self, dt)
  local a, target = self:GetAlpha(), self.targetAlpha
  local step = dt * 1.6
  if math.abs(a - target) <= step then
    self:SetAlpha(target)
    self:SetScript("OnUpdate", nil)
  else
    self:SetAlpha(a + (target > a and step or -step))
  end
end

-- What alpha the feed should be heading for right now
function UI:FeedDimTarget(now)
  local f = self.feed
  if not (f and ns.db.settings.feedDim) then return 1 end
  now = now or GetTime()
  if f:IsMouseOver() then f.lastActivity = now; return 1 end
  if now - (f.lastActivity or 0) < DIM_AFTER then return 1 end
  return DIM_ALPHA
end

function UI:UpdateFeedDim(now)
  local f = self.feed
  if not f then return end
  local target = self:FeedDimTarget(now)
  if target ~= f.targetAlpha then
    f.targetAlpha = target
    f:SetScript("OnUpdate", fadeStep)
  end
  return target
end

function UI:ClearFeed()
  ns.db.feedClearedAt = ns.Now()
  if self.feed then self.feed.offset = 0 end
  self:RequestRefresh()
  ns.Print("Feed cleared. Everything is still in More details (the book icon on the feed).")
end

function UI:ToggleFeed()
  local s = ns.db.settings
  s.feedShown = not s.feedShown
  self.feed:SetShown(s.feedShown)
  if s.feedShown then self:RefreshFeed() end
end

---------------------------------------------------------------------------
-- Toasts (animated pop-ups)
---------------------------------------------------------------------------
local toastQueue = {}

local function easeOut(x) return 1 - (1 - x) ^ 3 end

function UI:CreateToast()
  local t = CreateFrame("Button", "FriendFeedToast", UIParent, "BackdropTemplate")
  t:SetSize(TOAST_W, 56)
  t:SetFrameStrata("HIGH")
  t:Hide()
  skin(t, 0.93)

  t.glow = t:CreateTexture(nil, "BACKGROUND", nil, 1)
  t.glow:SetPoint("TOPLEFT", 1, -1)
  t.glow:SetPoint("BOTTOMRIGHT", -1, 1)
  t.glow:SetColorTexture(1, 1, 1, 1)
  local pulse = t.glow:CreateAnimationGroup()
  pulse:SetLooping("BOUNCE")
  local pa = pulse:CreateAnimation("Alpha")
  pa:SetFromAlpha(1); pa:SetToAlpha(0.3); pa:SetDuration(0.7)
  t.pulse = pulse

  t.iconBorder = t:CreateTexture(nil, "BORDER")
  t.icon = t:CreateTexture(nil, "ARTWORK")
  t.icon:SetPoint("CENTER", t, "LEFT", 29, 0)
  t.icon:SetSize(40, 40)
  t.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  t.iconBorder:SetPoint("TOPLEFT", t.icon, -1, 1)
  t.iconBorder:SetPoint("BOTTOMRIGHT", t.icon, 1, -1)

  t.who = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  t.who:SetPoint("TOPLEFT", t, "TOPLEFT", 58, -10)
  t.who:SetPoint("RIGHT", -10, 0)
  t.who:SetJustifyH("LEFT")
  t.who:SetWordWrap(false)

  t.body = t:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  t.body:SetPoint("TOPLEFT", t.who, "BOTTOMLEFT", 0, -4)
  t.body:SetPoint("RIGHT", -10, 0)
  t.body:SetJustifyH("LEFT")
  t.body:SetWordWrap(false)

  -- where it came from
  t.sub = t:CreateFontString(nil, "OVERLAY", SUB_FONT)
  t.sub:SetPoint("TOPLEFT", t.body, "BOTTOMLEFT", 0, -3)
  t.sub:SetPoint("RIGHT", -10, 0)
  t.sub:SetJustifyH("LEFT")
  t.sub:SetWordWrap(false)

  t:SetScript("OnEnter", function(self) self.hover = true end)
  t:SetScript("OnLeave", function(self) self.hover = false end)
  t:SetScript("OnClick", function(self)
    UI:OpenDetails(self.target)
    self.elapsed = math.max(self.elapsed, T_IN + T_HOLD)
  end)

  t:SetScript("OnUpdate", function(self, dt)
    local e = self.elapsed
    local holding = e > T_IN and e < T_IN + T_HOLD
    if not (self.hover and holding) then self.elapsed = e + dt end
    e = self.elapsed

    local x, y, alpha, scale = 0, 0, 1, 1
    if e < T_IN then
      local p = easeOut(e / T_IN)
      x, alpha, scale = -60 * (1 - p), p, 1.6 - 0.6 * p
    elseif e < T_IN + T_HOLD then
      -- hold
    elseif e < T_IN + T_HOLD + T_OUT then
      local p = (e - T_IN - T_HOLD) / T_OUT
      if not self.flyChecked then
        self.flyChecked = true
        self.fly = UI:ToastFlightPlan(self)
        self.flying = self.fly ~= nil -- LayoutFeed leaves a flying pop-up alone
      end
      local fl = self.fly
      if fl then
        -- swoop into the feed row that now shows this milestone: slide,
        -- shrink to the row's size, then let the row's flash take over
        local q = p * p * (3 - 2 * p)
        self:ClearAllPoints()
        self:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", fl.x0 + (fl.x1 - fl.x0) * q, fl.y0 + (fl.y1 - fl.y0) * q)
        self:SetSize(fl.w0 + (fl.w1 - fl.w0) * q, fl.h0 + (fl.h1 - fl.h0) * q)
        self.icon:SetSize(40 - 16 * q, 40 - 16 * q)
        self:SetAlpha(p < 0.55 and 1 or (1 - (p - 0.55) / 0.45))
        return
      end
      alpha, y = 1 - p, 12 * p
    else
      self:Hide()
      self.pulse:Stop()
      if self.fly then UI:Landed(self.fly.ev) end
      self.fly, self.flyChecked, self.flying = nil, nil, false
      UI:NextToast()
      return
    end
    self:SetAlpha(alpha)
    self:ClearAllPoints()
    self:SetPoint(self.ap[1], self.ap[2], self.ap[3], self.ap[4] + x, self.ap[5] + y)
    self.icon:SetSize(40 * scale, 40 * scale)
  end)

  self.toast = t
end

-- Where a finishing pop-up should fly to: the feed row showing its event.
-- Screen positions in UIParent coordinates; nil means just fade out.
function UI:ToastFlightPlan(t)
  local ev = t.ev
  local row = self:FeedRowFor(ev)
  if not row then return nil end
  local x0, y0, x1, y1 = t:GetLeft(), t:GetTop(), row:GetLeft(), row:GetTop()
  local w0, h0, w1, h1 = t:GetWidth(), t:GetHeight(), row:GetWidth(), row:GetHeight()
  for _, v in ipairs({ x0, y0, x1, y1, w0, h0, w1, h1 }) do
    if type(v) ~= "number" then return nil end
  end
  return { ev = ev, x0 = x0, y0 = y0, x1 = x1, y1 = y1, w0 = w0, h0 = h0, w1 = w1, h1 = h1 }
end

-- Pop-ups are always the feed's width (even while the feed is hidden), so the two line up
function UI:ToastWidth()
  local w = self.feed and tonumber(self.feed:GetWidth())
  if w and w > 0 then return w end
  return TOAST_W
end

function UI:ToastFromEvent(ev)
  local icon, desc, q, sub = ns:Describe(ev)
  local r, g, b = accentRGB(ev.k, q)
  return { icon = icon, title = ns.Label(ev), body = desc, sub = sub, q = q, color = { r, g, b },
           target = ev.id, sound = ev.k, ev = ev }
end

---------------------------------------------------------------------------
-- Sounds. A palette of named sounds the player can pick from for each kind
-- of alert (settings.sounds). Each entry lists what to try in order: sound
-- kit names the client may know, then raw sound kit numbers, so a missing
-- name falls back safely. "Test sounds" prints what was actually played.
---------------------------------------------------------------------------
local SOUND_OPTIONS = {
  { value = "epic",        label = "Epic loot",        kit = { "UI_EPICLOOT_TOAST", 31578 } },
  { value = "legendary",   label = "Legendary loot",   kit = { "UI_LEGENDARY_LOOT_TOAST", 63971 } },
  { value = "levelup",     label = "Level up",         kit = { "LEVELUP", "UI_LEVELUP", 888 } },
  { value = "achievement", label = "Achievement",      kit = { "UI_ACHIEVEMENT_TOAST", "ACHIEVEMENT_TOAST", "ACHIEVEMENT_MENU_OPEN", 857 } },
  { value = "mission",     label = "Mission complete", kit = { "UI_GARRISON_TOAST_MISSION_COMPLETE", 44294 } },
  { value = "questdone",   label = "Quest complete",   kit = { "IG_QUEST_LIST_COMPLETE", 878 } },
  { value = "questfailed", label = "Quest failed",     kit = { "IG_QUEST_FAILED", "IG_QUEST_LOG_ABANDON_QUEST", 846 } },
  { value = "questlog",    label = "Quest log",        kit = { "IG_QUEST_LOG_OPEN", "IG_QUEST_LIST_OPEN", 844, 875 } },
  { value = "raidwarning", label = "Raid warning",     kit = { "RAID_WARNING", 8959 } },
  { value = "readycheck",  label = "Ready check",      kit = { "READY_CHECK", 8960 } },
  { value = "whisper",     label = "Whisper",          kit = { "TELL_MESSAGE", 3081 } },
  { value = "mapping",     label = "Map ping",         kit = { "MAP_PING", 3175 } },
  { value = "alarm",       label = "Alarm clock",      kit = { "ALARM_CLOCK_WARNING_3", "ALARM_CLOCK_WARNING_2", 12889 } },
  { value = "pvpqueue",    label = "PvP queue",        kit = { "PVP_THROUGH_QUEUE", 8458 } },
  { value = "auction",     label = "Auction house",    kit = { "AUCTION_WINDOW_OPEN", 5864 } },
  { value = "petbattle",   label = "Pet battle",       kit = { "UI_PET_BATTLE_START", "UI_PET_BATTLES_START", "IG_QUEST_LIST_OPEN", 875 } },
  { value = "toybox",      label = "Toy box",          kit = { "UI_TOYBOX_TABS", "IG_BACKPACK_OPEN", 862 } },
  { value = "none",        label = "No sound",         kit = {} },
}
UI.SOUND_OPTIONS = SOUND_OPTIONS
local soundByValue = {}
for _, o in ipairs(SOUND_OPTIONS) do soundByValue[o.value] = o end

-- what each kind of alert plays unless the player picks something else
UI.DEFAULT_SOUNDS = {
  loot = "epic", level = "levelup", ach = "achievement", mount = "legendary",
  pet = "petbattle", toy = "toybox", death = "questfailed", catchup = "questlog",
}
UI.SOUND_ORDER = { "loot", "level", "ach", "mount", "pet", "toy", "death", "catchup" }
UI.SOUND_KIND_LABELS = {
  loot = "Gear & items", level = "Levels", ach = "Achievements", mount = "Mounts",
  pet = "Battle pets", toy = "Toys", death = "Deaths", catchup = "While you were away",
}
local SUMMARY_SOUND = { "IG_MAINMENU_OPTION_CHECKBOX_ON", 856 } -- "+N more" and pings, not configurable

-- Which sound a kind of alert is set to (a SOUND_OPTIONS value)
function UI:SoundFor(kind)
  local s = ns.db and ns.db.settings and ns.db.settings.sounds
  local v = s and s[kind]
  if v and soundByValue[v] then return v end
  return self.DEFAULT_SOUNDS[kind] or "epic"
end

function UI:SoundLabel(value)
  local o = soundByValue[value]
  return o and o.label or tostring(value)
end

-- The first sound in a list the client can play: its id and a name for it
local function resolveSound(kit)
  for _, c in ipairs(kit) do
    if type(c) == "number" then return c, "#" .. c end
    local id = SOUNDKIT and SOUNDKIT[c]
    if id then return id, c end
  end
  return nil
end

---------------------------------------------------------------------------
-- Volume. Addons can't set a sound's volume directly, so:
--   100%       plays on the Master channel, exactly like the game's own sounds.
--   below 100% plays on the Dialog channel with that channel's volume lowered
--              for a few seconds, then put back.
--   above 100% plays 2 or 3 copies at once, which is louder.
-- The original Dialog volume is saved first (soundRestore) so it's put back
-- on the next login even if the game closes mid-sound.
---------------------------------------------------------------------------
local VOL_CHANNEL, VOL_CVAR, VOL_HOLD = "Dialog", "Sound_DialogVolume", 4
local volActive = 0

local function cvar(name)
  local ok, v = pcall(GetCVar, name)
  return ok and v or nil
end

local function setCVar(name, value)
  pcall(SetCVar, name, value)
end

local function canLowerVolume()
  return GetCVar ~= nil and SetCVar ~= nil and cvar(VOL_CVAR) ~= nil and cvar("Sound_EnableDialog") ~= "0"
end

local function restoreVolume()
  local db = ns.db
  if db and db.soundRestore then
    setCVar(VOL_CVAR, db.soundRestore)
    db.soundRestore = nil
  end
end
UI.RestoreVolume = restoreVolume

local function lowerVolumeFor(level)
  if volActive == 0 then ns.db.soundRestore = ns.db.soundRestore or cvar(VOL_CVAR) end
  volActive = volActive + 1
  setCVar(VOL_CVAR, format("%.2f", level))
  C_Timer.After(VOL_HOLD, function()
    volActive = math.max(0, volActive - 1)
    if volActive == 0 then restoreVolume() end
  end)
end

-- How a volume (percent) is played: number of copies, per-copy level, channel.
function UI:VolumePlan(pct)
  local scale = (pct or 100) / 100
  if scale <= 0 then return 0 end
  local copies = math.max(1, math.min(3, math.ceil(scale - 0.001)))
  local level = scale / copies
  if level > 0.99 then return copies, 1, "Master" end
  if not canLowerVolume() then return copies, 1, "Master" end -- can't go quieter, play normally
  return copies, level, VOL_CHANNEL
end

-- Play a list of sound kit candidates at a volume; returns the name played
local function playKit(kit, pct)
  local id, name = resolveSound(kit)
  if not id then return nil end
  local copies, level, channel = UI:VolumePlan(pct)
  if copies == 0 then return name end
  if channel ~= "Master" then lowerVolumeFor(level) end
  for _ = 1, copies do pcall(PlaySound, id, channel) end
  return name
end

-- Play one of the palette's sounds (settings preview). Returns what was played.
function UI:PlaySoundOption(value, pct)
  local o = soundByValue[value]
  if not o then return nil end
  if value == "none" then return "none" end
  return playKit(o.kit, pct or ns.db.settings.soundVolume or 100)
end

function UI:PlayKindSound(kind, pct)
  pct = pct or ns.db.settings.soundVolume or 100
  if kind == "summary" then return playKit(SUMMARY_SOUND, pct) end
  return self:PlaySoundOption(self:SoundFor(kind), pct)
end

function UI:QueueToast(data)
  if not ns.db.settings.toasts then return end
  -- don't let a burst bury the screen: fold the backlog into one summary
  if #toastQueue >= 4 then
    local last = toastQueue[#toastQueue]
    if last.summary then
      last.count = last.count + 1
    else
      toastQueue[#toastQueue + 1] = { summary = true, count = 1, icon = ns.ICONS.ach, title = "Friend Feed", q = 4, sound = "summary" }
    end
  else
    toastQueue[#toastQueue + 1] = data
  end
  if not self.toast:IsShown() then self:NextToast() end
end

function UI:NextToast()
  local data = table.remove(toastQueue, 1)
  if not data then return end
  if data.summary then data.body = "+" .. data.count .. " more - check your feed" end

  local t = self.toast
  local r, g, b
  if data.color then r, g, b = data.color[1], data.color[2], data.color[3] else r, g, b = qualityRGB(data.q) end
  setGradient(t.glow, r, g, b, 0.45)
  t.iconBorder:SetColorTexture(r, g, b, 1)
  t.icon:SetTexture(data.icon)
  t.who:SetText(data.title)
  t.body:SetText(data.body)
  t.sub:SetText(data.sub or "")
  t.target = data.target
  t.ev = data.ev
  t.fly, t.flyChecked, t.flying = nil, nil, false
  -- a third line when we know where it came from
  t.who:ClearAllPoints()
  t.who:SetPoint("TOPLEFT", t, "TOPLEFT", 58, data.sub and -8 or -10)
  t.who:SetPoint("RIGHT", -10, 0)

  -- sits under the feed, exactly as wide as it (LayoutFeed keeps it matched on resize)
  if self.feed and self.feed:IsShown() then
    t.ap = { "TOPLEFT", self.feed, "BOTTOMLEFT", 0, -6 }
  else
    t.ap = { "TOPLEFT", UIParent, "TOPLEFT", 20, -140 }
  end
  t:SetSize(self:ToastWidth(), data.sub and 68 or 56)

  local big = (data.q or 0) >= 4
  if big then t.pulse:Play() else t.pulse:Stop() end
  self:PlayKindSound(data.sound)

  t.elapsed = 0
  t.hover = false
  t:SetAlpha(0)
  t:Show()
end

-- "While you were away" summary, batched over a few seconds
local catchup = { total = 0, who = {} } -- who: friend id -> display label

function UI:QueueCatchup(ev)
  catchup.total = catchup.total + 1
  catchup.who[ev.id] = ns.Label(ev)
  if not catchup.timer then
    catchup.timer = C_Timer.NewTimer(3, function() UI:FlushCatchup() end)
  end
end

function UI:FlushCatchup()
  local names, onlyID = {}, nil
  for id, label in pairs(catchup.who) do names[#names + 1] = label; onlyID = id end
  table.sort(names)
  local who
  if #names == 1 then who = names[1]
  elseif #names == 2 then who = names[1] .. " and " .. names[2]
  else who = names[1] .. " and " .. (#names - 1) .. " others" end
  local body = who .. ": " .. catchup.total .. " new milestone" .. (catchup.total == 1 and "" or "s")
  catchup.total = 0
  wipe(catchup.who)
  catchup.timer = nil
  self:QueueToast({
    icon = "Interface\\Icons\\INV_Misc_Book_09",
    title = "While you were away",
    body = body,
    q = 4,
    sound = "catchup",
    target = (#names == 1) and onlyID or nil,
  })
end

---------------------------------------------------------------------------
-- Friend history window
---------------------------------------------------------------------------
local HIST_TOP = 84 -- where the history rows start

function UI:CreateDetails()
  local d = CreateFrame("Frame", "FriendFeedDetails", UIParent, "BackdropTemplate")
  d:SetSize(DETAIL_W, DETAIL_H)
  d:SetPoint("CENTER")
  d:SetFrameStrata("DIALOG")
  d:SetToplevel(true)
  d:Hide()
  skin(d, 0.96)
  makeDraggable(d)
  tinsert(UISpecialFrames, "FriendFeedDetails") -- Esc closes it

  d.logo = d:CreateTexture(nil, "ARTWORK")
  d.logo:SetSize(26, 26)
  d.logo:SetPoint("TOPLEFT", 6, -4)
  d.logo:SetTexture(ns.LOGO_SMALL)

  d.title = d:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  d.title:SetPoint("TOPLEFT", 34, -11)
  d.title:SetText("Friend Feed")

  local close = CreateFrame("Button", nil, d, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)

  local div = d:CreateTexture(nil, "ARTWORK")
  div:SetColorTexture(0.45, 0.36, 0.2, 0.9)
  div:SetWidth(1)
  div:SetPoint("TOPLEFT", 12 + LIST_W, -40)
  div:SetPoint("BOTTOMLEFT", 12 + LIST_W, 10)

  -- left: friends
  d.listOffset = 0
  d.friendRows = {}
  local listRows = math.floor((DETAIL_H - 52) / LIST_ROW_H)
  for i = 1, listRows do
    local b = CreateFrame("Button", nil, d)
    b:SetSize(LIST_W - 6, LIST_ROW_H)
    b:SetPoint("TOPLEFT", 10, -40 - (i - 1) * LIST_ROW_H)
    b.sel = b:CreateTexture(nil, "BACKGROUND")
    b.sel:SetAllPoints()
    b.sel:SetColorTexture(1, 0.82, 0, 0.16)
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.07)
    b.badge = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.badge:SetPoint("RIGHT", -4, 0)
    b.name = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.name:SetPoint("LEFT", 6, 0)
    b.name:SetPoint("RIGHT", b.badge, "LEFT", -4, 0)
    b.name:SetJustifyH("LEFT")
    b.name:SetWordWrap(false)
    b:SetScript("OnClick", function(self) UI:OpenDetails(self.id) end)
    b:EnableMouseWheel(true)
    b:SetScript("OnMouseWheel", function(_, delta) d.listOffset = d.listOffset - delta; UI:RefreshDetails() end)
    d.friendRows[i] = b
  end

  -- right: history
  local rx = 24 + LIST_W
  d.rx = rx
  d.header = d:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  d.header:SetPoint("TOPLEFT", rx, -42)
  d.sub = d:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  d.sub:SetPoint("TOPLEFT", d.header, "BOTTOMLEFT", 0, -4)

  d.histOffset = 0
  d.histRows = {}

  d.empty = d:CreateFontString(nil, "OVERLAY", "GameFontDisable")
  d.empty:SetPoint("TOPLEFT", rx, -96)
  d.empty:SetText("Nothing here yet.")

  d:SetScript("OnHide", function(self) ns:MarkRead(self.selected); UI:RequestRefresh() end)
  self.details = d
  self:LayoutDetails()
end

-- History rows for the current row style, created on demand.
function UI:LayoutDetails()
  local d = self.details
  if not d then return end
  local st = detailsStyle()
  local rowH = st.row
  local n = math.floor((DETAIL_H - HIST_TOP - 12) / rowH)
  for i = #d.histRows + 1, n do
    local r = CreateRow(d, st)
    r:EnableMouseWheel(true)
    r:SetScript("OnMouseWheel", function(_, delta) d.histOffset = d.histOffset - delta * 3; UI:RefreshDetails() end)
    d.histRows[i] = r
  end
  for i, r in ipairs(d.histRows) do
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", d.rx - 4, -HIST_TOP - (i - 1) * rowH)
    r:SetPoint("TOPRIGHT", -10, -HIST_TOP - (i - 1) * rowH)
    if i > n then r:Hide() end
  end
  d.numRows = n
end

-- One entry per friend (Battle.net account), labelled with the character
-- they were last seen on, e.g. "Grommash (RP-PvP)".
function UI:FriendSummaries()
  local by, order = {}, {}
  for _, e in ipairs(ns.db.log) do
    if not e.self then
      local s = by[e.id]
      if not s then
        s = { id = e.id, count = 0, new = 0, last = 0 }
        by[e.id] = s
        order[#order + 1] = s
      end
      s.count = s.count + 1
      if ns:IsNew(e) then s.new = s.new + 1 end
      if e.t >= s.last then s.last = e.t; s.label = ns.Label(e) end
    end
  end
  table.sort(order, function(a, b)
    if (a.new > 0) ~= (b.new > 0) then return a.new > 0 end
    return a.last > b.last
  end)
  return order
end

function UI:RefreshDetails()
  local d = self.details
  if not d or not d:IsShown() then return end

  local all = { label = "All friends", count = 0, new = 0 }
  local entries = { all }
  local selectedLabel
  for _, s in ipairs(self:FriendSummaries()) do
    all.count = all.count + s.count
    all.new = all.new + s.new
    entries[#entries + 1] = s
    if s.id == d.selected then selectedLabel = s.label end
  end

  d.listOffset = math.max(0, math.min(d.listOffset, #entries - #d.friendRows))
  for i, b in ipairs(d.friendRows) do
    local s = entries[i + d.listOffset]
    if s then
      b.id = s.id
      b.name:SetText(s.label)
      b.badge:SetText(s.new > 0 and gold(s.new .. " new") or ("|cff888888" .. s.count .. "|r"))
      b.sel:SetShown(s.id == d.selected)
      b:Show()
    else
      b:Hide()
    end
  end

  local hist, newCount, log = {}, 0, ns.db.log
  for i = #log, 1, -1 do
    local e = log[i]
    if not e.self and (d.selected == nil or e.id == d.selected) then
      hist[#hist + 1] = e
      if ns:IsNew(e) then newCount = newCount + 1 end
    end
  end
  local rows = d.numRows or #d.histRows
  d.histOffset = math.max(0, math.min(d.histOffset, #hist - rows))
  -- one friend can play several characters, so show names unless they're all the same
  local showNames = d.selected == nil
  for i = 2, #hist do
    if hist[i].who ~= hist[1].who or hist[i].rs ~= hist[1].rs then showNames = true; break end
  end
  for i = 1, rows do SetRow(d.histRows[i], hist[i + d.histOffset], showNames) end

  d.header:SetText(d.selected and (selectedLabel or "Friend") or "All friends")
  local sub = #hist .. " milestone" .. (#hist == 1 and "" or "s")
  if newCount > 0 then sub = sub .. "   " .. gold(newCount .. " new since you were last on") end
  if #hist > rows then sub = sub .. "   |cff888888(scroll for more)|r" end
  d.sub:SetText(sub)
  d.empty:SetShown(#hist == 0)
end

function UI:OpenDetails(who)
  local d = self.details
  if d:IsShown() and d.selected ~= who then ns:MarkRead(d.selected) end
  d.selected = who
  d.histOffset = 0
  d:Show()
  self:RefreshDetails()
end

function UI:ToggleDetails()
  if self.details:IsShown() then self.details:Hide() else self:OpenDetails(nil) end
end

---------------------------------------------------------------------------
-- Wiring
---------------------------------------------------------------------------
function UI:RequestRefresh(flashEv)
  if flashEv then self.pendingFlash = flashEv end
  if self.refreshPending then return end
  self.refreshPending = true
  C_Timer.After(0.05, function()
    self.refreshPending = false
    local fe = self.pendingFlash
    self.pendingFlash = nil
    self:RefreshFeed(fe)
    self:RefreshDetails()
  end)
end

ns:On("DB_READY", function()
  restoreVolume() -- in case the game closed while a quieter sound was playing
  UI:CreateFeed()
  UI:CreateToast()
  UI:CreateDetails()
  UI:RequestRefresh()
end)

ns:On("EVENT_ADDED", function(ev, source)
  local isLive = source == "live" or source == "demo"
  local wanted = not ev.self and ns:Wants(ev)
  -- a live milestone that gets a pop-up lights its row up when the pop-up
  -- lands on it (UI:Landed); the others flash as soon as they appear
  local toast = isLive and wanted and ns.db.settings.toasts
  UI:RequestRefresh((isLive and not toast) and ev or nil)
  if not wanted then return end
  if isLive then
    UI:QueueToast(UI:ToastFromEvent(ev))
  elseif (source == "catchup" or source == "inbox") and ns:IsNew(ev) then
    UI:QueueCatchup(ev)
  end
end)

local ef = CreateFrame("Frame")
ef:RegisterEvent("GET_ITEM_INFO_RECEIVED")
ef:SetScript("OnEvent", function() UI:RequestRefresh() end)

-- keep the "5m / 2h" labels current
C_Timer.NewTicker(30, function()
  if UI.feed and UI.feed:IsShown() then UI:RefreshFeed() end
  UI:RefreshDetails()
end)

-- fade the feed down when it's been quiet, back up when something happens
C_Timer.NewTicker(2, function()
  if UI.feed and UI.feed:IsShown() then
    UI:CheckHover()
    UI:UpdateFeedDim()
  end
end)
