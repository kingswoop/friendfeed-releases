-- Friend Feed inbox.
-- The companion app replaces this file with your friends' activity before you
-- log in (or before a /reload). Don't edit it by hand.
--
-- events: { id = "<friend's BattleTag>", who = "<character name>", rs = "<ruleset>",
--           t = <unix time>, k = "loot"|"level"|"ach"|"mount"|"pet"|"toy"|"death",
--           v = <itemID / level / achievementID / mountID / speciesID>, q = <quality>, n = "<name>",
--           s = "<where it came from, e.g. Baron Rivendare, Stratholme>" (optional, v0.7) }
--   id groups a friend's characters into one history; who + rs is shown, e.g. "Grommash (RP-PvP)".
--   rs is the label the sender's addon reported (Normal, PvP, RP, RP-PvP, Hardcore); keep it as is.
--   Version 1 files (no id/rs) still load: the character name is used as the id.
-- ackedUntil: newest timestamp of YOUR events the server has stored, so the
--             addon can drop them from its outbox.

FriendFeedInbox = {
  version = 2,
  generatedAt = 0,
  ackedUntil = 0,
  events = {},
}
