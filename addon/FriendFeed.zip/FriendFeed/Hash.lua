-- SHA-256 and HMAC-SHA256 in plain Lua, for live following's tokens (0.9.8).
-- A follower's hello carries a token the server made from the followed
-- player's secret and the follower's character; the followed player's addon
-- recomputes it here and answers only when it matches. Nothing else uses this.
--
-- Numbers are kept as unsigned 32-bit values in Lua doubles. The game's bit
-- library (LuaBitOp) does the bitwise work when it gives right answers; if
-- it's missing or odd, plain arithmetic takes over (slower, always right).
-- The choice is made once, by hashing "abc" and checking the known digest.
local _, ns = ...

-- Everything is done in floating point on purpose: the game's Lua has only
-- doubles, and the test runner's integers are 32-bit, so a literal above
-- 2^31 wraps there. Constants are brought back into range with % MOD.
local MOD = 2 ^ 32

---------------------------------------------------------------------------
-- Bitwise operations, two ways
---------------------------------------------------------------------------
local function pureBxor(a, b)
  local r, p = 0, 1.0
  while a > 0 or b > 0 do
    local x, y = a % 2, b % 2
    if x ~= y then r = r + p end
    a, b, p = (a - x) / 2, (b - y) / 2, p * 2
  end
  return r
end

local function pureBand(a, b)
  local r, p = 0, 1.0
  while a > 0 and b > 0 do
    local x, y = a % 2, b % 2
    if x == 1 and y == 1 then r = r + p end
    a, b, p = (a - x) / 2, (b - y) / 2, p * 2
  end
  return r
end

local function pureBor(a, b)
  local r, p = 0, 1.0
  while a > 0 or b > 0 do
    local x, y = a % 2, b % 2
    if x == 1 or y == 1 then r = r + p end
    a, b, p = (a - x) / 2, (b - y) / 2, p * 2
  end
  return r
end

local function pureBnot(a) return MOD - 1 - a end
local function pureRshift(a, n) return math.floor(a / 2 ^ n) end
local function pureLshift(a, n) return (a * 2 ^ n) % MOD end

local pure = {
  bxor = pureBxor, band = pureBand, bor = pureBor, bnot = pureBnot, rshift = pureRshift, lshift = pureLshift,
}

local fast
if type(bit) == "table" and bit.band and bit.bor and bit.bxor and bit.bnot and bit.rshift and bit.lshift then
  local b = bit
  fast = {
    bxor = function(x, y) return b.bxor(x, y) % MOD end,
    band = function(x, y) return b.band(x, y) % MOD end,
    bor = function(x, y) return b.bor(x, y) % MOD end,
    bnot = function(x) return b.bnot(x) % MOD end,
    rshift = function(x, n) return b.rshift(x, n) % MOD end,
    lshift = function(x, n) return b.lshift(x, n) % MOD end,
  }
end

---------------------------------------------------------------------------
-- SHA-256 (FIPS 180-4)
---------------------------------------------------------------------------
local K = {
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
}
for i = 1, #K do K[i] = K[i] % MOD end
local H0 = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 }
for i = 1, #H0 do H0[i] = H0[i] % MOD end

local function makeSha256(ops)
  local bxor, band, bor, bnot, rshift, lshift = ops.bxor, ops.band, ops.bor, ops.bnot, ops.rshift, ops.lshift
  local function rrot(x, n) return bor(rshift(x, n), lshift(x, 32 - n)) end

  local function be32(n)
    local a = math.floor(n / 16777216) % 256
    local b = math.floor(n / 65536) % 256
    local c = math.floor(n / 256) % 256
    local d = n % 256
    return string.char(a, b, c, d)
  end

  -- raw 32-byte digest of a string
  return function(msg)
    local h0, h1, h2, h3 = H0[1], H0[2], H0[3], H0[4]
    local h4, h5, h6, h7 = H0[5], H0[6], H0[7], H0[8]
    local len = #msg
    local bits = len * 8
    msg = msg .. "\128" .. string.rep("\0", (55 - len) % 64) .. be32(math.floor(bits / MOD)) .. be32(bits % MOD)
    local w = {}
    for chunk = 1, #msg, 64 do
      for i = 0, 15 do
        local a, b, c, d = msg:byte(chunk + i * 4, chunk + i * 4 + 3)
        w[i] = ((a * 256.0 + b) * 256 + c) * 256 + d
      end
      for i = 16, 63 do
        local x, y = w[i - 15], w[i - 2]
        local s0 = bxor(bxor(rrot(x, 7), rrot(x, 18)), rshift(x, 3))
        local s1 = bxor(bxor(rrot(y, 17), rrot(y, 19)), rshift(y, 10))
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) % MOD
      end
      local a, b, c, d, e, f, g, h = h0, h1, h2, h3, h4, h5, h6, h7
      for i = 0, 63 do
        local S1 = bxor(bxor(rrot(e, 6), rrot(e, 11)), rrot(e, 25))
        local ch = bxor(band(e, f), band(bnot(e), g))
        local t1 = (h + S1 + ch + K[i + 1] + w[i]) % MOD
        local S0 = bxor(bxor(rrot(a, 2), rrot(a, 13)), rrot(a, 22))
        local maj = bxor(bxor(band(a, b), band(a, c)), band(b, c))
        local t2 = (S0 + maj) % MOD
        h, g, f, e, d, c, b, a = g, f, e, (d + t1) % MOD, c, b, a, (t1 + t2) % MOD
      end
      h0, h1, h2, h3 = (h0 + a) % MOD, (h1 + b) % MOD, (h2 + c) % MOD, (h3 + d) % MOD
      h4, h5, h6, h7 = (h4 + e) % MOD, (h5 + f) % MOD, (h6 + g) % MOD, (h7 + h) % MOD
    end
    return be32(h0) .. be32(h1) .. be32(h2) .. be32(h3) .. be32(h4) .. be32(h5) .. be32(h6) .. be32(h7)
  end
end

local function hex(raw)
  return (raw:gsub(".", function(ch) return string.format("%02x", ch:byte()) end))
end

local KNOWN_ABC = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
local sha256raw = makeSha256(pure)
ns.HashUsesBit = false
if fast then
  local candidate = makeSha256(fast)
  local ok, digest = pcall(candidate, "abc")
  if ok and hex(digest) == KNOWN_ABC then
    sha256raw = candidate
    ns.HashUsesBit = true
  end
end

function ns.Sha256(msg) return hex(sha256raw(msg)) end
ns.HashOps = { pure = pure, fast = fast } -- for tests

---------------------------------------------------------------------------
-- HMAC-SHA256 (RFC 2104), hex
---------------------------------------------------------------------------
local function pad(key, byte)
  local out = {}
  for i = 1, 64 do
    local k = key:byte(i) or 0
    out[i] = string.char(pure.bxor(k, byte))
  end
  return table.concat(out)
end

function ns.HmacSha256(key, msg)
  key = tostring(key or "")
  if #key > 64 then key = sha256raw(key) end
  local inner = sha256raw(pad(key, 0x36) .. tostring(msg or ""))
  return hex(sha256raw(pad(key, 0x5c) .. inner))
end

-- The token a follower presents when saying hello: the followed player's
-- secret over the follower's character key ("name-ruleset", lower case,
-- ruleset squashed), 16 hex characters. The server makes the same one.
ns.LIVE_TOKEN_LEN = 16
function ns.LiveToken(secret, charKey)
  if not (type(secret) == "string" and secret ~= "" and type(charKey) == "string" and charKey ~= "") then return nil end
  return ns.HmacSha256(secret, "ff1:" .. charKey):sub(1, ns.LIVE_TOKEN_LEN)
end

-- The character key the tokens are keyed by, from a name and ruleset label
function ns.LiveKey(who, rs)
  if not (type(who) == "string" and who ~= "") then return nil end
  return who:lower() .. "-" .. ns.Squash(rs or "")
end
