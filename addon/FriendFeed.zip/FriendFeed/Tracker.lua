-- Detects YOUR milestones and records them, with a note of where each one
-- came from ("Baron Rivendare, Stratholme", "Bought from Katie Hunter",
-- "Killed by Son of Arugal"). Only the sender knows that context, so it's
-- worked out here and sent along with the event (ev.s).
--
-- Forever refuses addons the combat log (COMBAT_LOG_EVENT_UNFILTERED is a
-- "Blizzard UI only" event there, confirmed in game 2026-11-07), so kill
-- names and death causes come from the units around you instead: the corpse
-- under your mouse or your target. World PvP kills come from the honor line
-- in chat and the honorable kill count (see below).
local _, ns = ...

local f = CreateFrame("Frame")
local handlers = {}
local usable = ns.Usable

-- Turn a localized format string like "You receive loot: %s." into a Lua pattern
local function fmtToPattern(fmt)
  if type(fmt) ~= "string" then return nil end
  local p = fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
  p = p:gsub("%%%%s", "(.+)"):gsub("%%%%d", "(%%d+)")
  return "^" .. p
end

-- self-loot chat patterns, each tagged with how the item arrived
local SELF_LOOT = {}
for _, entry in ipairs({
  { "LOOT_ITEM_SELF", "loot" }, { "LOOT_ITEM_SELF_MULTIPLE", "loot" },
  { "LOOT_ITEM_PUSHED_SELF", "pushed" }, { "LOOT_ITEM_PUSHED_SELF_MULTIPLE", "pushed" },
  { "LOOT_ITEM_CREATED_SELF", "created" }, { "LOOT_ITEM_CREATED_SELF_MULTIPLE", "created" },
}) do
  local pat = fmtToPattern(_G[entry[1]])
  if pat then SELF_LOOT[#SELF_LOOT + 1] = { pat, entry[2] } end
end

-- "loot" (from a loot window), "pushed" (quest reward, vendor, mail, trade),
-- "created" (crafted), or nil when it's someone else's
local function selfLootKind(text)
  for _, p in ipairs(SELF_LOOT) do
    if text:find(p[1]) then return p[2] end
  end
  return nil
end

---------------------------------------------------------------------------
-- Context: what's open and what just happened around you
---------------------------------------------------------------------------
local ctx = {
  loot = {},      -- itemID -> { src = "Baron Rivendare" or nil, t } from the loot window
  got = {},       -- itemID -> { s, t }: every item you received, so a mount or toy
                  --   learned from it later knows where it came from
  nGot = 0,
  vendor = nil,   -- the vendor's name while a shop is open
  mail = false,   -- the mailbox is open
  trade = nil,    -- who you're trading with
  quest = nil,    -- { title, t } of the quest you just turned in
  encounter = nil,-- { name, t } of the boss you just beat
}
local LOOT_WINDOW = 120   -- seconds the loot window's source names stay valid
local GOT_WINDOW = 3600   -- seconds to remember where an item came from (for mounts/toys)
local QUEST_WINDOW = 15
local ENCOUNTER_WINDOW = 600

local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b, c, d, e = pcall(fn, ...)
  if ok then return a, b, c, d, e end
  return nil
end

-- "Molten Core" inside an instance, otherwise the zone you're in
local function place()
  local inInstance = call(IsInInstance)
  if inInstance then
    local name = call(GetInstanceInfo)
    if usable(name) then return name end
  end
  local zone = call(GetRealZoneText)
  if not usable(zone) then zone = call(GetZoneText) end
  return usable(zone) and zone or nil
end
ns.Place = place

local function join(a, b)
  if a and b and a ~= b then return a .. ", " .. b end
  return a or b
end

-- How notable a loot source is: "boss" (the boss you just beat, a world boss,
-- a skull-level elite in a dungeon) or "rare" (a rare or rare elite), nil for
-- anything ordinary. The game doesn't tell addons drop chances, so this is
-- how friends get a sense of how rare a drop was.
local function rank(unit, name)
  local e = ctx.encounter
  if name and e and e.name == name and GetTime() - e.t < ENCOUNTER_WINDOW then return "boss" end
  if call(UnitIsBossMob, unit) == true then return "boss" end
  local c = call(UnitClassification, unit)
  if c == "worldboss" then return "boss" end
  if c == "rare" or c == "rareelite" then return "rare" end
  if call(IsInInstance) and call(UnitLevel, unit) == -1 then return "boss" end
  return nil
end

-- Who or what a loot source GUID is: the corpse under your mouse (you just
-- clicked it), your target, or the thing you're interacting with, and how
-- notable it is. Chests and other objects have no name.
local function sourceOf(guid)
  if not usable(guid) then return nil end
  for _, unit in ipairs({ "mouseover", "target", "npc" }) do
    local g = call(UnitGUID, unit)
    if usable(g) and g == guid then
      local name = call(UnitName, unit)
      if usable(name) then return name, rank(unit, name) end
      return nil
    end
  end
  return nil
end

-- "Boss drop: Baron Rivendare, Stratholme" (Core.lua turns the prefix into a coloured tag)
local TAG_PREFIX = { boss = "Boss drop: ", rare = "Rare mob: " }
local function tagged(how, s)
  if not (s and TAG_PREFIX[how]) then return s end
  return TAG_PREFIX[how] .. s
end

function handlers.LOOT_OPENED()
  local now = GetTime()
  local fishing = call(IsFishingLoot)
  local n = call(GetNumLootItems) or 0
  for slot = 1, n do
    local link = call(GetLootSlotLink, slot)
    local itemID = usable(link) and tonumber(link:match("|Hitem:(%d+)")) or nil
    if itemID then
      local src, how
      if fishing then
        src = "Fishing"
      else
        src, how = sourceOf((call(GetLootSourceInfo, slot)))
      end
      ctx.loot[itemID] = { src = src, how = how, t = now }
    end
  end
end

local function npcName()
  local name = call(UnitName, "npc")
  return usable(name) and name or nil
end
function handlers.MERCHANT_SHOW() ctx.vendor = npcName() or "a vendor" end
function handlers.MERCHANT_CLOSED() ctx.vendor = nil end
function handlers.MAIL_SHOW() ctx.mail = true end
function handlers.MAIL_CLOSED() ctx.mail = false end
function handlers.TRADE_SHOW() ctx.trade = npcName() or "someone" end
function handlers.TRADE_CLOSED() ctx.trade = nil end

-- the quest you're handing in (QUEST_COMPLETE opens the reward page,
-- QUEST_TURNED_IN confirms it; the reward item arrives right after)
function handlers.QUEST_COMPLETE()
  local title = call(GetTitleText)
  if usable(title) then ctx.quest = { title = title, t = GetTime() } end
end
function handlers.QUEST_TURNED_IN(questID)
  local title
  if C_QuestLog and C_QuestLog.GetTitleForQuestID and questID then
    title = call(C_QuestLog.GetTitleForQuestID, questID)
  end
  if not usable(title) and ctx.quest then title = ctx.quest.title end
  if usable(title) then ctx.quest = { title = title, t = GetTime() } end
end

function handlers.ENCOUNTER_START(_, name)
  if usable(name) then ctx.encounter = { name = name, t = GetTime() } end
end
function handlers.ENCOUNTER_END(_, name, _, _, success)
  if usable(name) and (success == 1 or success == true) then
    ctx.encounter = { name = name, t = GetTime() }
  else
    ctx.encounter = nil
  end
end

-- What killed you: the enemy you had targeted when you died, if it's still
-- standing. (The combat log, which would say for sure, is closed to addons.)
local function killer()
  if not call(UnitExists, "target") then return nil end
  if UnitCanAttack and not call(UnitCanAttack, "player", "target") then return nil end
  if call(UnitIsDeadOrGhost, "target") then return nil end
  local name
  if call(UnitIsPlayer, "target") then name = ns.FullUnitName("target") end
  if not usable(name) then name = call(UnitName, "target") end
  if not usable(name) then return nil end
  return "Killed by " .. name
end

-- Where an item you just received came from.
-- how: "loot" (loot window), "pushed" (quest, vendor, mail, trade), "created"
local function lootSource(itemID, how)
  local now = GetTime()
  local where = place()
  if how == "created" then return "Crafted" end
  if how == "pushed" then
    if ctx.vendor then return "Bought from " .. ctx.vendor end
    if ctx.mail then return "From the mailbox" end
    if ctx.trade then return "Trade with " .. ctx.trade end
    if ctx.quest and now - ctx.quest.t < QUEST_WINDOW then return "Quest: " .. ctx.quest.title end
  end
  local l = ctx.loot[itemID]
  ctx.loot[itemID] = nil -- each loot window entry is used once
  if l and now - l.t < LOOT_WINDOW and l.src then return tagged(l.how, join(l.src, where)) end
  local e = ctx.encounter
  if e and now - e.t < ENCOUNTER_WINDOW then return tagged("boss", join(e.name, where)) end
  return where
end

local function rememberGot(itemID, s)
  if ctx.nGot >= 100 then wipe(ctx.got); ctx.nGot = 0 end
  if not ctx.got[itemID] then ctx.nGot = ctx.nGot + 1 end
  ctx.got[itemID] = { s = s, t = GetTime() }
end

-- The source of a recently received item that `teaches` this mount or toy
local function taughtBy(teaches)
  local now = GetTime()
  local best
  for itemID, g in pairs(ctx.got) do
    if now - g.t < GOT_WINDOW and teaches(itemID) and (not best or g.t > best.t) then best = g end
  end
  return best and best.s or nil
end

---------------------------------------------------------------------------
-- Milestones
---------------------------------------------------------------------------
local function recordLoot(itemID, source)
  local item = Item:CreateFromItemID(itemID)
  item:ContinueOnItemLoad(function()
    local q = item:GetItemQuality()
    if q and q >= (ns.db.settings.minQuality or 3) then
      ns:RecordSelf("loot", itemID, q, item:GetItemName(), source)
    end
  end)
end

function handlers.PLAYER_LEVEL_UP(level)
  ns:RecordSelf("level", level, nil, nil, place())
end

function handlers.CHAT_MSG_LOOT(text)
  -- loot messages can be hidden from addons during encounters
  if type(text) ~= "string" or ns.IsSecret(text) then return end
  local how = selfLootKind(text)
  if not how then return end
  local itemID = tonumber(text:match("|Hitem:(%d+)"))
  if not itemID then return end
  local source = lootSource(itemID, how)
  rememberGot(itemID, source)
  recordLoot(itemID, source)
end

function handlers.ACHIEVEMENT_EARNED(achievementID, alreadyEarned)
  if alreadyEarned then return end
  local name
  if GetAchievementInfo then name = select(2, GetAchievementInfo(achievementID)) end
  ns:RecordSelf("ach", achievementID, nil, name)
end

function handlers.NEW_MOUNT_ADDED(mountID)
  local name
  if C_MountJournal and C_MountJournal.GetMountInfoByID then
    name = C_MountJournal.GetMountInfoByID(mountID)
  end
  -- learned from an item you picked up recently? then we know where that came from
  local source = taughtBy(function(itemID)
    return C_MountJournal and call(C_MountJournal.GetMountFromItem, itemID) == mountID
  end)
  ns:RecordSelf("mount", mountID, 4, name, source)
end

function handlers.NEW_PET_ADDED(petGUID)
  if not (C_PetJournal and C_PetJournal.GetPetInfoByPetID) then return end
  local speciesID, customName, _, _, _, _, _, name = C_PetJournal.GetPetInfoByPetID(petGUID)
  if speciesID then ns:RecordSelf("pet", speciesID, 2, name or customName) end
end

-- The game's "Total deaths" statistic for this character (a number, or nil)
local TOTAL_DEATHS_STAT = 60
local function deathStatistic()
  local v = call(GetStatistic, TOTAL_DEATHS_STAT)
  return tonumber(v) -- "--" (none yet) or a missing function give nil
end
ns.DeathStatistic = deathStatistic
local DEATH_DELAY = 1.5 -- seconds: lets the game count this death in its statistic first

function handlers.PLAYER_DEAD()
  if not ns.db.settings.shareDeaths then return end
  -- battlegrounds and arenas would flood your friends with deaths
  local _, instanceType = IsInInstance()
  if instanceType == "pvp" or instanceType == "arena" then return end
  -- what we know now: where, at what level, and what killed you
  local level = UnitLevel("player") or 0
  local zone = (GetRealZoneText and GetRealZoneText()) or (GetZoneText and GetZoneText())
  if not usable(zone) then zone = nil end
  local cause = killer()
  C_Timer.After(DEATH_DELAY, function()
    -- the game's Total deaths statistic: this character's whole life, this death included
    local total = deathStatistic()
    ns:RecordSelf("death", level, nil, zone, cause, (total and total > 0) and total or nil)
  end)
end

---------------------------------------------------------------------------
-- World PvP kills (v0.9.0). No combat log on Forever, so two signals from
-- the game: the honor line in chat ("Varian Holt dies, honorable kill ...",
-- CHAT_MSG_COMBAT_HONOR_GAIN), which says who died, and your lifetime
-- honorable kill count (GetPVPLifetimeStats, checked on
-- PLAYER_PVP_KILLS_CHANGED), which catches a kill whose line never came.
-- Both mean any honorable kill you took part in: the game doesn't tell
-- addons who landed the killing blow. Kills close together are one
-- milestone ("killed 3 players"), recorded once the fight has gone quiet.
-- Never in battlegrounds or arenas.
---------------------------------------------------------------------------
local KILL_QUIET = 5    -- seconds without another kill before the milestone goes out (30 before 0.9.9)
local KILL_MAX = 120    -- a long fight still goes out by then
local KILL_COUNT_WAIT = 3 -- seconds the honor line gets to arrive after the count goes up
local KILL_NAMES = 4    -- names kept for one milestone (the rest are just counted)

-- "%s dies, honorable kill Rank: %s (%d Honor Points)" and friends -> patterns
-- whose first capture is who died
local HONOR_KILL = {}
for _, key in ipairs({ "COMBATLOG_HONORGAIN", "COMBATLOG_HONORGAIN_NO_RANK" }) do
  local fmt = _G[key]
  if type(fmt) == "string" then
    local pat = fmtToPattern(fmt:gsub("%%%d%$", "%%"))
    if pat then HONOR_KILL[#HONOR_KILL + 1] = pat end
  end
end
HONOR_KILL[#HONOR_KILL + 1] = "^(.+) dies, honorable kill"
ns.HONOR_KILL = HONOR_KILL

local function inWorldPvP()
  local _, instanceType = call(IsInInstance)
  return instanceType ~= "pvp" and instanceType ~= "arena"
end

-- your lifetime honorable kills, or nil when the client doesn't say
local function honorableKills()
  return tonumber((call(GetPVPLifetimeStats)))
end
ns.HonorableKills = honorableKills

-- an enemy player who just died, as your target or under your mouse:
-- their name and level, if it matches `name` (or any, when name is nil)
local function deadEnemy(name)
  for _, unit in ipairs({ "target", "mouseover" }) do
    if call(UnitExists, unit) and call(UnitIsPlayer, unit) and call(UnitIsDeadOrGhost, unit)
      and (not UnitCanAttack or call(UnitCanAttack, "player", unit)) then
      local full = ns.FullUnitName(unit)
      local short = call(UnitName, unit)
      if name == nil or name == full or name == short then
        local level = tonumber((call(UnitLevel, unit)))
        return usable(full) and full or short, (level and level > 0) and level or nil
      end
    end
  end
  return nil
end

local kills = {
  fight = nil, -- { first, last, count, names = {}, level, place, gen }
  seen = nil,  -- lifetime honorable kills when last read
  named = 0,   -- kills the honor line named since the count was last read
}
ns.kills = kills

local function recordFight()
  local fight = kills.fight
  kills.fight = nil
  if not fight or fight.count < 1 then return end
  local n
  if #fight.names > 0 then
    n = table.concat(fight.names, ", ")
    if fight.count == 1 and fight.level then n = n .. " (" .. fight.level .. ")" end
    n = n:sub(1, 60)
  end
  -- the game's lifetime honorable kills, sent along like the death total
  local total = honorableKills()
  ns:RecordSelf("kill", fight.count, nil, n, fight.place, (total and total > 0) and total or nil)
end
ns.RecordFight = recordFight

-- one kill: name and level when known
local function addKill(name, level)
  if not (ns.db and ns.db.settings.shareKills) or not inWorldPvP() then return end
  local now = GetTime()
  local fight = kills.fight
  if not fight then
    fight = { first = now, count = 0, names = {}, gen = 0 }
    kills.fight = fight
  end
  fight.count = fight.count + 1
  fight.last = now
  fight.place = place() or fight.place
  if usable(name) and #fight.names < KILL_NAMES then
    local dup = false
    for _, n in ipairs(fight.names) do if n == name then dup = true end end
    if not dup then fight.names[#fight.names + 1] = name end
  end
  fight.level = fight.count == 1 and level or nil
  if now - fight.first >= KILL_MAX then return recordFight() end
  fight.gen = fight.gen + 1
  local gen = fight.gen
  C_Timer.After(KILL_QUIET, function()
    if kills.fight == fight and fight.gen == gen then recordFight() end
  end)
end

-- the honor line: "Varian Holt dies, honorable kill Rank: Sergeant (12 Honor Points)"
function handlers.CHAT_MSG_COMBAT_HONOR_GAIN(text)
  if type(text) ~= "string" or ns.IsSecret(text) then return end
  local name
  for _, pat in ipairs(HONOR_KILL) do
    name = text:match(pat)
    if name then break end
  end
  if not usable(name) then return end -- bonus honor, not a kill
  name = name:gsub("|", ""):match("^%s*(.-)%s*$")
  local who, level = deadEnemy(name)
  kills.named = kills.named + 1
  addKill(who or name, level)
end

-- the count went up: any kill the honor line didn't name gets recorded too
local function checkKillCount()
  local hk = honorableKills()
  if not hk then return end
  if not kills.seen then kills.seen, kills.named = hk, 0; return end
  local extra = hk - kills.seen - kills.named
  kills.seen, kills.named = hk, 0
  -- a big jump is the game catching up (the count read 0 at login), not a fight
  if extra > 5 then return end
  for i = 1, math.max(extra, 0) do
    if i == 1 then addKill(deadEnemy(nil)) else addKill(nil) end
  end
end
ns.CheckKillCount = checkKillCount

function handlers.PLAYER_PVP_KILLS_CHANGED()
  C_Timer.After(KILL_COUNT_WAIT, checkKillCount)
end

-- /ff pvp: what the game tells us, to check it on Forever
function ns.PrintPvP()
  local hk = honorableKills()
  ns.Print("World PvP kills:", ns.db.settings.shareKills and "|cff00ff00shared|r" or "|cffff4040not shared|r")
  print("  honorable kills (lifetime): " .. (hk and tostring(hk) or "|cffff8040the game didn't say|r"))
  print("  honor line in chat: " .. (type(_G.COMBATLOG_HONORGAIN) == "string" and _G.COMBATLOG_HONORGAIN or "|cffff8040not known to this client|r"))
  local fight = kills.fight
  if fight then print("  this fight so far: " .. fight.count .. " kill(s)") end
  print("  Kills in battlegrounds and arenas are never shared. Kill someone in the open world, wait 30 seconds, and it should show in your feed.")
end

---------------------------------------------------------------------------
-- Duels (0.9.8). The game prints a system line when a duel ends, for
-- everyone nearby: "Thrall Hellscream has defeated Arthas Menethil in a duel"
-- (DUEL_WINNER_KNOCKOUT) or "Arthas Menethil has fled from Thrall Hellscream
-- in a duel" (DUEL_WINNER_RETREAT). Only a duel you were in counts, won or
-- lost; the total comes from the game's Duels won / Duels lost statistics
-- (ids 319 and 320 in the Mainline client), read a moment later like a
-- death's, so this duel is in it. Live only: the app and server don't carry
-- the kind yet.
---------------------------------------------------------------------------
local DUEL_WON_STAT, DUEL_LOST_STAT = 319, 320
local DUEL_DELAY = 1.5
-- { pattern, winnerFirst }: which capture is the winner
local DUEL_LINES = {}
for _, key in ipairs({ "DUEL_WINNER_KNOCKOUT", "DUEL_WINNER_RETREAT" }) do
  local fmt = _G[key]
  if type(fmt) == "string" then
    local first = fmt:match("%%(%d)%$s") -- the first positional specifier, if any
    local pat = fmtToPattern(fmt:gsub("%%%d%$", "%%"))
    if pat then DUEL_LINES[#DUEL_LINES + 1] = { pat, first ~= "2" } end
  end
end
DUEL_LINES[#DUEL_LINES + 1] = { "^(.+) has defeated (.+) in a duel", true }
DUEL_LINES[#DUEL_LINES + 1] = { "^(.+) has fled from (.+) in a duel", false }
ns.DUEL_LINES = DUEL_LINES

local function isMe(name)
  if not usable(name) then return false end
  name = name:lower()
  local full = (ns.PlayerName() or ""):lower()
  local short = (call(UnitName, "player") or ""):lower()
  return name == full or (short ~= "" and name == short)
end

local function duelStatistic(won)
  return tonumber((call(GetStatistic, won and DUEL_WON_STAT or DUEL_LOST_STAT)))
end

function handlers.CHAT_MSG_SYSTEM(text)
  if type(text) ~= "string" or ns.IsSecret(text) then return end
  if not (ns.db and ns.db.settings.shareDuels) then return end
  local a, b, winnerFirst
  for _, line in ipairs(DUEL_LINES) do
    a, b = text:match(line[1])
    if a then winnerFirst = line[2]; break end
  end
  if not a then return end
  local winner, loser = a, b
  if not winnerFirst then winner, loser = b, a end
  winner = winner:gsub("|", ""):match("^%s*(.-)%s*$")
  loser = loser:gsub("|", ""):match("^%s*(.-)%s*$")
  local won
  if isMe(winner) then won = true elseif isMe(loser) then won = false else return end -- someone else's duel
  local other = won and loser or winner
  local where = place()
  C_Timer.After(DUEL_DELAY, function()
    local total = duelStatistic(won)
    ns:RecordSelf("duel", won and 1 or 2, nil, other, where, (total and total > 0) and total or nil)
  end)
end

function handlers.NEW_TOY_ADDED(itemID)
  local name
  if C_ToyBox and C_ToyBox.GetToyInfo then
    local _, n = C_ToyBox.GetToyInfo(itemID)
    name = n
  end
  ns:RecordSelf("toy", itemID, 3, name, taughtBy(function(id) return id == itemID end))
end

f:SetScript("OnEvent", function(_, event, ...)
  if ns.trackReady and handlers[event] then handlers[event](...) end
end)

-- Register for the game events, one at a time. Some may not exist in every
-- client (a plain error, skipped), and the game may refuse one outright
-- ("blocked from an action only available to the Blizzard UI"): Core.lua
-- notes which event that was (ns.registering) in FriendFeedDB.forbidden,
-- so it's never asked for again, and /ff blocked names it.
local EVENT_ORDER = {
  "PLAYER_LEVEL_UP", "CHAT_MSG_LOOT", "ACHIEVEMENT_EARNED", "NEW_MOUNT_ADDED", "NEW_PET_ADDED",
  "NEW_TOY_ADDED", "PLAYER_DEAD", "LOOT_OPENED", "MERCHANT_SHOW", "MERCHANT_CLOSED", "MAIL_SHOW",
  "MAIL_CLOSED", "TRADE_SHOW", "TRADE_CLOSED", "QUEST_COMPLETE", "QUEST_TURNED_IN",
  "ENCOUNTER_START", "ENCOUNTER_END", "CHAT_MSG_COMBAT_HONOR_GAIN", "PLAYER_PVP_KILLS_CHANGED",
  "CHAT_MSG_SYSTEM",
}
ns:On("DB_READY", function()
  local forbidden = ns.db and ns.db.forbidden or {}
  local seen = {}
  local function register(event)
    if seen[event] or not handlers[event] or forbidden[event] then return end
    seen[event] = true
    ns.registering = event
    pcall(f.RegisterEvent, f, event)
    ns.registering = nil
  end
  for _, event in ipairs(EVENT_ORDER) do register(event) end
  for event in pairs(handlers) do register(event) end -- anything not listed above
end)

ns:On("LOGIN", function()
  -- ignore collection events the client fires while loading in
  C_Timer.After(5, function()
    ns.trackReady = true
    kills.seen, kills.named = honorableKills(), 0 -- where the kill count starts
  end)
end)
