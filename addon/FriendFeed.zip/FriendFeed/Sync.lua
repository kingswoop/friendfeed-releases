-- Live sharing between friends who are online at the same time.
-- Messages (tab separated):
--   E/C  t  k  v  q  name  who  ruleset  source   E = live milestone, C = catch-up milestone
--   H    since                                    hello: send me what I missed
--   P    version                                  ping: "are you there?" (/ff ping)
--   A    version                                  answer to a ping
-- "who" and "ruleset" were added in v0.4 (the event may be from one of the
-- sender's other characters). Older senders stop after "name"; the sender's
-- current character is used instead. "source" (v0.7) is where it came from,
-- e.g. "Baron Rivendare, Stratholme"; older senders leave it out.
local _, ns = ...

local Sync = {}
ns.Sync = Sync

local SEP = "\t"
local MAX_NAME = 60
local MAX_SHORT = 24 -- ruleset labels
local MAX_WHO = 48   -- character names: Forever characters have first and last names
local MAX_QUEUE = 300
local CATCHUP_LIMIT = 15
local PING_COOLDOWN = 10 -- seconds between pings shown from the same friend

local queue = {}
local friendChars = {} -- char key ("char:name-realm") -> friend id (BattleTag or the char key)
local bnByGame = {}    -- Battle.net game account ID -> { id, who, rs } for friends online in this game
local bnTargets = {}   -- Battle.net game account IDs to send to
local charTargets = {} -- character names ("Name" or "Name-Realm") to whisper
local lastRefresh = 0
local lastPing = {}    -- friend id -> GetTime() of the last ping we showed
local toldVersion = {} -- friend id -> true once we told them a newer version is out

---------------------------------------------------------------------------
-- Friend lists
---------------------------------------------------------------------------
local function eachGameAccount(i, acc, fn)
  local BN = C_BattleNet
  local n = BN.GetFriendNumGameAccounts and BN.GetFriendNumGameAccounts(i)
  if n and n > 0 and BN.GetFriendGameAccountInfo then
    for j = 1, n do
      local g = BN.GetFriendGameAccountInfo(i, j)
      if g then fn(g) end
    end
  elseif acc.gameAccountInfo then
    fn(acc.gameAccountInfo)
  end
end

function Sync:Refresh(force)
  if not force and GetTime() - lastRefresh < 5 then return end
  lastRefresh = GetTime()
  wipe(friendChars); wipe(bnByGame); wipe(bnTargets); wipe(charTargets)
  local covered = {} -- char keys we already reach over Battle.net

  -- the full Battle.net friend list (online or not) is saved for the companion
  -- app, which uploads it so the server can link friends who list each other
  local connected = BNConnected == nil or BNConnected()
  local tags = connected and {} or nil

  if BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo then
    for i = 1, (BNGetNumFriends()) do
      local acc = C_BattleNet.GetFriendAccountInfo(i)
      if acc then
        local tag = ns.Usable(acc.battleTag) and acc.battleTag or nil
        if tag and tags then tags[tag] = ns.Now() end
        eachGameAccount(i, acc, function(g)
          if g.isOnline and g.clientProgram == BNET_CLIENT_WOW
            and g.wowProjectID == WOW_PROJECT_ID and g.gameAccountID
            and ns.Usable(g.characterName) then
            local realm = ns.Usable(g.realmName) and g.realmName or nil
            local ck = realm and ns.CharKey(g.characterName, realm) or nil
            local id = tag or ck or ("bn:" .. g.gameAccountID)
            bnByGame[g.gameAccountID] = {
              id = id,
              who = g.characterName,
              rs = ns.Ruleset(g.realmDisplayName) or ns.Ruleset(realm),
            }
            -- remember which characters this friend plays (Friends tab)
            ns:NoteCharacter(id, g.characterName, bnByGame[g.gameAccountID].rs)
            bnTargets[#bnTargets + 1] = g.gameAccountID
            if ck then friendChars[ck] = id; covered[ck] = true end
          end
        end)
      end
    end
  end
  if tags and next(tags) and ns.db then
    ns.db.bnFriends = tags
    ns.db.bnFriendsComplete = true
  end

  if C_FriendList and C_FriendList.GetNumFriends then
    for i = 1, C_FriendList.GetNumFriends() do
      local info = C_FriendList.GetFriendInfoByIndex(i)
      if info and ns.Usable(info.name) then
        local ck = ns.CharKey(info.name)
        if not friendChars[ck] then friendChars[ck] = ck end
        if info.connected and not covered[ck] then
          covered[ck] = true
          charTargets[#charTargets + 1] = info.name
        end
      end
    end
  end
end

function Sync:PrintTargets()
  self:Refresh(true)
  ns.Print("Online friends Friend Feed can reach:")
  local any = false
  for gid, f in pairs(bnByGame) do
    any = true
    print("  Battle.net " .. gid .. ": " .. ns.Label(f, true) .. "  id " .. f.id)
  end
  for _, name in ipairs(charTargets) do
    any = true
    local n, realm = ns.SplitName(name)
    print("  Whisper: " .. ns.Label({ who = n, rs = ns.Ruleset(realm) }, true) .. "  id " .. friendChars[ns.CharKey(name)])
  end
  if not any then print("  nobody online right now") end
end

---------------------------------------------------------------------------
-- Sending (throttled, paused only while the game blocks addon messages)
---------------------------------------------------------------------------
-- Live milestones and ping answers jump ahead of catch-up replies, so a
-- friend logging in (up to 15 catch-up messages each) never delays them.
local bulk = {} -- catch-up ("C"), hello ("H") and version ("V") messages
local MAX_TRIES = 10 -- attempts per message when the game says "too fast" or "not now"
local holdTicks = 0  -- ticks to wait after the game refused a message

local function enqueue(kind, target, msg)
  local tag = msg:sub(1, 1)
  local q = (tag == "C" or tag == "H" or tag == "V") and bulk or queue
  if #queue + #bulk >= MAX_QUEUE then return end
  q[#q + 1] = { kind, target, msg }
end

-- Midnight blocks addon messages during boss encounters (and some instanced
-- content), not in ordinary combat, so only those pause the queue.
local function busy()
  if IsEncounterInProgress and IsEncounterInProgress() then return true end
  if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown then
    local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
    if ok and locked == true then return true end
  end
  return false
end

-- send results that mean "try again in a moment" (names from Enum.SendAddonMessageResult)
local RETRY = {}
do
  local R = Enum and Enum.SendAddonMessageResult
  if R then
    for _, name in ipairs({ "AddonMessageThrottle", "ChannelThrottle", "AddOnMessageLockdown", "AddonMessageLockdown" }) do
      if R[name] ~= nil then RETRY[R[name]] = true end
    end
  end
end

-- returns true if the game asked us to try again later
local function sendOne(item)
  local kind, target, msg = item[1], item[2], item[3]
  local ok, res
  if kind == "bn" then
    if BNSendGameData then ok, res = pcall(BNSendGameData, target, ns.PREFIX, msg) end
  elseif kind == "w" then
    ok, res = pcall(C_ChatInfo.SendAddonMessage, ns.PREFIX, msg, "WHISPER", target)
  elseif kind == "guild" then
    ok, res = pcall(C_ChatInfo.SendAddonMessage, ns.PREFIX, msg, "GUILD")
  end
  return ok and res ~= nil and RETRY[res] == true
end

C_Timer.NewTicker(0.3, function()
  if holdTicks > 0 then holdTicks = holdTicks - 1; return end
  local q = (#queue > 0) and queue or bulk
  if #q == 0 or busy() then return end
  local item = table.remove(q, 1)
  if sendOne(item) then
    item.tries = (item.tries or 0) + 1
    if item.tries < MAX_TRIES then table.insert(q, 1, item) end
    holdTicks = 3 -- about a second
  end
end)

local function clean(s, max)
  s = tostring(s or ""):gsub("[\t\r\n]", " ")
  return s:sub(1, max or MAX_NAME)
end

function Sync:Encode(ev, tag)
  local parts = {
    tag or "E", ev.t, ev.k, ev.v or 0, ev.q or 0, clean(ev.n),
    clean(ev.who, MAX_WHO), clean(ev.rs, MAX_SHORT),
  }
  -- where it came from, only when known (keeps messages short)
  if ns.Usable(ev.s) then parts[#parts + 1] = clean(ev.s, ns.MAX_SUB) end
  -- a death carries the player's total deaths as a 10th field (v0.8.4; older
  -- versions ignore it), with an empty source before it if there's none
  if ev.k == "death" and tonumber(ev.d) then
    if #parts < 9 then parts[#parts + 1] = "" end
    parts[#parts + 1] = math.floor(tonumber(ev.d))
  end
  return table.concat(parts, SEP)
end

function Sync:SendToAll(msg)
  self:Refresh(true)
  for _, id in ipairs(bnTargets) do enqueue("bn", id, msg) end
  for _, name in ipairs(charTargets) do enqueue("w", name, msg) end
  local guild = ns.db.settings.includeGuild and IsInGuild()
  if guild then enqueue("guild", nil, msg) end
  return #bnTargets + #charTargets, guild
end

function Sync:Broadcast(ev)
  self:SendToAll(self:Encode(ev, "E"))
end

function Sync:Hello()
  -- the version rides along so friends on an older one hear there's an update
  self:SendToAll(table.concat({ "H", ns.prevLogout or 0, ns.VERSION }, SEP))
end

-- /ff ping: check the connection to every online friend who has the addon
function Sync:Ping()
  local count, guild = self:SendToAll(table.concat({ "P", ns.VERSION }, SEP))
  if count == 0 and not guild then
    ns.Print("Nobody to ping. None of your friends are online in this game right now.")
    return
  end
  local where = count .. " online friend" .. (count == 1 and "" or "s")
  if guild then where = where .. " and your guild" end
  ns.Print("Pinging " .. where .. ". Friends with Friend Feed will answer in a few seconds.")
  if busy() then ns.Print("Addon messages are paused during this fight, so the ping will go out afterwards.") end
end

---------------------------------------------------------------------------
-- Receiving
---------------------------------------------------------------------------
local function split(s)
  local out = {}
  for part in (s .. SEP):gmatch("(.-)" .. SEP) do out[#out + 1] = part end
  return out
end

local function field(s) return (s and s ~= "") and s or nil end

-- from = { id, who, rs }: the friend who sent this and their current character
local function handle(text, from, replyKind, replyTarget)
  if type(text) ~= "string" or ns.IsSecret(text) then return end
  local p = split(text)
  local tag = p[1]
  if tag == "E" or tag == "C" then
    local q = tonumber(p[5])
    local who = field(p[7]) or from.who
    local rs = field(p[8])
    if not rs and who == from.who then rs = from.rs end
    ns:AddEvent({
      id = from.id, who = who, rs = rs,
      t = tonumber(p[2]), k = p[3], v = tonumber(p[4]),
      q = (q and q > 0) and q or nil,
      n = field(p[6]), s = field(p[9]), d = tonumber(p[10]),
      guild = from.guild or nil, -- from a guildmate who isn't a friend: the Guild tab's settings apply
    }, tag == "E" and "live" or "catchup")
  elseif tag == "H" then
    -- a friend just came online: send them our own milestones they missed
    local since = tonumber(p[2]) or 0
    local theirs = field(p[3]) -- nil from versions before 0.8.6
    ns:NoteVersion(theirs)
    -- they're on an older version: tell them ours, once per session
    if not toldVersion[from.id] and (not theirs or ns.NewerVersion(ns.VERSION, theirs)) then
      toldVersion[from.id] = true
      enqueue(replyKind, replyTarget, table.concat({ "V", ns.VERSION }, SEP))
    end
    local mine, log = {}, ns.db.log
    for i = #log, 1, -1 do
      local e = log[i]
      if e.self and e.t > since then
        mine[#mine + 1] = e
        if #mine >= CATCHUP_LIMIT then break end
      end
    end
    for i = #mine, 1, -1 do enqueue(replyKind, replyTarget, Sync:Encode(mine[i], "C")) end
  elseif tag == "V" then
    ns:NoteVersion(field(p[2]))
  elseif tag == "P" then
    ns:NoteVersion(field(p[2]))
    -- answer every ping, but only pop up once per friend every few seconds
    enqueue(replyKind, replyTarget, table.concat({ "A", ns.VERSION }, SEP))
    local now = GetTime()
    if now - (lastPing[from.id] or -PING_COOLDOWN) < PING_COOLDOWN then return end
    lastPing[from.id] = now
    ns.Print(ns.Label(from, true) .. " pinged you. Friend Feed is connected.")
    if ns.UI then
      ns.UI:QueueToast({
        icon = "Interface\\Icons\\INV_Misc_Note_02", title = ns.Label(from),
        body = "pinged you. Friend Feed is connected!", q = 2, sound = "summary", target = from.id,
      })
    end
  elseif tag == "A" then
    local version = field(p[2]) or "?"
    ns:NoteVersion(version)
    local note = (version ~= ns.VERSION) and ("  |cffff8040(they have v" .. version .. ", you have v" .. ns.VERSION .. ")|r") or ""
    ns.Print("|cff00ff00Connected:|r " .. ns.Label(from, true) .. " has Friend Feed v" .. version .. note)
  end
end

local function isGuildMember(fullName)
  if not IsInGuild() then return false end
  if C_GuildInfo and C_GuildInfo.MemberExistsByName then
    local ok, yes = pcall(C_GuildInfo.MemberExistsByName, fullName)
    if ok and yes then return true end
    local short = Ambiguate(fullName, "short")
    ok, yes = pcall(C_GuildInfo.MemberExistsByName, short)
    return ok and yes or false
  end
  return false
end

local function lookupChar(ck)
  Sync:Refresh()
  if not friendChars[ck] then Sync:Refresh(true) end -- they may have just been added or come online
  return friendChars[ck]
end

local function lookupGame(gameAccountID)
  Sync:Refresh()
  if not bnByGame[gameAccountID] then Sync:Refresh(true) end
  return bnByGame[gameAccountID]
end

local f = CreateFrame("Frame")
f:SetScript("OnEvent", function(_, event, ...)
  if event == "CHAT_MSG_ADDON" then
    local prefix, text, channel, sender = ...
    if ns.IsSecret(prefix) or ns.IsSecret(sender) or prefix ~= ns.PREFIX then return end
    Sync.lastSender = sender -- shown by /ff names, to see how the game writes two-part names
    local name, realm = ns.SplitName(sender)
    local ck = ns.CharKey(name, realm)
    if ck == ns.CharKey(ns.PlayerName(), ns.MyRealm()) then return end
    local from = { who = name, rs = ns.Ruleset(realm) }
    if channel == "WHISPER" then
      from.id = lookupChar(ck)
      -- guildmates answer a guild "hello" by whisper, so accept them too when guild sharing is on
      if not from.id and ns.db.settings.includeGuild and isGuildMember(sender) then
        from.id = ck
        from.guild = true
      end
      if not from.id then return end -- only accept from friends (and guildmates, if sharing with guild)
      if from.guild then ns:NoteGuildmate(from.id) end
      handle(text, from, "w", sender)
    elseif channel == "GUILD" and ns.db.settings.includeGuild then
      -- a friend who is also in the guild keeps their friend settings
      from.id = friendChars[ck] or ck
      from.guild = not friendChars[ck]
      if from.guild then ns:NoteGuildmate(from.id) end
      handle(text, from, "w", sender)
    end
  elseif event == "BN_CHAT_MSG_ADDON" then
    local prefix, text, _, senderID = ...
    if ns.IsSecret(prefix) or prefix ~= ns.PREFIX then return end
    local from = lookupGame(senderID)
    if not from then
      -- not in our list (another game version?): fall back to the character
      local info = C_BattleNet.GetGameAccountInfoByID(senderID)
      if not (info and ns.Usable(info.characterName)) then return end
      local realm = ns.Usable(info.realmName) and info.realmName or nil
      from = {
        id = realm and ns.CharKey(info.characterName, realm) or ("bn:" .. senderID),
        who = info.characterName,
        rs = ns.Ruleset(info.realmDisplayName) or ns.Ruleset(realm),
      }
    end
    handle(text, from, "bn", senderID)
  end
end)

ns:On("DB_READY", function()
  C_ChatInfo.RegisterAddonMessagePrefix(ns.PREFIX)
  f:RegisterEvent("CHAT_MSG_ADDON")
  f:RegisterEvent("BN_CHAT_MSG_ADDON")
end)

ns:On("LOGIN", function()
  C_Timer.After(8, function() Sync:Hello() end)
end)
