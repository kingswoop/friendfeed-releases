-- Settings window, also shown as a welcome/setup screen on first login.
-- Three tabs: General (what you share, what you're told about, pop-ups and
-- the feed's look), Sounds (volume and a sound per kind of alert) and
-- Friends (tick who you want alerts from).
local _, ns = ...

local S = {}
ns.Settings = S

local W = 460
local BODY_H = 564 -- General is the tallest (0.9.21: the row of loot extras); 564 is all a 768-unit screen allows
local SETUP_BODY_H = 540 -- the welcome screen shows General only, without its bottom buttons, and has to fit a 768-unit screen
local TAB_W = 57 -- seven tabs (General, Sounds, Guild, Friends, Following, Accolades, Help) across the window
local FRIEND_ROW_H = 22

StaticPopupDialogs["FRIENDFEED_DELETE_ALL"] = {
  text = "Delete ALL saved Friend Feed history?\nThis can't be undone.",
  button1 = YES,
  button2 = NO,
  OnAccept = function() ns:DeleteAll() end,
  timeout = 0,
  whileDead = true,
  hideOnEscape = true,
  preferredIndex = 3,
}

StaticPopupDialogs["FRIENDFEED_REMOVE_FRIEND"] = {
  text = "Stop tracking %s?\nTheir saved milestones are deleted and new ones are ignored. You can add them back under Removed.",
  button1 = YES,
  button2 = NO,
  OnAccept = function(_, data)
    if data then ns:RemoveFriend(data.id, data.label, data.guild); ns.Settings:RefreshOpenLists() end
  end,
  timeout = 0,
  whileDead = true,
  hideOnEscape = true,
  preferredIndex = 3,
}

local function ActionButton(parent, x, y, w, label, onClick)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, 22)
  b:SetPoint("TOPLEFT", x, y)
  b:SetText(label)
  b:SetScript("OnClick", onClick)
  return b
end

local function TestSounds()
  local UI = ns.UI
  local vol = ns.db.settings.soundVolume or 100
  if vol <= 0 then
    ns.Print("Sounds are off. Turn the volume up to hear them.")
    return
  end
  ns.Print("Playing each sound at " .. vol .. "% volume:")
  for i, kind in ipairs(UI.SOUND_ORDER) do
    C_Timer.After((i - 1) * 2, function()
      local played = UI:PlayKindSound(kind)
      local choice = UI:SoundLabel(UI:SoundFor(kind))
      ns.Print(UI.SOUND_KIND_LABELS[kind] .. ": " .. choice .. "  "
        .. (played and ("|cff888888" .. played .. "|r") or "|cffff4040no sound found|r"))
    end)
  end
end

local BACKDROP = {
  bgFile = "Interface\\Buttons\\WHITE8x8",
  edgeFile = "Interface\\Buttons\\WHITE8x8",
  edgeSize = 1,
}

local function qcolor(q)
  if C_Item and C_Item.GetItemQualityColor then
    local r, g, b = C_Item.GetItemQualityColor(q)
    if r then return { r, g, b } end
  end
  return { 1, 1, 1 }
end

local GOLD = { 1, 0.82, 0 }
local controls = {}

local function notify() return ns.db.settings.notify end
local function settings() return ns.db.settings end

local function changed()
  for _, c in ipairs(controls) do c:Update() end
  if S.frame then
    for _, body in ipairs({ S.frame.friends, S.frame.guild }) do
      if body and body:IsShown() then S:RefreshList(body) end
    end
  end
  if ns.UI then ns.UI:RequestRefresh() end
end

---------------------------------------------------------------------------
-- Widgets
---------------------------------------------------------------------------
local function Header(parent, text, y)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fs:SetPoint("TOPLEFT", 0, y)
  fs:SetText(text)
  local line = parent:CreateTexture(nil, "ARTWORK")
  line:SetColorTexture(0.4, 0.33, 0.18, 0.7)
  line:SetHeight(1)
  line:SetPoint("LEFT", fs, "RIGHT", 8, 0)
  line:SetPoint("RIGHT", parent, "RIGHT", 0, 0)
end

local function Label(parent, text, y)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  fs:SetPoint("TOPLEFT", 0, y - 3)
  fs:SetText(text)
  return fs
end

local function Note(parent, text, y)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  fs:SetPoint("TOPLEFT", 0, y)
  fs:SetWidth(W - 32)
  fs:SetJustifyH("LEFT")
  fs:SetText(text)
  return fs
end

local function paintChoice(b, selected, color)
  local r, g, bl = color[1], color[2], color[3]
  if selected then
    b:SetBackdropColor(r, g, bl, 0.35)
    b:SetBackdropBorderColor(r, g, bl, 1)
    b.text:SetTextColor(1, 1, 1)
  else
    b:SetBackdropColor(0.09, 0.09, 0.11, 0.95)
    b:SetBackdropBorderColor(0.28, 0.28, 0.3, 1)
    b.text:SetTextColor(r, g, bl)
  end
end

-- A row of buttons where exactly one is selected
local function Segmented(parent, x, y, options, get, set)
  local holder = CreateFrame("Frame", nil, parent)
  holder:SetPoint("TOPLEFT", x, y)
  holder.buttons = {}
  local ox = 0
  for i, o in ipairs(options) do
    local w = o.w or 58
    local b = CreateFrame("Button", nil, holder, "BackdropTemplate")
    b:SetSize(w, 20)
    b:SetPoint("TOPLEFT", ox, 0)
    b:SetBackdrop(BACKDROP)
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.text:SetPoint("CENTER")
    b.text:SetText(o.label)
    b.value, b.color = o.value, o.color or GOLD
    b:SetScript("OnClick", function() set(o.value); changed() end)
    holder.buttons[i] = b
    ox = ox + w + 3
  end
  holder:SetSize(ox, 20)
  function holder:Update()
    local cur = get()
    for _, b in ipairs(self.buttons) do paintChoice(b, b.value == cur, b.color) end
  end
  controls[#controls + 1] = holder
  return holder
end

local function CheckBox(parent)
  local box = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  box:SetSize(16, 16)
  box:SetBackdrop(BACKDROP)
  box:SetBackdropColor(0.08, 0.08, 0.1, 1)
  box:SetBackdropBorderColor(0.5, 0.42, 0.25, 1)
  box.check = box:CreateTexture(nil, "OVERLAY")
  box.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
  box.check:SetSize(22, 22)
  box.check:SetPoint("CENTER")
  return box
end

-- A checkbox with a label
local function Toggle(parent, x, y, label, get, set, w)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w or 200, 20)
  b:SetPoint("TOPLEFT", x, y)
  b.box = CheckBox(b)
  b.box:SetPoint("LEFT")
  b.check = b.box.check
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  b.text:SetPoint("LEFT", b.box, "RIGHT", 7, 0)
  b.text:SetText(label)
  local hl = b:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints(b.box)
  hl:SetColorTexture(1, 1, 1, 0.12)
  b:SetScript("OnClick", function() set(not get()); changed() end)
  function b:Update() self.check:SetShown(get() and true or false) end
  controls[#controls + 1] = b
  return b
end

-- Loot that isn't a milestone unless you ask for it (ns.LootExtra, 0.9.21):
-- a row of four small toggles, each explained when you hover it. Friends
-- only: it is never sent to the guild or to followers. nt(key) returns the
-- get and set for a notify key.
local EXTRAS_TIPS = {
  mats = "Crafting materials, gems, potions and food your friends loot or make.",
  recipes = "Green recipes and bags your friends find or make. Blue and better ones always show.",
  crafted = "Green gear and items your friends craft. Blue and better ones always show.",
  bought = "Things your friends get from the auction house, a vendor or a trade. Bought purple gear always shows.",
}
S.EXTRAS_TIPS = EXTRAS_TIPS
local function ExtrasRow(parent, y, nt)
  local row = { toggles = {} }
  for i, key in ipairs(ns.LOOT_EXTRAS) do
    local get, set = nt(key)
    local b = Toggle(parent, (i - 1) * 107, y, ns.LOOT_EXTRA_LABELS[key],
      function() return get() == true end, set, 100)
    b:SetScript("OnEnter", function(s)
      GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
      GameTooltip:SetText(ns.LOOT_EXTRA_LABELS[key])
      GameTooltip:AddLine(EXTRAS_TIPS[key], 1, 1, 1, true)
      GameTooltip:AddLine("Off unless you tick it. Friends only, and the Gear & items choice above still applies. The same item shows once a day.", 0.7, 0.7, 0.7, true)
      GameTooltip:Show()
    end)
    b:SetScript("OnLeave", GameTooltip_Hide)
    row.toggles[key] = b
  end
  return row
end

-- A horizontal slider with its value shown on the right
local function Slider(parent, x, y, w, minV, maxV, step, get, set, fmt, onRelease)
  local s = CreateFrame("Slider", nil, parent, "BackdropTemplate")
  s:SetOrientation("HORIZONTAL")
  s:SetSize(w, 12)
  s:SetPoint("TOPLEFT", x, y - 4)
  s:SetBackdrop(BACKDROP)
  s:SetBackdropColor(0.08, 0.08, 0.1, 1)
  s:SetBackdropBorderColor(0.5, 0.42, 0.25, 1)
  s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
  s:SetMinMaxValues(minV, maxV)
  s:SetValueStep(step)
  if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
  s.valueText = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  s.valueText:SetPoint("LEFT", s, "RIGHT", 10, 0)
  local function snap(v) return math.max(minV, math.min(maxV, math.floor(v / step + 0.5) * step)) end
  s:SetScript("OnValueChanged", function(self, v)
    if self.updating then return end
    v = snap(v)
    set(v)
    self.valueText:SetText(fmt(v))
  end)
  s:SetScript("OnMouseUp", function() if onRelease then onRelease(get()) end end)
  s:EnableMouseWheel(true)
  s:SetScript("OnMouseWheel", function(self, delta)
    local v = snap(get() + delta * step)
    set(v)
    self:Update()
    if onRelease then onRelease(v) end
  end)
  function s:Update()
    self.updating = true
    self:SetValue(get())
    self.updating = false
    self.valueText:SetText(fmt(get()))
  end
  controls[#controls + 1] = s
  return s
end

-- A drop-down: click for a menu of the options (the game's menu system, where
-- it exists), otherwise left click steps forward and right click back.
-- options: { { value, label }, ... }
function S.OpenMenu(owner, title, options, get, set)
  if not (MenuUtil and MenuUtil.CreateContextMenu) then return false end
  local ok = pcall(MenuUtil.CreateContextMenu, owner, function(_, root)
    if title and root.CreateTitle then root:CreateTitle(title) end
    for _, o in ipairs(options) do
      root:CreateRadio(o.label, function() return get() == o.value end, function() set(o.value); changed() end)
    end
  end)
  return ok
end

local function Picker(parent, x, y, w, title, options, get, set)
  local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
  b:SetSize(w, 20)
  b:SetPoint("TOPLEFT", x, y)
  b:SetBackdrop(BACKDROP)
  b:SetBackdropColor(0.09, 0.09, 0.11, 0.95)
  b:SetBackdropBorderColor(0.5, 0.42, 0.25, 1)
  b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  b.text:SetPoint("LEFT", 7, 0)
  b.text:SetPoint("RIGHT", -18, 0)
  b.text:SetJustifyH("LEFT")
  b.text:SetWordWrap(false)
  b.arrow = b:CreateTexture(nil, "OVERLAY")
  b.arrow:SetSize(16, 16)
  b.arrow:SetPoint("RIGHT", -2, 0)
  b.arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
  local hl = b:CreateTexture(nil, "HIGHLIGHT")
  hl:SetAllPoints()
  hl:SetColorTexture(1, 1, 1, 0.08)
  b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  b:SetScript("OnClick", function(self, button)
    if button ~= "RightButton" and S.OpenMenu(self, title, options, get, set) then return end
    local cur, idx = get(), 1
    for i, o in ipairs(options) do if o.value == cur then idx = i end end
    idx = (idx - 1 + (button == "RightButton" and -1 or 1)) % #options + 1
    set(options[idx].value)
    changed()
  end)
  b:SetScript("OnEnter", function(s)
    GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
    GameTooltip:SetText(title or "Choose")
    GameTooltip:AddLine("Click to choose. Right click steps back through the list.", 1, 1, 1, true)
    GameTooltip:Show()
  end)
  b:SetScript("OnLeave", GameTooltip_Hide)
  function b:Update()
    local cur = get()
    for _, o in ipairs(options) do
      if o.value == cur then self.text:SetText(o.label); return end
    end
    self.text:SetText(tostring(cur))
  end
  controls[#controls + 1] = b
  return b
end

---------------------------------------------------------------------------
-- General tab
---------------------------------------------------------------------------
local function BuildGeneral(body)
  local function nt(key) return function() return notify()[key] end, function(v) notify()[key] = v end end
  local function st(key) return function() return settings()[key] end, function(v) settings()[key] = v end end

  -- What I share (first, so new players decide this up front)
  -- gear is always shared from blue up (the user's call: no quality choice since v0.8.7, no greens since 0.9.8)
  Header(body, "What I share with friends", 0)
  Toggle(body, 0, -24, "My deaths", st("shareDeaths"))
  Toggle(body, 214, -24, "My world PvP kills", st("shareKills"))
  Toggle(body, 0, -48, "Also share with my guild", st("includeGuild"))
  Toggle(body, 214, -48, "My duels", st("shareDuels"))
  Note(body, "Gear you earn (green and up; greens go to friends only), levels, achievements, mounts, pets and toys are always shared. Crafting materials and things you buy only reach friends who ticked them. Never shared: battlegrounds and arenas.", -78)

  -- What I'm told about
  Header(body, "Notify me about", -122)
  Label(body, "Gear & items", -144)
  Segmented(body, 110, -144, {
    { value = 0, label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = 2, label = "Green+",  color = qcolor(2) },
    { value = 3, label = "Blue+",   color = qcolor(3) },
    { value = 4, label = "Purple+", color = qcolor(4) },
    { value = 5, label = "Orange",  color = qcolor(5) },
  }, function() return notify().loot end, function(v) notify().loot = v end)

  local maxLevel = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60
  Label(body, "Levels", -170)
  Segmented(body, 110, -170, {
    { value = "off", label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = "max", label = "Level " .. maxLevel, w = 72 },
    { value = "ten", label = "Every 10", w = 72 },
    { value = "all", label = "Every level", w = 82 },
  }, function() return notify().level end, function(v) notify().level = v end)

  Toggle(body, 0, -198, "Achievements", nt("ach"))
  Toggle(body, 214, -198, "Mounts", nt("mount"))
  Toggle(body, 0, -222, "Battle pets", nt("pet"))
  Toggle(body, 214, -222, "Toys", nt("toy"))
  Toggle(body, 0, -246, "Deaths", nt("death"))
  -- likes always show as a count on the heart; this is just the pop-up
  Toggle(body, 214, -246, "World PvP kills", nt("kill"))
  Toggle(body, 0, -270, "Likes on my milestones", st("likePopups"))
  Toggle(body, 214, -270, "Duels", nt("duel"))
  -- the loot 0.9.12 stopped showing, for anyone who wants it back
  body.extras = ExtrasRow(body, -296, nt)

  -- Pop-ups, feed and sound
  Header(body, "Pop-ups & feed", -332)
  -- what's on screen: the feed (the log) and pop-ups, or just one of them
  Label(body, "On screen", -354)
  Segmented(body, 110, -354, {
    { value = "both", label = "Feed & pop-ups", w = 96 },
    { value = "toasts", label = "Pop-ups only", w = 84 },
    { value = "feed", label = "Feed only", w = 70 },
  }, function()
    local s = settings()
    if s.feedShown and s.toasts then return "both" end
    if s.toasts then return "toasts" end
    if s.feedShown then return "feed" end
    return nil
  end, function(v)
    settings().toasts = v ~= "feed"
    if ns.UI then ns.UI:ShowFeed(v ~= "toasts") end
  end)
  Toggle(body, 0, -378, "Lock feed size & position", function() return settings().locked end, function(v)
    settings().locked = v
    if ns.UI then ns.UI:ApplyLock() end
  end)
  Toggle(body, 214, -378, "Dim the feed when it's quiet", function() return settings().feedDim end, function(v)
    settings().feedDim = v
    if ns.UI then ns.UI:Touch() end
  end)
  Toggle(body, 0, -402, "Filter bar on the feed", function() return settings().filterBar ~= false end, function(v)
    settings().filterBar = v
    if ns.UI then ns.UI:ApplyFilterBar() end
  end)
  Toggle(body, 214, -402, "Minimap button", function() return not settings().minimap.hide end, function(v)
    settings().minimap.hide = not v
    if ns.UI then ns.UI:ApplyMinimapButton() end
  end)

  -- the four looks, see STYLES in UI.lua
  Label(body, "Feed look", -430)
  local looks = {}
  for _, key in ipairs(ns.UI.STYLE_ORDER) do
    looks[#looks + 1] = { value = key, label = ns.UI.STYLE_LABELS[key], w = 66 }
  end
  Segmented(body, 110, -430, looks, function() return settings().feedStyle end, function(v)
    settings().feedStyle = v
    if ns.UI then ns.UI:ApplyStyle() end
  end)
  Note(body, "Cards: two lines, where it came from underneath. Compact: one line. Chat: no box, old rows fade. Timeline: grouped by day.", -454)

  -- how solid the feed's box is; applied as you drag
  Label(body, "Feed background", -484)
  Slider(body, 110, -484, 220, 0, 100, 5,
    function() return settings().feedAlpha or 70 end,
    function(v)
      settings().feedAlpha = v
      if ns.UI then ns.UI:ApplyBox() end
    end,
    function(v) return v == 0 and "|cff888888See-through|r" or (v .. "%") end)

  -- how long a pop-up stays up before it flies into the feed
  Label(body, "Pop-ups stay for", -512)
  body.toastSeconds = Slider(body, 110, -512, 220, ns.UI.TOAST_SECONDS_MIN, ns.UI.TOAST_SECONDS_MAX, 1,
    function() return ns.UI:ToastHold() end,
    function(v) settings().toastSeconds = v end,
    function(v) return v .. " seconds" end)

  -- (hidden on the welcome screen by S:Layout: nothing to clear yet, and no room)
  body.clearFeed = ActionButton(body, 0, -540, 120, "Clear feed", function() ns.UI:ClearFeed() end)
  body.deleteAll = ActionButton(body, 128, -540, 140, "Delete all history", function() StaticPopup_Show("FRIENDFEED_DELETE_ALL") end)
  body.movePopups = ActionButton(body, 276, -540, 124, "Move pop-ups", function() ns.UI:MoveToasts() end)
end

---------------------------------------------------------------------------
-- Sounds tab: the volume, and a sound for each kind of alert
---------------------------------------------------------------------------
local function BuildSounds(body)
  local UI = ns.UI
  Note(body, "Pick a sound for each kind of alert. Click a name to choose one, Play to hear it.", 0)

  Label(body, "Volume", -28)
  Slider(body, 110, -28, 220, 0, 300, 10,
    function() return settings().soundVolume or 100 end,
    function(v)
      settings().soundVolume = v
      if v > 0 then settings().lastSoundVolume = v end
    end,
    function(v) return v == 0 and "|cff888888Off|r" or (v .. "%") end,
    function(v) if v > 0 and ns.UI then ns.UI:PlayKindSound("loot", v) end end)

  local options = {}
  for _, o in ipairs(UI.SOUND_OPTIONS) do options[#options + 1] = { value = o.value, label = o.label } end
  body.pickers, body.plays = {}, {}
  local y = -62
  for _, kind in ipairs(UI.SOUND_ORDER) do
    Label(body, UI.SOUND_KIND_LABELS[kind], y)
    body.pickers[kind] = Picker(body, 150, y, 170, UI.SOUND_KIND_LABELS[kind], options,
      function() return UI:SoundFor(kind) end,
      function(v)
        settings().sounds[kind] = v
        UI:PlaySoundOption(v) -- hear it as you pick it
      end)
    body.plays[kind] = ActionButton(body, 328, y - 1, 50, "Play", function() UI:PlayKindSound(kind) end)
    y = y - 26
  end

  -- under the last row, wherever that lands
  ActionButton(body, 0, y - 8, 120, "Test all", TestSounds)
  body.reset = ActionButton(body, 128, y - 8, 140, "Back to defaults", function()
    wipe(settings().sounds)
    changed()
  end)
  Note(body, "The game picks the closest sound it knows for each name; Test all prints what actually played.", y - 38)
end

---------------------------------------------------------------------------
-- A list of people with an alerts checkbox and a Default/Custom button each,
-- used by the Friends and Guild tabs. listFn() gives { id, label, sub, chars }.
---------------------------------------------------------------------------
local function BuildPeopleList(body, top, tabKey, listFn, emptyText)
  body.tabKey, body.listFn, body.showRemoved = tabKey, listFn, false
  local listTop = -top + 30
  body.count = body:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  body.count:SetPoint("TOPRIGHT", 0, top - 4)
  ActionButton(body, 0, top, 90, "All on", function()
    for _, f in ipairs(listFn()) do settings().muted[f.id] = nil end
    changed()
  end)
  ActionButton(body, 96, top, 90, "All off", function()
    for _, f in ipairs(listFn()) do settings().muted[f.id] = true end
    changed()
  end)
  -- people you stopped tracking, with Add back (the same button goes back to the list)
  body.removedBtn = ActionButton(body, 192, top, 112, "Removed", function()
    body.showRemoved = not body.showRemoved
    body.offset = 0
    S:RefreshList(body)
  end)

  body.rows = {}
  body.offset = 0
  local rows = math.floor((BODY_H - listTop - 20) / FRIEND_ROW_H)
  for i = 1, rows do
    local r = CreateFrame("Button", nil, body)
    r:SetSize(W - 32, FRIEND_ROW_H)
    r:SetPoint("TOPLEFT", 0, -listTop - (i - 1) * FRIEND_ROW_H)
    r.box = CheckBox(r)
    r.box:SetPoint("LEFT", 2, 0)
    -- X: stop tracking this person (asks first)
    r.remove = CreateFrame("Button", nil, r)
    r.remove:SetSize(16, 16)
    r.remove:SetPoint("RIGHT", -2, 0)
    r.remove:SetNormalTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
    r.remove:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Highlight", "ADD")
    r.remove:SetPushedTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Down")
    r.remove:SetScript("OnClick", function()
      if not r.id then return end
      local plain = (r.label or r.id):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
      StaticPopup_Show("FRIENDFEED_REMOVE_FRIEND", plain, nil, { id = r.id, label = plain, guild = tabKey == "guild" })
    end)
    r.remove:SetScript("OnEnter", function(s)
      GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
      GameTooltip:SetText("Stop tracking this person")
      GameTooltip:AddLine("Deletes their saved milestones and ignores new ones. Add them back any time under Removed.", 1, 1, 1, true)
      GameTooltip:Show()
    end)
    r.remove:SetScript("OnLeave", GameTooltip_Hide)
    -- "Default" / "Custom": opens this person's own alert settings ("Add back" in the Removed list)
    r.alerts = CreateFrame("Button", nil, r, "BackdropTemplate")
    r.alerts:SetSize(64, 18)
    r.alerts:SetPoint("RIGHT", r.remove, "LEFT", -6, 0)
    r.alerts:SetBackdrop(BACKDROP)
    r.alerts.text = r.alerts:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.alerts.text:SetPoint("CENTER")
    r.alerts:SetScript("OnClick", function()
      if not r.id then return end
      if body.showRemoved then
        ns:RestoreFriend(r.id)
        ns.Print((r.label or r.id) .. " is back on your list. New milestones from them will show up again.")
        S:RefreshList(body)
      else
        S:EditFriend(r.id, r.label, tabKey)
      end
    end)
    r.alerts:SetScript("OnEnter", function(s)
      GameTooltip:SetOwner(s, "ANCHOR_RIGHT")
      GameTooltip:SetText(body.showRemoved and "Track this person again" or "Choose what you hear about from this person")
      GameTooltip:Show()
    end)
    r.alerts:SetScript("OnLeave", GameTooltip_Hide)
    r.sub = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    r.sub:SetPoint("RIGHT", r.alerts, "LEFT", -8, 0)
    r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.text:SetPoint("LEFT", r.box, "RIGHT", 8, 0)
    r.text:SetPoint("RIGHT", r.sub, "LEFT", -8, 0)
    r.text:SetJustifyH("LEFT")
    r.text:SetWordWrap(false)
    local hl = r:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.06)
    r:SetScript("OnClick", function(self)
      if self.id and not body.showRemoved then ns:SetMuted(self.id, not ns:IsMuted(self.id)); changed() end
    end)
    -- hover: every character this friend has been seen on
    r:SetScript("OnEnter", function(self)
      if not self.id or body.showRemoved then return end
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      GameTooltip:SetText(self.label or self.id, 1, 1, 1)
      if self.id:find("#", 1, true) and not self.id:find(":", 1, true) then
        GameTooltip:AddLine(self.id, 0.6, 0.6, 0.6)
      end
      local chars = self.chars or {}
      if #chars > 0 then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Characters", 1, 0.82, 0)
        for i, c in ipairs(chars) do
          if i > 10 then GameTooltip:AddLine("and " .. (#chars - 10) .. " more", 0.6, 0.6, 0.6); break end
          GameTooltip:AddDoubleLine(ns.Label({ who = c.who, rs = c.rs }), c.seen and c.seen > 0 and (ns.Ago(c.seen) .. " ago") or "",
            1, 1, 1, 0.6, 0.6, 0.6)
        end
      else
        GameTooltip:AddLine("No characters seen yet. They show up once this friend is online in Forever while you are, or once their activity reaches you.", 0.7, 0.7, 0.7, true)
      end
      GameTooltip:AddLine(" ")
      GameTooltip:AddLine("Click to turn alerts on or off", 0.5, 0.8, 1)
      GameTooltip:Show()
    end)
    r:SetScript("OnLeave", GameTooltip_Hide)
    r:EnableMouseWheel(true)
    r:SetScript("OnMouseWheel", function(_, delta) body.offset = body.offset - delta * 3; S:RefreshList(body) end)
    body.rows[i] = r
  end
  body:EnableMouseWheel(true)
  body:SetScript("OnMouseWheel", function(_, delta) body.offset = body.offset - delta * 3; S:RefreshList(body) end)

  body.empty = body:CreateFontString(nil, "OVERLAY", "GameFontDisable")
  body.empty:SetPoint("TOPLEFT", 0, -listTop - 8)
  body.empty:SetWidth(W - 32)
  body.empty:SetJustifyH("LEFT")
  body.empty:SetText(emptyText)
  body.emptyText = emptyText

  body.more = body:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  body.more:SetPoint("BOTTOMLEFT", 0, 0)
end

---------------------------------------------------------------------------
-- Friends tab
---------------------------------------------------------------------------
local function BuildFriends(body)
  Note(body, "Untick someone to stop their pop-ups, sounds and feed rows (their history is kept). The X stops tracking them; Removed lets you add them back.", 0)
  BuildPeopleList(body, -36, "friends", function() return ns:KnownFriends() end,
    "No friends yet. Your Battle.net and character friends show up here, and so does anyone whose activity you've seen.")
end

---------------------------------------------------------------------------
-- Guild tab: guildmates who aren't friends get their own alert settings
-- (purple+ gear and level 60 to start), and their own list.
---------------------------------------------------------------------------
local function BuildGuild(body)
  local function st(key) return function() return settings()[key] end, function(v) settings()[key] = v end end
  local function gn(key) return function() return settings().guildNotify[key] end, function(v) settings().guildNotify[key] = v end end

  Note(body, "Your milestones also go to guildmates who have Friend Feed, and theirs come to you, live. Both of you need this on. Guildmates who are also your friends keep your Friends settings.", 0)
  Toggle(body, 0, -40, "Share with my guild", st("includeGuild"))

  Header(body, "Notify me about, from guildmates", -68)
  Label(body, "Gear & items", -90)
  Segmented(body, 110, -90, {
    { value = 0, label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = 3, label = "Blue+",   color = qcolor(3) },
    { value = 4, label = "Purple+", color = qcolor(4) },
    { value = 5, label = "Orange",  color = qcolor(5) },
  }, gn("loot"))
  local maxLevel = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60
  Label(body, "Levels", -116)
  Segmented(body, 110, -116, {
    { value = "off", label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = "max", label = "Level " .. maxLevel, w = 72 },
    { value = "ten", label = "Every 10", w = 72 },
    { value = "all", label = "Every level", w = 82 },
  }, gn("level"))
  Toggle(body, 0, -144, "Achievements", gn("ach"))
  Toggle(body, 214, -144, "Mounts", gn("mount"))
  Toggle(body, 0, -168, "Battle pets", gn("pet"))
  Toggle(body, 214, -168, "Toys", gn("toy"))
  Toggle(body, 0, -192, "Deaths", gn("death"))
  Toggle(body, 214, -192, "World PvP kills", gn("kill"))
  Toggle(body, 0, -216, "Duels", gn("duel"))
  Toggle(body, 214, -216, "Accolades", gn("acc"))

  Header(body, "Guildmates", -248)
  BuildPeopleList(body, -272, "guild", function() return ns:KnownGuildmates() end,
    "No guildmates yet. They show up here once their activity reaches you, which needs Share with my guild on for both of you.")
end

---------------------------------------------------------------------------
-- Following tab (0.9.8): what your followers get from you live, what you
-- get told about from the people you follow (everything to start), and the
-- list of them. Following itself is done in the Friend Feed app, or on the
-- website with a code pasted in /ff code (Code.lua, the Website code button).
---------------------------------------------------------------------------
local function BuildFollowing(body)
  local function st(key) return function() return settings()[key] end, function(v) settings()[key] = v end end
  local function fs(key) return function() return settings().followShare[key] ~= false end, function(v) settings().followShare[key] = v end end
  local function fn(key) return function() return settings().followNotify[key] end, function(v) settings().followNotify[key] = v end end

  Note(body, "People you follow in the Friend Feed app or on the website reach you live when you're both online on the same ruleset and faction, friends or not, and you reach yours the same way.", 0)
  Toggle(body, 0, -40, "Let my followers see my milestones live", st("followLive"))
  -- no app: follow on the website and paste its code here
  body.codeBtn = ActionButton(body, W - 32 - 120, -40, 120, "Website code", function() ns.Code:Open() end)

  Header(body, "Send to my followers", -68)
  Toggle(body, 0, -90, "Gear & items (blue and up)", fs("loot"))
  Toggle(body, 214, -90, "Levels", fs("level"))
  Toggle(body, 0, -114, "Achievements", fs("ach"))
  Toggle(body, 214, -114, "Mounts", fs("mount"))
  Toggle(body, 0, -138, "Battle pets", fs("pet"))
  Toggle(body, 214, -138, "Toys", fs("toy"))
  Toggle(body, 0, -162, "Deaths", fs("death"))
  Toggle(body, 214, -162, "World PvP kills", fs("kill"))
  Toggle(body, 0, -186, "Duels", fs("duel"))
  Toggle(body, 214, -186, "Accolades", fs("acc"))

  Header(body, "Notify me about, from people I follow", -218)
  Label(body, "Gear & items", -240)
  Segmented(body, 110, -240, {
    { value = 0, label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = 3, label = "Blue+",   color = qcolor(3) },
    { value = 4, label = "Purple+", color = qcolor(4) },
    { value = 5, label = "Orange",  color = qcolor(5) },
  }, fn("loot"))
  local maxLevel = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60
  Label(body, "Levels", -266)
  Segmented(body, 110, -266, {
    { value = "off", label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = "max", label = "Level " .. maxLevel, w = 72 },
    { value = "ten", label = "Every 10", w = 72 },
    { value = "all", label = "Every level", w = 82 },
  }, fn("level"))
  Toggle(body, 0, -294, "Achievements", fn("ach"))
  Toggle(body, 214, -294, "Mounts", fn("mount"))
  Toggle(body, 0, -318, "Battle pets", fn("pet"))
  Toggle(body, 214, -318, "Toys", fn("toy"))
  Toggle(body, 0, -342, "Deaths", fn("death"))
  Toggle(body, 214, -342, "World PvP kills", fn("kill"))
  Toggle(body, 0, -366, "Duels", fn("duel"))
  -- pop-ups for likes from followers who aren't friends (General's "Likes on my milestones" turns all of them off)
  Toggle(body, 214, -366, "Likes from my followers", st("followLikePopups"))

  Header(body, "People you follow", -398)
  BuildPeopleList(body, -422, "following", function() return ns:KnownFollowed() end,
    "Nobody yet. Follow people in the Friend Feed app, or on the website with the Website code button above.")
end

---------------------------------------------------------------------------
-- Help tab (0.9.8): what players need to know, from docs/HELP.md (keep the
-- two in step). Topics down the left, the chosen one on the right. Game
-- text never mentions money, so "in the Friend Feed app" stands in for it.
---------------------------------------------------------------------------
local Y = "|cffffd200" -- commands and buttons in gold
local HELP_TOPICS = {
  { "Getting started", table.concat({
    "You only see milestones from friends and guildmates who have Friend Feed installed. Send it to the people you play with.",
    "",
    "Type " .. Y .. "/ff ping|r to see which of your online friends already have it.",
    "",
    "Type " .. Y .. "/ff demo|r for a three-minute preview with made-up friends.",
  }, "\n") },
  { "Feed & history", table.concat({
    Y .. "The feed|r shows what's happening now. Drag it by its header, resize it from the bottom-right corner, and use the filter bar to hide kinds of milestones, guildmates or people you follow.",
    "",
    Y .. "The book icon|r opens the history window: everything that reached you, with Friends, Guild and Following tabs.",
    "",
    Y .. "The gear icon|r opens these settings.",
  }, "\n") },
  { "Following someone", table.concat({
    Y .. "1.|r In the Friend Feed app, open Social, find them and click Follow.",
    "",
    Y .. "2.|r In game, type " .. Y .. "/reload|r (or log out and back in). The game only reads what the app sends it at login or /reload.",
    "",
    Y .. "3.|r When you're both online on the same ruleset and faction, their milestones pop up live. Friend Feed says hello to them by itself and keeps trying every few minutes while they're offline, so if they log in after you, you're connected within 5 minutes.",
    "",
    Y .. "4.|r On another ruleset, or while one of you is offline, their milestones still reach you through the app, in your history window.",
    "",
    Y .. "/ff following|r shows who you follow here and who has answered.",
    "",
    "No app? See " .. Y .. "No app? Use a code|r.",
  }, "\n") },
  { "Being followed", table.concat({
    "Join the public list in the Friend Feed app (Social page). Your followers then get your milestones live while you're both online on the same ruleset and faction.",
    "",
    "The " .. Y .. "Following|r tab here decides which kinds of milestones your followers get, or turns it off.",
    "",
    "Greens are only ever shared with friends, never with your guild or your followers.",
    "",
    "Your followers can like your milestones, and they all see the same count. The first ten likes on a milestone pop up as they come, then one pop-up every 15 seconds at most, and hearts float up from the heart on its row in between. "
      .. Y .. "Likes from my followers|r in the Following tab turns those pop-ups off; " .. Y .. "Likes on my milestones|r in General turns off every like pop-up. The count shows either way.",
  }, "\n") },
  { "No app? Use a code", table.concat({
    "Rather not install the Friend Feed app? You can follow people and join the public list on the website instead: " .. Y .. ns.SITE .. "/code|r",
    "",
    Y .. "1.|r Add your characters there (" .. Y .. "/ff code|r shows this one's name and ruleset), follow people, and join the public list if you like.",
    "",
    Y .. "2.|r Click Copy my code, then type " .. Y .. "/ff code|r here, paste it with Ctrl+V and click Save. It works straight away.",
    "",
    Y .. "Paste a new code|r whenever you follow someone new, play a new character, or someone you follow starts a new one.",
    "",
    Y .. "Everyone needs it:|r the people you follow need their own code in their game too, or the app.",
    "",
    "Live only: what happened while you were offline needs the app.",
  }, "\n") },
  { "Why /reload?", table.concat({
    "The game only swaps files with the Friend Feed app at certain moments:",
    "",
    Y .. "App to game:|r friends' history and who you follow are read when you log in or type /reload.",
    "",
    Y .. "Game to app:|r your own milestones are saved for the app when you log out or type /reload.",
    "",
    "Live pop-ups between players who are online together don't wait for either.",
  }, "\n") },
  { "Offline history", table.concat({
    "Keep the Friend Feed app running: it sits in your tray, starts with your computer and syncs every few minutes.",
    "",
    "When you log in, friends' milestones from while you were away are in your history window, with one \"While you were away\" summary instead of a pile of pop-ups.",
  }, "\n") },
  { "Commands", table.concat({
    Y .. "/ff|r  show or hide the feed",
    Y .. "/ff settings|r  these settings",
    Y .. "/ff help|r  this help",
    Y .. "/ff details|r  the history window",
    Y .. "/ff ping|r  who among your online friends has Friend Feed",
    Y .. "/ff following|r  live following status",
    Y .. "/ff code|r  paste a code from the website",
    Y .. "/ff demo|r  a preview with made-up friends",
    Y .. "/ff popups|r  move where pop-ups appear",
    Y .. "/ff minimap|r  show or hide the minimap button",
    "",
    "Type " .. Y .. "/ff xyz|r (anything unknown) for the full list in chat.",
  }, "\n") },
}
S.HELP_TOPICS = HELP_TOPICS

-- Accolades tab (0.9.17): this character's accolades with progress, and
-- what you hear about other people's
local function BuildAccolades(body)
  local UI = ns.UI
  Header(body, "This character's accolades", 0)
  body.list = UI:MakeAccoladeList(body, W - 32)
  body.list:SetPoint("TOPLEFT", 0, -26)
  local y = -26 - #ns.ACCOLADES * UI.ACC_ROW - 4
  body.note = body:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  body.note:SetPoint("TOPLEFT", 0, y)
  body.note:SetWidth(W - 32)
  body.note:SetJustifyH("LEFT")
  body.note:SetText("Earned on each character. What you already had when you installed counts, without an announcement. Your best one shows next to your name in your friends' feeds, and they can click an accolade to see them all.")
  body.streaks = body:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  body.streaks:SetPoint("TOPLEFT", 0, y - 44)
  body.streaks:SetWidth(W - 32)
  body.streaks:SetJustifyH("LEFT")
  Header(body, "Notify me about", y - 76)
  Toggle(body, 0, y - 98, "Friends' accolades",
    function() return notify().acc ~= false end, function(v) notify().acc = v end)
  Toggle(body, 214, y - 98, "From people I follow",
    function() return settings().followNotify.acc ~= false end, function(v) settings().followNotify.acc = v end)
  Toggle(body, 0, y - 122, "Badges next to names",
    function() return settings().badges ~= false end,
    function(v) settings().badges = v; if UI.RequestRefresh then UI:RequestRefresh() end end)
  function body:Refresh()
    self.list:Paint(ns:MyAccolades(), true)
    local streaks = ns.StreakSummary and ns.StreakSummary(ns.MyStreaks())
    self.streaks:SetText("Kill streaks (each kill within a minute of the last): " .. (streaks or "none yet"))
  end
end

local function BuildHelp(body)
  local LIST_W = 128
  body.topics = {}
  body.text = body:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  body.text:SetPoint("TOPLEFT", LIST_W + 14, -4)
  body.text:SetWidth(W - 32 - LIST_W - 14)
  body.text:SetJustifyH("LEFT")
  body.text:SetJustifyV("TOP")
  body.text:SetSpacing(2)
  local div = body:CreateTexture(nil, "ARTWORK")
  div:SetColorTexture(0.4, 0.33, 0.18, 0.7)
  div:SetWidth(1)
  div:SetPoint("TOPLEFT", LIST_W + 6, 0)
  div:SetPoint("BOTTOMLEFT", LIST_W + 6, 20)
  function body:ShowTopic(i)
    body.current = i
    body.text:SetText(HELP_TOPICS[i][2])
    for j, b in ipairs(body.topics) do paintChoice(b, j == i, GOLD) end
  end
  for i, t in ipairs(HELP_TOPICS) do
    local b = CreateFrame("Button", nil, body, "BackdropTemplate")
    b:SetSize(LIST_W, 24)
    b:SetPoint("TOPLEFT", 0, -(i - 1) * 28)
    b:SetBackdrop(BACKDROP)
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.text:SetPoint("LEFT", 8, 0)
    b.text:SetText(t[1])
    b:SetScript("OnClick", function() body:ShowTopic(i) end)
    body.topics[i] = b
  end
  body:ShowTopic(1)
end

---------------------------------------------------------------------------
-- One friend's own alert settings (opened from the Friends tab)
---------------------------------------------------------------------------
local function BuildFriendEdit(body)
  local function editing() return S.editId end
  body.back = ActionButton(body, 0, 0, 70, "< Back", function() S:ShowTab(S.editBack or "friends") end)
  body.title = body:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  body.title:SetPoint("TOPLEFT", 82, -4)
  body.title:SetPoint("RIGHT", 0, 0)
  body.title:SetJustifyH("LEFT")
  body.title:SetWordWrap(false)

  Toggle(body, 0, -34, "Alerts from this person",
    function() return not ns:IsMuted(editing()) end,
    function(v) ns:SetMuted(editing(), not v) end)
  body.normalToggle = Toggle(body, 214, -34, "Use my normal settings",
    function() return not ns:HasCustomAlerts(editing()) end,
    function(v) ns:SetCustomAlerts(editing(), not v) end)
  Note(body, "Changing anything below gives this person their own settings. Tick \"Use my normal settings\" (or \"Use my guild settings\" for a guildmate) to go back to the shared ones.", -58)

  -- the same choices as "Notify me about", but for this person only
  local grp = CreateFrame("Frame", nil, body)
  grp:SetPoint("TOPLEFT", 0, -92)
  grp:SetSize(W - 32, 188)
  local function get(key) return function() return ns:NotifyFor(editing())[key] end end
  local function set(key) return function(v) ns:SetCustomAlerts(editing(), true)[key] = v end end
  local function nt(key) return get(key), set(key) end

  Label(grp, "Gear & items", 0)
  Segmented(grp, 110, 0, {
    { value = 0, label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = 2, label = "Green+",  color = qcolor(2) }, -- greens only ever come from friends
    { value = 3, label = "Blue+",   color = qcolor(3) },
    { value = 4, label = "Purple+", color = qcolor(4) },
    { value = 5, label = "Orange",  color = qcolor(5) },
  }, get("loot"), set("loot"))
  local maxLevel = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60
  Label(grp, "Levels", -26)
  Segmented(grp, 110, -26, {
    { value = "off", label = "Off", color = { 0.6, 0.6, 0.6 } },
    { value = "max", label = "Level " .. maxLevel, w = 72 },
    { value = "ten", label = "Every 10", w = 72 },
    { value = "all", label = "Every level", w = 82 },
  }, get("level"), set("level"))
  Toggle(grp, 0, -54, "Achievements", nt("ach"))
  Toggle(grp, 214, -54, "Mounts", nt("mount"))
  Toggle(grp, 0, -78, "Battle pets", nt("pet"))
  Toggle(grp, 214, -78, "Toys", nt("toy"))
  Toggle(grp, 0, -102, "Deaths", nt("death"))
  Toggle(grp, 214, -102, "World PvP kills", nt("kill"))
  Toggle(grp, 0, -126, "Duels", nt("duel"))
  Toggle(grp, 214, -126, "Accolades", nt("acc"))
  body.extras = ExtrasRow(grp, -150, nt)

  -- dim the choices while this person follows your normal settings
  local dim = { Update = function() grp:SetAlpha(ns:HasCustomAlerts(editing()) and 1 or 0.55) end }
  controls[#controls + 1] = dim
end

function S:EditFriend(id, label, fromTab)
  local f = self.frame
  self.editId = id
  self.editBack = fromTab or "friends"
  f.friendEdit.title:SetText("Alerts for " .. (label or id))
  -- same order as ns:NotifyFor: a friend first, then following, then the guild
  f.friendEdit.normalToggle.text:SetText(ns:IsFriendID(id) and "Use my normal settings"
    or ns:IsFollowedID(id) and "Use my following settings"
    or ns:IsGuildmate(id) and "Use my guild settings" or "Use my normal settings")
  f.general:Hide()
  f.sounds:Hide()
  f.guild:Hide()
  f.friends:Hide()
  f.following:Hide()
  f.help:Hide()
  f.friendEdit:Show()
  changed()
end

function S:RefreshFriends()
  if self.frame then self:RefreshList(self.frame.friends) end
end

-- Fill a people list (Friends or Guild tab) from its listFn
-- Both people lists, if the window is open (after someone is removed)
function S:RefreshOpenLists()
  local f = self.frame
  if not f then return end
  for _, body in ipairs({ f.friends, f.guild, f.following }) do
    if body and body:IsShown() then self:RefreshList(body) end
  end
end

-- The Removed view: people you stopped tracking, each with Add back
local function RefreshRemoved(body)
  local list = ns:RemovedPeople(body.tabKey == "guild")
  local n = #body.rows
  body.offset = math.max(0, math.min(body.offset, #list - n))
  body.count:SetText(#list > 0 and (#list .. " removed") or "")
  body.removedBtn:SetText("< Back to list")
  for i, r in ipairs(body.rows) do
    local f = list[i + body.offset]
    if f then
      r.id, r.label, r.chars = f.id, f.label, nil
      r.text:SetText(f.label)
      r.text:SetAlpha(0.7)
      r.sub:SetText(f.t > 0 and ("removed " .. ns.Ago(f.t) .. " ago") or "")
      r.box:Hide()
      r.remove:Hide()
      r.alerts.text:SetText("Add back")
      paintChoice(r.alerts, true, GOLD)
      r:Show()
    else
      r.id = nil
      r:Hide()
    end
  end
  body.empty:SetText("Nobody removed. The X on someone's row stops tracking them; they show up here so you can add them back.")
  body.empty:SetShown(#list == 0)
  body.more:SetText(#list > n and format("%d-%d of %d   |cff888888(scroll for more)|r", body.offset + 1, math.min(body.offset + n, #list), #list) or "")
end

function S:RefreshList(body)
  if not (body and body.listFn) then return end
  if body.showRemoved then return RefreshRemoved(body) end
  local nRemoved = #ns:RemovedPeople(body.tabKey == "guild")
  body.removedBtn:SetText(nRemoved > 0 and ("Removed (" .. nRemoved .. ")") or "Removed")
  body.empty:SetText(body.emptyText)
  local list = body.listFn()
  local n = #body.rows
  body.offset = math.max(0, math.min(body.offset, #list - n))
  local on = 0
  for _, f in ipairs(list) do if not ns:IsMuted(f.id) then on = on + 1 end end
  body.count:SetText(#list > 0 and (on .. " of " .. #list .. " on") or "")
  for i, r in ipairs(body.rows) do
    local f = list[i + body.offset]
    if f then
      r.box:Show()
      r.remove:Show()
      r.id, r.label, r.chars = f.id, f.label, f.chars
      local more = (f.chars and #f.chars > 1) and (" |cff888888+" .. (#f.chars - 1) .. "|r") or ""
      r.text:SetText(f.label .. more)
      r.sub:SetText(f.sub or "")
      local muted = ns:IsMuted(f.id)
      r.box.check:SetShown(not muted)
      r.text:SetAlpha(muted and 0.5 or 1)
      local custom = ns:HasCustomAlerts(f.id)
      r.alerts.text:SetText(custom and "Custom" or "Default")
      paintChoice(r.alerts, custom, custom and GOLD or { 0.7, 0.7, 0.7 })
      r:Show()
    else
      r.id = nil
      r:Hide()
    end
  end
  body.empty:SetShown(#list == 0)
  if #list > n then
    body.more:SetText(format("%d-%d of %d   |cff888888(scroll for more)|r", body.offset + 1, math.min(body.offset + n, #list), #list))
  else
    body.more:SetText("")
  end
end

---------------------------------------------------------------------------
-- "Stay updated while you're offline": what the Friend Feed app adds and
-- where to get it. Always open, as a panel down the right of the welcome
-- screen and the settings window (across the top it made both windows
-- taller than a 768-unit screen). A short intro, the benefits as bullets,
-- the address, and last the sign-in reassurance in its own tinted section.
-- Plain facts only. Nothing about prices or paying, ever.
---------------------------------------------------------------------------
local SITE = ns.SITE
local SIDE_W = 300
local OFFLINE_INTRO = "The Friend Feed app for Windows and Mac picks up where the game leaves off."
local OFFLINE_BENEFITS = ns.APP_BENEFITS -- shared with the feed logo's panel (Core.lua)
local SAFE_HEAD = "Your login stays with Battle.net"
local SAFE_TEXT = "You sign in on Battle.net's own page, so Friend Feed never sees or stores your password. "
  .. "We only keep your BattleTag, your characters' names, your in-game milestones and your friend list."

-- A font string's height once laid out, or a guess where the client can't say yet
local function textH(fs, guess)
  local ok, h = pcall(fs.GetStringHeight, fs)
  h = ok and tonumber(h) or nil
  if not h or h <= 0 then return guess end
  return h
end

local function BuildOffline(parent)
  local inner = SIDE_W - 24
  local b = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  b:SetWidth(SIDE_W)
  b:SetBackdrop(BACKDROP)
  b:SetBackdropColor(1, 0.82, 0, 0.05)
  b:SetBackdropBorderColor(0.5, 0.42, 0.25, 0.8)

  local function text(font, w)
    local fs = b:CreateFontString(nil, "OVERLAY", font)
    fs:SetWidth(w)
    fs:SetJustifyH("LEFT")
    return fs
  end

  -- the panel's header, then what it's about underneath
  b.header = text("GameFontNormalLarge", inner)
  b.header:SetPoint("TOPLEFT", 12, -12)
  b.header:SetText("Never Miss The World's Big Moments")
  b.headerLine = b:CreateTexture(nil, "ARTWORK")
  b.headerLine:SetHeight(1)
  b.headerLine:SetPoint("TOPLEFT", b.header, "BOTTOMLEFT", 0, -6)
  b.headerLine:SetPoint("RIGHT", b, "RIGHT", -12, 0)
  b.headerLine:SetColorTexture(1, 0.82, 0, 0.35)

  b.title = text("GameFontNormal", inner)
  b.title:SetPoint("TOPLEFT", b.header, "BOTTOMLEFT", 0, -14)
  b.title:SetText("Stay updated with your friends while you're offline")

  b.intro = text("GameFontHighlightSmall", inner)
  b.intro:SetPoint("TOPLEFT", b.title, "BOTTOMLEFT", 0, -6)
  b.intro:SetText(OFFLINE_INTRO)

  -- the benefits, each with a gold bullet
  b.bullets = {}
  local prev = b.intro
  for i, line in ipairs(OFFLINE_BENEFITS) do
    local t = text("GameFontHighlightSmall", inner - 14)
    if i == 1 then t:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 14, -10) else t:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -6) end
    t:SetText(line)
    local dot = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dot:SetPoint("TOPRIGHT", t, "TOPLEFT", -5, 0)
    dot:SetText("|cffffd200\226\128\162|r") -- a bullet, in gold
    b.bullets[i] = { text = t, dot = dot }
    prev = t
  end

  -- where to get it: the address in a box so it can be copied (the game can't open links)
  b.label = text("GameFontNormalSmall", inner)
  b.label:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", -14, -14)
  b.label:SetText("Get the app at")
  local box = CreateFrame("EditBox", nil, b, "InputBoxTemplate")
  box:SetSize(160, 20)
  box:SetPoint("TOPLEFT", b.label, "BOTTOMLEFT", 6, -4)
  box:SetAutoFocus(false)
  box:SetText(SITE)
  box:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
  box:SetScript("OnTextChanged", function(self, byUser)
    if byUser and self:GetText() ~= SITE then self:SetText(SITE); self:HighlightText() end
  end)
  box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  b.box = box
  b.hint = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  b.hint:SetPoint("LEFT", box, "RIGHT", 8, 0)
  b.hint:SetText("click it, then Ctrl+C")

  -- last: the sign-in reassurance, pinned to the bottom in a tinted section
  b.note = text("GameFontHighlightSmall", inner)
  b.note:SetPoint("BOTTOMLEFT", 12, 12)
  b.note:SetText(SAFE_TEXT)
  b.safeHead = text("GameFontNormal", inner)
  b.safeHead:SetPoint("BOTTOMLEFT", b.note, "TOPLEFT", 0, 5)
  b.safeHead:SetText("|cff8fd0ff" .. SAFE_HEAD .. "|r")
  b.divider = b:CreateTexture(nil, "ARTWORK")
  b.divider:SetHeight(1)
  b.divider:SetPoint("BOTTOMLEFT", b.safeHead, "TOPLEFT", -11, 10)
  b.divider:SetPoint("RIGHT", b, "RIGHT", -1, 0)
  b.divider:SetColorTexture(0.56, 0.82, 1, 0.35)
  b.safeBg = b:CreateTexture(nil, "BACKGROUND", nil, 1)
  b.safeBg:SetPoint("TOP", b.divider, "BOTTOM", 0, 0)
  b.safeBg:SetPoint("BOTTOMLEFT", 1, 1)
  b.safeBg:SetPoint("BOTTOMRIGHT", -1, 1)
  b.safeBg:SetColorTexture(0.56, 0.82, 1, 0.07)

  -- how tall the panel's content is (the window is made at least this tall)
  function b:ContentHeight()
    local h = 12 + textH(self.header, 18) + 14 + textH(self.title, 30) + 6 + textH(self.intro, 26) + 10
    for _, bl in ipairs(self.bullets) do h = h + textH(bl.text, 24) + 6 end
    h = h + 8 + textH(self.label, 12) + 4 + 20 -- the address
    h = h + 24 + 10 + textH(self.safeHead, 14) + 5 + textH(self.note, 52) + 12 -- the reassurance
    return h
  end
  return b
end

---------------------------------------------------------------------------
-- "Your friends need Friend Feed too": the network notice right under the
-- window's title. Friend Feed only works between players who both have it,
-- so this says so plainly and nudges people to pass it on.
---------------------------------------------------------------------------
local NETWORK_HEAD = "Your friends need Friend Feed too"
local NETWORK_TEXT = "You only see milestones from friends and guildmates who have the addon installed. "
  .. "Send it to the people you play with, and type |cffffd200/ff ping|r to see who already has it."

local function BuildNetworkNotice(parent)
  local n = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  n:SetWidth(W - 32)
  n:SetBackdrop(BACKDROP)
  n:SetBackdropColor(1, 0.5, 0, 0.1)
  n:SetBackdropBorderColor(1, 0.55, 0.1, 0.85)
  n.icon = n:CreateTexture(nil, "ARTWORK")
  n.icon:SetSize(30, 30)
  n.icon:SetPoint("TOPLEFT", 10, -10)
  n.icon:SetTexture("Interface\\Icons\\Achievement_GuildPerk_EverybodysFriend")
  n.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  n.head = n:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  n.head:SetPoint("TOPLEFT", n.icon, "TOPRIGHT", 10, 0)
  n.head:SetPoint("RIGHT", -10, 0)
  n.head:SetJustifyH("LEFT")
  n.head:SetText("|cffff9933" .. NETWORK_HEAD .. "|r")
  n.text = n:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  n.text:SetPoint("TOPLEFT", n.head, "BOTTOMLEFT", 0, -4)
  n.text:SetWidth(W - 32 - 60)
  n.text:SetJustifyH("LEFT")
  n.text:SetText(NETWORK_TEXT)
  -- tall enough for its text (two lines in English; more if it wraps further)
  function n:Fit()
    local h = 10 + textH(self.head, 14) + 4 + textH(self.text, 24) + 10
    self:SetHeight(math.max(50, h))
    return self:GetHeight()
  end
  n:Fit()
  return n
end

-- Place the intro, network notice, tabs, bodies and the offline panel for the current mode.
function S:Layout()
  local f = self.frame
  local setup = f.setupMode
  local y = 40 -- below the title
  f.intro:SetShown(setup)
  if setup then y = 98 end -- the intro's three lines
  -- friends need it too: right under the title (after the intro on the welcome screen)
  f.network:ClearAllPoints()
  f.network:SetPoint("TOPLEFT", 16, -y)
  f.network:Show()
  y = y + f.network:Fit() + 10
  local tx = 16
  for _, b in ipairs(f.tabs) do
    b:SetShown(not setup) -- the welcome screen is just the basics
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", tx, -y)
    tx = tx + TAB_W + 4
  end
  if not setup then y = y + 34 end
  for _, body in ipairs({ f.general, f.sounds, f.guild, f.friends, f.following, f.accolades, f.help, f.friendEdit }) do
    body:ClearAllPoints()
    body:SetPoint("TOPLEFT", 16, -y)
  end
  f.footer:SetShown(setup)
  for _, key in ipairs({ "clearFeed", "deleteAll", "movePopups" }) do
    if f.general[key] then f.general[key]:SetShown(not setup) end
  end
  -- the offline panel runs down the right, as tall as the window
  local panelTop = 40
  -- the welcome screen is General only, which fits in less than the tallest tab
  local bodyH = setup and SETUP_BODY_H or BODY_H
  local height = math.max(y + bodyH + (setup and 50 or 16), panelTop + f.offline:ContentHeight() + 16)
  f:SetHeight(height)
  f.offline:ClearAllPoints()
  f.offline:SetPoint("TOPLEFT", W, -panelTop)
  f.offline:SetHeight(height - panelTop - 16)
  f.offline:Show()
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
function S:Create()
  local f = CreateFrame("Frame", "FriendFeedSettings", UIParent, "BackdropTemplate")
  f:SetWidth(W + SIDE_W + 16) -- settings on the left, the offline panel on the right
  f:SetPoint("CENTER", 0, 40)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:Hide()
  f:SetBackdrop(BACKDROP)
  f:SetBackdropColor(0.04, 0.04, 0.06, 0.97)
  f:SetBackdropBorderColor(0.4, 0.33, 0.18, 0.9)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:SetClampedToScreen(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  tinsert(UISpecialFrames, "FriendFeedSettings")

  f.logo = f:CreateTexture(nil, "ARTWORK")
  f.logo:SetSize(28, 28)
  f.logo:SetPoint("TOPLEFT", 10, -6)
  f.logo:SetTexture(ns.LOGO_SMALL)

  f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.title:SetPoint("TOPLEFT", 42, -14)

  f.intro = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  f.intro:SetPoint("TOPLEFT", 16, -40)
  f.intro:SetWidth(W - 32)
  f.intro:SetJustifyH("LEFT")
  f.intro:SetText("See your friends' big moments as they happen, and catch up on what you missed. Pick what you share and what you want to hear about. You can change this any time with |cffffd200/ff settings|r.")

  local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)

  -- offline sync: always open, down the right (placed by S:Layout)
  f.offline = BuildOffline(f)
  -- friends need Friend Feed too (placed by S:Layout)
  f.network = BuildNetworkNotice(f)

  -- tabs (placed by S:Layout)
  f.tabs = {}
  for _, t in ipairs({ { key = "general", label = "General" }, { key = "sounds", label = "Sounds" }, { key = "guild", label = "Guild" }, { key = "friends", label = "Friends" }, { key = "following", label = "Following" }, { key = "accolades", label = "Accolades" }, { key = "help", label = "Help" } }) do
    local b = CreateFrame("Button", nil, f, "BackdropTemplate")
    b:SetSize(TAB_W, 22)
    b:SetBackdrop(BACKDROP)
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall") -- small: seven tabs share the width
    b.text:SetPoint("CENTER")
    b.text:SetText(t.label)
    b.key = t.key
    b:SetScript("OnClick", function() S:ShowTab(t.key) end)
    f.tabs[#f.tabs + 1] = b
  end

  f.general = CreateFrame("Frame", nil, f)
  f.general:SetSize(W - 32, BODY_H)
  BuildGeneral(f.general)

  f.sounds = CreateFrame("Frame", nil, f)
  f.sounds:SetSize(W - 32, BODY_H)
  f.sounds:Hide()
  BuildSounds(f.sounds)

  f.guild = CreateFrame("Frame", nil, f)
  f.guild:SetSize(W - 32, BODY_H)
  f.guild:Hide()
  BuildGuild(f.guild)

  f.friends = CreateFrame("Frame", nil, f)
  f.friends:SetSize(W - 32, BODY_H)
  BuildFriends(f.friends)

  f.following = CreateFrame("Frame", nil, f)
  f.following:SetSize(W - 32, BODY_H)
  f.following:Hide()
  BuildFollowing(f.following)

  f.help = CreateFrame("Frame", nil, f)
  f.help:SetSize(W - 32, BODY_H)
  f.help:Hide()
  BuildHelp(f.help)

  f.accolades = CreateFrame("Frame", nil, f)
  f.accolades:SetSize(W - 32, BODY_H)
  f.accolades:Hide()
  BuildAccolades(f.accolades)

  f.friendEdit = CreateFrame("Frame", nil, f)
  f.friendEdit:SetSize(W - 32, BODY_H)
  f.friendEdit:Hide()
  BuildFriendEdit(f.friendEdit)

  -- Footer (setup mode only)
  local footer = CreateFrame("Frame", nil, f)
  footer:SetSize(W - 32, 26)
  footer:SetPoint("BOTTOMLEFT", 16, 14)
  local demo = CreateFrame("Button", nil, footer, "UIPanelButtonTemplate")
  demo:SetSize(150, 24)
  demo:SetPoint("LEFT")
  demo:SetText("Preview with demo")
  demo:SetScript("OnClick", function() f:Hide(); ns:Demo() end)
  local done = CreateFrame("Button", nil, footer, "UIPanelButtonTemplate")
  done:SetSize(110, 24)
  done:SetPoint("RIGHT")
  done:SetText("Done")
  done:SetScript("OnClick", function() f:Hide() end)
  f.footer = footer

  f:SetScript("OnHide", function(self)
    if self.setupMode and not settings().setupDone then
      ns.Print("All set! Change this any time with |cffffd200/ff settings|r.")
    end
    settings().setupDone = true
  end)

  self.frame = f
end

function S:ShowTab(key)
  local f = self.frame
  f.tab = key
  f.general:SetShown(key == "general")
  f.sounds:SetShown(key == "sounds")
  f.guild:SetShown(key == "guild")
  f.friends:SetShown(key == "friends")
  f.following:SetShown(key == "following")
  f.help:SetShown(key == "help")
  f.accolades:SetShown(key == "accolades")
  if key == "accolades" then f.accolades:Refresh() end
  f.friendEdit:Hide()
  for _, b in ipairs(f.tabs) do paintChoice(b, b.key == key, GOLD) end
  if key == "friends" then f.friends.offset = 0; f.friends.showRemoved = false; self:RefreshList(f.friends) end
  if key == "guild" then f.guild.offset = 0; f.guild.showRemoved = false; self:RefreshList(f.guild) end
  if key == "following" then f.following.offset = 0; f.following.showRemoved = false; self:RefreshList(f.following) end
end

function S:Open(setupMode, tab)
  local f = self.frame
  f.setupMode = setupMode
  f.title:SetText(setupMode and "Welcome to Friend Feed" or "Friend Feed Settings")
  self:Layout()
  changed()
  self:ShowTab(setupMode and "general" or (tab or f.tab or "general"))
  f:Show()
end

function S:Toggle()
  if self.frame:IsShown() then self.frame:Hide() else self:Open(false) end
end

-- called when something outside the window (like /ff sound) changes a setting
function S:Refresh()
  if self.frame and self.frame:IsShown() then changed() end
end

---------------------------------------------------------------------------
-- Wiring
---------------------------------------------------------------------------
ns:On("DB_READY", function()
  S:Create()

  -- an entry under Esc > Options > AddOns that opens this window
  if Settings and Settings.RegisterCanvasLayoutCategory then
    pcall(function()
      local panel = CreateFrame("Frame")
      local logo = panel:CreateTexture(nil, "ARTWORK")
      logo:SetSize(96, 96)
      logo:SetPoint("TOPLEFT", 10, -10)
      logo:SetTexture(ns.LOGO)
      local t = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
      t:SetPoint("TOPLEFT", 112, -30)
      t:SetText("Friend Feed")
      local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
      b:SetSize(180, 26)
      b:SetPoint("TOPLEFT", 112, -58)
      b:SetText("Open settings")
      b:SetScript("OnClick", function()
        if SettingsPanel and SettingsPanel:IsShown() then HideUIPanel(SettingsPanel) end
        S:Open(false)
      end)
      local cat = Settings.RegisterCanvasLayoutCategory(panel, "Friend Feed")
      Settings.RegisterAddOnCategory(cat)
    end)
  end
end)

ns:On("LOGIN", function()
  if not ns.db.settings.setupDone then
    C_Timer.After(3, function() S:Open(true) end)
  end
end)

-- the Accolades tab follows what you earn while it's open
ns:On("ACCOLADES_CHANGED", function()
  local f = S.frame
  if f and f.accolades and f.accolades:IsShown() then f.accolades:Refresh() end
end)
