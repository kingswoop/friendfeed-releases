local ADDON, ns = ...

---------------------------------------------------------------------------
-- The website's game code (0.9.10). For players who'd rather not install the
-- Friend Feed app: they follow people and join the public list on the
-- website (friendfeedwow.com/code), which gives them one line to paste here
-- with /ff code. It carries what the app would write into Inbox.lua for live
-- following: their own secret (when public) and, for each person they follow,
-- the name, characters and the passes for their own characters. Saved in
-- FriendFeedDB.gameCode and merged with the inbox by ns:IngestInbox.
--
-- Format (web/lib/core/gamecode.js): "FF1:" .. base64 of the lines
--   ff1 / <made at> / <secret or empty> / <my char keys, tab separated>
--   <handle> TAB <name> TAB <friend tag> TAB <passes, 16 hex each> TAB <who> TAB <rs> ...
--   @me TAB <my public name>   (public profiles only, 0.9.15)
--   end
---------------------------------------------------------------------------
local Code = {}
ns.Code = Code

local PASS_LEN = 16
local NO_PASS = string.rep("0", PASS_LEN)
local MAX_FOLLOWING = 200
local MAX_CHARS = 5   -- per followed person, like the inbox
local MAX_KEYS = 10   -- my characters with passes
Code.PAGE = ns.SITE .. "/code"

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B64DEC = {}
for i = 1, 64 do B64DEC[B64:sub(i, i)] = i - 1 end

-- base64 -> bytes, or nil when it isn't valid (cut off, or not base64)
function Code.Base64Decode(s)
  s = tostring(s or ""):gsub("%s", "")
  if #s == 0 or #s % 4 ~= 0 then return nil end
  local out = {}
  for i = 1, #s, 4 do
    local a, b = B64DEC[s:sub(i, i)], B64DEC[s:sub(i + 1, i + 1)]
    local c, d = s:sub(i + 2, i + 2), s:sub(i + 3, i + 3)
    if not a or not b then return nil end
    local n = a * 262144 + b * 4096
    out[#out + 1] = string.char(math.floor(n / 65536))
    if c ~= "=" then
      local cv = B64DEC[c]
      if not cv then return nil end
      n = n + cv * 64
      out[#out + 1] = string.char(math.floor(n / 256) % 256)
      if d ~= "=" then
        local dv = B64DEC[d]
        if not dv then return nil end
        out[#out + 1] = string.char((n + dv) % 256)
      end
    elseif d ~= "=" then
      return nil
    end
    if (c == "=" or d == "=") and i + 4 <= #s then return nil end -- padding only at the end
  end
  return table.concat(out)
end

local function split(s, sep)
  local t = {}
  for part in (s .. sep):gmatch("(.-)" .. sep) do t[#t + 1] = part end
  return t
end

local function clean(s, max)
  s = tostring(s or ""):gsub("[%c|]", ""):gsub("%s+", " "):match("^%s*(.-)%s*$")
  return s:sub(1, max)
end

-- The pasted text -> { at, secret, keys, following = { { id, name, friend, chars, tokens } } },
-- or nil and a message for the player
function Code.Parse(text)
  text = tostring(text or "")
  local body = text:match("[Ff][Ff]1:%s*([%w%+/=%s]+)")
  if not body then
    return nil, "That isn't a Friend Feed code. On the website, click Copy my code, then paste it here."
  end
  local raw = Code.Base64Decode(body)
  local lines = raw and split(raw, "\n")
  if not lines or lines[1] ~= "ff1" or lines[#lines] ~= "end" or #lines < 5 then
    return nil, "The code looks cut off. Copy the whole code from the website again."
  end
  local code = { at = tonumber(lines[2]) or 0, following = {}, keys = {} }
  local secret = lines[3]
  if secret:match("^%x+$") and #secret >= 32 and #secret <= 128 then code.secret = secret:lower() end
  if lines[4] ~= "" then
    for _, k in ipairs(split(lines[4], "\t")) do
      if #code.keys < MAX_KEYS then code.keys[#code.keys + 1] = clean(k, 80) end
    end
  end
  for i = 5, #lines - 1 do
    local f = split(lines[i], "\t")
    local handle, name, friend, passes = f[1] or "", f[2] or "", f[3] or "", f[4] or ""
    -- my own public name (0.9.15), for the feed's "Follow me" line
    if handle == "@me" and name:match("^[%w_]+$") and #name <= 24 then code.handle = name end
    if handle:match("^[%w_]+$") and name:match("^[%w_]+$") and #code.following < MAX_FOLLOWING then
      local entry = { id = "pub:" .. handle:lower(), name = name, chars = {}, tokens = {} }
      if friend:match("^[^%s#|]+#%d+$") then entry.friend = friend end
      for k, key in ipairs(code.keys) do
        local t = passes:sub(k * PASS_LEN - PASS_LEN + 1, k * PASS_LEN):lower()
        if #t == PASS_LEN and t:match("^%x+$") and t ~= NO_PASS then
          entry.tokens[#entry.tokens + 1] = { c = key, t = t }
        end
      end
      for j = 5, #f, 2 do
        local who = clean(f[j], 48)
        if who ~= "" and #entry.chars < MAX_CHARS then
          entry.chars[#entry.chars + 1] = { who = who, rs = clean(f[j + 1], 24) }
        end
      end
      code.following[#code.following + 1] = entry
    end
  end
  return code
end

-- Does the saved code carry a pass for the character I'm on?
function Code:HasPassHere(code)
  code = code or ns.db.gameCode
  if type(code) ~= "table" then return false end
  local mine = ns.LiveKey(ns.PlayerName(), ns.MyRuleset())
  for _, k in ipairs(code.keys or {}) do
    if k == mine then return true end
  end
  return false
end

-- Apply now: no /reload needed. Hellos go out on the next pass of the
-- follow loop (or straight away here).
local function apply()
  ns:IngestInbox()
  if ns.Sync and ns.Sync.SayHi then ns.Sync:SayHi() end
  if ns.Settings and ns.Settings.Refresh then pcall(ns.Settings.Refresh, ns.Settings) end
  if ns.UI and ns.UI.RequestRefresh then ns.UI:RequestRefresh() end
end

function Code:Save(text)
  local code, err = Code.Parse(text)
  if not code then return nil, err end
  code.savedAt = ns.Now()
  ns.db.gameCode = code
  apply()
  return code
end

function Code:Remove()
  ns.db.gameCode = nil
  ns.rebuildFollowing = true -- the inbox may have no list to rebuild from
  apply()
  ns.rebuildFollowing = nil
end

local Y, G, O, R = "|cffffd200", "|cff40ff40", "|cffff9a30", "|r"

-- What the window says about the saved code (also printed by /ff code status)
function Code:StatusText()
  local code = ns.db.gameCode
  if type(code) ~= "table" then
    return "No code saved yet."
  end
  local n = #(code.following or {})
  local parts = {}
  parts[#parts + 1] = G .. "Code saved." .. R .. " Made on the website " .. ns.Ago(code.at) .. (ns.Ago(code.at) == "now" and "" or " ago")
    .. ". You follow " .. n .. (n == 1 and " person" or " people") .. " with it."
  if code.secret then parts[#parts + 1] = "Your followers can reach you." end
  if n > 0 and not self:HasPassHere(code) then
    parts[#parts + 1] = O .. "This character isn't in the code, so the people you follow won't answer it. Add "
      .. ns.PlayerName() .. " (" .. (ns.MyRuleset() or "?") .. ") under Your characters on the website, then paste a new code." .. R
  end
  return table.concat(parts, "\n")
end

---------------------------------------------------------------------------
-- The window (/ff code, and the Following tab's Website code button)
---------------------------------------------------------------------------
local W = 420

local function readOnlyBox(parent, w, get)
  local box = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
  box:SetSize(w, 20)
  box:SetAutoFocus(false)
  box:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
  box:SetScript("OnTextChanged", function(self, byUser)
    if byUser and self:GetText() ~= get() then self:SetText(get()); self:HighlightText() end
  end)
  box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  function box:Update() self:SetText(get()) end
  return box
end

function Code:Create()
  if self.frame then return self.frame end
  local UI = ns.UI
  local p = CreateFrame("Frame", "FriendFeedCodeFrame", UIParent, "BackdropTemplate")
  p:SetWidth(W)
  p:SetFrameStrata("DIALOG")
  p:SetToplevel(true)
  p:SetPoint("CENTER", UIParent, "CENTER", 0, 60)
  p:Hide()
  if UI.Skin then UI.Skin(p, 0.96) end
  if UI.MakeDraggable then UI.MakeDraggable(p) end
  tinsert(UISpecialFrames, "FriendFeedCodeFrame") -- Esc closes it
  local inner = W - 24
  local function text(font, w)
    local fs = p:CreateFontString(nil, "OVERLAY", font)
    fs:SetWidth(w or inner)
    fs:SetJustifyH("LEFT")
    return fs
  end

  p.logo = p:CreateTexture(nil, "ARTWORK")
  p.logo:SetSize(26, 26)
  p.logo:SetPoint("TOPLEFT", 8, -6)
  p.logo:SetTexture(ns.LOGO_SMALL)
  p.title = text("GameFontNormalLarge", inner - 50)
  p.title:SetPoint("LEFT", p.logo, "RIGHT", 6, 0)
  p.title:SetText("Website code")
  local close = CreateFrame("Button", nil, p, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", 2, 2)

  p.intro = text("GameFontHighlightSmall")
  p.intro:SetPoint("TOPLEFT", 12, -40)
  p.intro:SetText("No app? You can follow people and join the public list on the website instead. It gives you a code: paste it below and it works straight away.")

  p.siteLabel = text("GameFontNormalSmall", 80)
  p.siteLabel:SetPoint("TOPLEFT", p.intro, "BOTTOMLEFT", 0, -12)
  p.siteLabel:SetText("Website")
  p.site = readOnlyBox(p, 200, function() return Code.PAGE end)
  p.site:SetPoint("LEFT", p.siteLabel, "LEFT", 92, 0)
  p.siteHint = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  p.siteHint:SetPoint("LEFT", p.site, "RIGHT", 8, 0)
  p.siteHint:SetText("click, then Ctrl+C")

  p.charHead = text("GameFontNormalSmall")
  p.charHead:SetPoint("TOPLEFT", p.siteLabel, "BOTTOMLEFT", 0, -16)
  p.charHead:SetText("This character, for Your characters on the website:")
  p.nameLabel = text("GameFontHighlightSmall", 80)
  p.nameLabel:SetPoint("TOPLEFT", p.charHead, "BOTTOMLEFT", 0, -10)
  p.nameLabel:SetText("Name")
  p.name = readOnlyBox(p, 150, function() return ns.PlayerName() or "" end)
  p.name:SetPoint("LEFT", p.nameLabel, "LEFT", 92, 0)
  p.rsLabel = text("GameFontHighlightSmall", 60)
  p.rsLabel:SetPoint("LEFT", p.name, "RIGHT", 14, 0)
  p.rsLabel:SetText("Ruleset")
  p.rs = readOnlyBox(p, 80, function() return ns.MyRuleset() or "" end)
  p.rs:SetPoint("LEFT", p.rsLabel, "LEFT", 54, 0)

  p.pasteHead = text("GameFontNormalSmall")
  p.pasteHead:SetPoint("TOPLEFT", p.nameLabel, "BOTTOMLEFT", 0, -18)
  p.pasteHead:SetText("Paste your code here (Ctrl+V), then click Save:")
  local box = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
  box:SetSize(inner - 8, 22)
  box:SetPoint("TOPLEFT", p.pasteHead, "BOTTOMLEFT", 6, -6)
  box:SetAutoFocus(false)
  pcall(box.SetMaxLetters, box, 0) -- codes can be long
  pcall(box.SetMaxBytes, box, 0)
  box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  box:SetScript("OnEnterPressed", function() Code:SaveFromBox() end)
  p.box = box

  local save = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
  save:SetSize(90, 22)
  save:SetPoint("TOPLEFT", box, "BOTTOMLEFT", -6, -8)
  save:SetText("Save")
  save:SetScript("OnClick", function() Code:SaveFromBox() end)
  p.save = save
  local remove = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
  remove:SetSize(110, 22)
  remove:SetPoint("LEFT", save, "RIGHT", 8, 0)
  remove:SetText("Remove code")
  remove:SetScript("OnClick", function()
    Code:Remove()
    p.box:SetText("")
    Code:ShowMessage("Code removed.")
  end)
  p.remove = remove

  p.message = text("GameFontHighlightSmall")
  p.message:SetPoint("TOPLEFT", save, "BOTTOMLEFT", 0, -10)
  p.status = text("GameFontHighlightSmall")
  p.status:SetPoint("TOPLEFT", p.message, "BOTTOMLEFT", 0, -6)
  p.note = text("GameFontDisableSmall")
  p.note:SetPoint("TOPLEFT", p.status, "BOTTOMLEFT", 0, -12)
  p.note:SetText("Paste a new code whenever you follow someone new, play a new character, or someone you follow starts a new one. "
    .. "The people you follow need their own code in their game too (or the Friend Feed app), or their game can't answer yours. "
    .. "Live only: while you're both online on the same ruleset and faction.")

  function p:Fit()
    local th = (UI.TextHeight or function(_, g) return g end)
    local h = 40 + th(self.intro, 26) + 12 + 20 + 16 + th(self.charHead, 12) + 10 + 20 + 18
      + th(self.pasteHead, 12) + 6 + 22 + 8 + 22 + 10 + th(self.message, 12) + 6 + th(self.status, 40) + 12 + th(self.note, 52) + 14
    self:SetHeight(h)
  end
  self.frame = p
  return p
end

function Code:ShowMessage(msg)
  local p = self.frame
  if not p then return end
  p.message:SetText(msg or "")
  p.status:SetText(self:StatusText())
  p:Fit()
end

function Code:SaveFromBox()
  local p = self.frame
  if not p then return nil end
  local code, err = self:Save(p.box:GetText())
  if code then
    p.box:SetText("")
    p.box:ClearFocus()
    self:ShowMessage(G .. "Saved. It works now, no /reload needed." .. R)
  else
    self:ShowMessage("|cffff6060" .. err .. R)
  end
  return code, err
end

function Code:Open()
  local p = self:Create()
  p.site:Update()
  p.name:Update()
  p.rs:Update()
  self:ShowMessage("")
  p:Show()
  return p
end

function Code:Toggle()
  if self.frame and self.frame:IsShown() then self.frame:Hide() else self:Open() end
end

-- At login: a code without this character can't follow anyone from here,
-- so say so once (after the other login lines)
ns:On("LOGIN", function()
  if not C_Timer then return end
  C_Timer.After(8, function()
    local code = ns.db and ns.db.gameCode
    if type(code) == "table" and #(code.following or {}) > 0 and not Code:HasPassHere(code) then
      ns.Print("your website code doesn't include " .. ns.PlayerName() .. ", so the people you follow won't answer this character. "
        .. "Add it on " .. Code.PAGE .. " and paste a new code with " .. Y .. "/ff code" .. R .. ".")
    end
  end)
end)
