local ADDON, ns = ...

ns.PREFIX = "FriendFeed"
ns.MAX_SUB = 60 -- longest "where it came from" line (ev.s), same as item names (n)
ns.VERSION = "0.9.5"
-- The banner logo (Media/Logo.tga, 256x256 with transparent edges; LogoSmall is 64x64)
ns.LOGO = "Interface\\AddOns\\" .. ADDON .. "\\Media\\Logo"
ns.LOGO_SMALL = "Interface\\AddOns\\" .. ADDON .. "\\Media\\LogoSmall"
-- kill = world PvP kills (v0.9.0): v = how many players, n = who, s = where
ns.KINDS = { loot = true, level = true, ach = true, mount = true, pet = true, toy = true, death = true, kill = true }

-- The Friend Feed app and its website, as named in game (settings panel, the
-- feed logo's panel, the weekly chat line). Plain facts only: never a price,
-- "free", "premium" or paying (Blizzard's add-on policy; a test checks).
ns.SITE = "friendfeedwow.com"
ns.APP_BENEFITS = {
  "See what your friends got up to while you were offline",
  "Your big moments reach friends even after you log off",
  "Follow streamers, or go public so anyone can follow you",
  "Quick to set up, and the addon works fine without it",
}

---------------------------------------------------------------------------
-- Is the Friend Feed app set up? The app rewrites Inbox.lua on every sync
-- (free or not) and stamps generatedAt; the copy that ships in the addon
-- (CurseForge, the website zip) has 0. The game reads the file at login and
-- on /reload. Returns "none" | "connected" | "stale", and the last sync time.
---------------------------------------------------------------------------
local APP_STALE_AFTER = 3 * 86400
ns.APP_STALE_AFTER = APP_STALE_AFTER
function ns:AppStatus()
  local inbox = FriendFeedInbox
  local t = type(inbox) == "table" and tonumber(inbox.generatedAt) or 0
  if not t or t <= 0 then return "none", nil end
  if ns.Now() - t > APP_STALE_AFTER then return "stale", t end
  return "connected", t
end

local defaults = {
  log = {},        -- every milestone we know about, oldest first
  seen = {},       -- uid -> true, for de-duplication
  outbox = {},     -- your own milestones, waiting for the companion app to upload
  read = {},       -- friend id -> time you last looked at their history
  viewed = {},     -- uid -> time you hovered that milestone in the feed (counts as seen)
  likes = {},      -- uid of YOUR milestone -> { [friend id] = { n = label, t = time } }: who liked it
  liked = {},      -- uid of a friend's milestone -> time you liked it
  heard = {},      -- uid of a friend's milestone -> { [liker] = time }: likes the people who gave them told you about (0.9.5)
  likeOut = {},    -- likes waiting for their owner to come online: { id, who, t, k, v, on, at }
  readAll = 0,
  feedClearedAt = 0, -- the feed only shows things received after this; history keeps everything
  lastLogout = 0,
  sessionPrevLogout = 0,
  -- read by the companion app (see docs/SYNC-SPEC.md)
  bnFriends = {},            -- BattleTag -> time last seen in your Battle.net friend list
  bnFriendsComplete = false, -- true once the list was read while Battle.net was connected
  me = {},                   -- { battleTag, name, ruleset } for display in the app
  following = {},            -- "pub:handle" -> public name, people you follow (from Inbox.lua)
  chars = {},                -- friend id -> { ["name-ruleset"] = { who, rs, seen } }, characters seen
  guildmates = {},           -- id -> time last heard from, for guildmates who aren't friends (Guild tab)
  settings = {
    setupDone = false,
    -- what YOU share: everything (the user's call). Gear is always green and up
    -- since v0.8.7 (the choice is gone from settings); deaths and guild can be unticked
    minQuality = 2,      -- lowest gear quality shared: 2 = uncommon (green)
    likePopups = true,   -- a pop-up when someone likes one of your milestones (the count always shows)
    shareDeaths = true,  -- whether YOUR deaths are shared
    shareKills = true,   -- whether YOUR world PvP kills are shared (never battlegrounds or arenas)
    -- what you get notified about (feed + pop-ups)
    notify = {
      loot = 3,          -- 0 = off, otherwise minimum item quality
      level = "ten",     -- "off" | "max" | "ten" | "all"
      ach = true,
      mount = true,
      pet = true,
      toy = true,
      death = true,
      kill = true,       -- friends' world PvP kills
    },
    muted = {},          -- friend id -> true: no pop-ups, sounds or feed rows from them
    removed = {},        -- friend id -> { label, t, guild }: not tracked at all (Friends tab > Removed)
    perFriend = {},      -- friend id -> custom notify table (same keys as notify); missing = use notify
    -- what you get told about from guildmates who aren't friends (Guild tab); same keys as notify
    guildNotify = { loot = 4, level = "max", ach = false, mount = false, pet = false, toy = false, death = false, kill = false },
    showSelf = true,     -- your own milestones in the feed (with a pop-up), so you see their likes
    includeGuild = true, -- also share with (and hear from) guildmates who have the addon
    locked = false,
    toasts = true,
    soundVolume = 100,   -- percent of the game's master volume, 0 = no sounds, up to 300
    lastSoundVolume = 100, -- what /ff sound turns sounds back on to
    feedShown = true,
    minimap = { angle = 215, hide = false }, -- the minimap button: degrees round the edge (0 = right, 90 = top)
    -- toastPoint = { point, relativePoint, x, y } on UIParent once the player moves the pop-ups;
    -- missing = under the feed (or where the feed would be while it's hidden)
    feedStyle = "comfortable", -- "comfortable" (cards) | "compact" | "chat" (no box) | "timeline" (by day), see UI.lua
    feedDim = true,      -- fade the feed down when nothing new has happened for a while
    feedAlpha = 70,      -- how solid the feed's background is, 0 (see-through) to 100 percent
    filterBar = true,    -- the row of filter toggles under the feed's header
    feedFilter = { kinds = {}, quality = {} }, -- what the filter bar hides from the feed (false = hidden)
    sounds = {},         -- kind -> a UI.SOUND_OPTIONS value ("epic", "raidwarning", "none"...); missing = UI.DEFAULT_SOUNDS
    maxLog = 2000,
  },
}

local function applyDefaults(dst, src)
  for k, v in pairs(src) do
    if type(v) == "table" then
      if type(dst[k]) ~= "table" then dst[k] = {} end
      applyDefaults(dst[k], v)
    elseif dst[k] == nil then
      dst[k] = v
    end
  end
end

---------------------------------------------------------------------------
-- Tiny callback system
---------------------------------------------------------------------------
local listeners = {}
function ns:On(name, fn)
  listeners[name] = listeners[name] or {}
  table.insert(listeners[name], fn)
end
function ns:Fire(name, ...)
  local list = listeners[name]
  if not list then return end
  for _, fn in ipairs(list) do
    local ok, err = pcall(fn, ...)
    if not ok then geterrorhandler()(err) end
  end
end

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
function ns.IsSecret(v) return issecretvalue ~= nil and issecretvalue(v) or false end
function ns.Now() return GetServerTime() end
function ns.Print(...) print("|cffffd200Friend Feed:|r", ...) end

---------------------------------------------------------------------------
-- Update notice: every Friend Feed says its version when it says hello (and
-- in pings). Hearing a newer one than yours prints "An update is available"
-- in chat, once per session, and again at the next login until you update.
---------------------------------------------------------------------------
function ns.ParseVersion(s)
  if type(s) ~= "string" or #s > 20 or ns.IsSecret(s) then return nil end
  local a, b, c = s:match("^(%d+)%.(%d+)%.(%d+)$")
  if not a then return nil end
  return { tonumber(a), tonumber(b), tonumber(c) }
end

-- is version a newer than version b?
function ns.NewerVersion(a, b)
  local x, y = ns.ParseVersion(a), ns.ParseVersion(b)
  if not (x and y) then return false end
  for i = 1, 3 do
    if x[i] ~= y[i] then return x[i] > y[i] end
  end
  return false
end

-- Remember a newer version than yours (from a friend, or from the app through
-- Inbox.lua). Returns true when it is newer than yours.
function ns:RememberVersion(v)
  if not ns.NewerVersion(v, ns.VERSION) then return false end
  -- a far-off number is someone's typo or a joke, not a release
  if ns.ParseVersion(v)[1] > ns.ParseVersion(ns.VERSION)[1] + 1 then return false end
  local db = ns.db
  if not ns.NewerVersion(db.newestVersion, v) then db.newestVersion = v end
  return true
end

-- A version heard from another player's Friend Feed. Returns true when it's
-- newer than yours (and the notice was due).
function ns:NoteVersion(v)
  if not ns:RememberVersion(v) then return false end
  return ns:TellUpdate()
end

-- Print the notice for the newest version heard, once per session.
-- Returns true if it printed.
function ns:TellUpdate()
  local v = ns.db.newestVersion
  if not ns.NewerVersion(v, ns.VERSION) then
    ns.db.newestVersion = nil -- you've updated since
    return false
  end
  if ns.toldUpdate == v then return false end
  ns.toldUpdate = v
  local head = "|cff00ff00An update is available!|r Version " .. v .. " is out (you have " .. ns.VERSION .. "). "
  if ns:AppStatus() == "connected" then
    -- the app puts it in while the game is closed or at the logout screen
    ns.Print(head .. "The Friend Feed app installs it for you: log out, wait a moment and log back in. "
      .. "If it still hasn't arrived, open the app and check the Addon card.")
  else
    local where = ns.UI and ns.UI.AppLinkText and ns.UI:AppLinkText() or ns.SITE
    ns.Print(head .. "The Friend Feed app updates it for you, or get it from CurseForge or " .. where .. ".")
  end
  return true
end
-- Your character's full name. In Forever, UnitName returns the first name and
-- the SURNAME as its two values (other WoW versions return a realm there, and
-- nothing for yourself): "Not", "Theo" -> "Not Theo". Confirmed in game with
-- /ff names on 2026-11-07.
function ns.FullUnitName(unit)
  local first, last = UnitName(unit)
  if type(first) ~= "string" or first == "" or ns.IsSecret(first) then return first end
  if type(last) == "string" and last ~= "" and not ns.IsSecret(last)
    and not last:find("[%-%s]") and last ~= (GetRealmName and GetRealmName() or "") then
    return first .. " " .. last
  end
  return first
end

function ns.PlayerName() return ns.FullUnitName("player") end

function ns.Ago(t)
  local d = ns.Now() - (t or 0)
  if d < 60 then return "now"
  elseif d < 3600 then return math.floor(d / 60) .. "m"
  elseif d < 86400 then return math.floor(d / 3600) .. "h"
  end
  return math.floor(d / 86400) .. "d"
end

function ns.QualityHex(q)
  if q and C_Item and C_Item.GetItemQualityColor then
    local _, _, _, hex = C_Item.GetItemQualityColor(q)
    if hex then return "|c" .. hex end
  end
  return "|cffffffff"
end

---------------------------------------------------------------------------
-- Identity
-- Forever has rulesets (Normal, PvP, RP, RP-PvP, Hardcore) instead of realms,
-- each its own world, so a character name alone is not unique. Friends are
-- keyed by Battle.net account (BattleTag) where we know it, otherwise by
-- "char:name-realm". The character name and ruleset are kept for display.
---------------------------------------------------------------------------
local RULESETS = { -- checked in order against the squashed realm name
  { "rppvp", "RP-PvP" }, { "hardcore", "Hardcore" }, { "pvp", "PvP" },
  { "rp", "RP" }, { "normal", "Normal" }, { "pve", "Normal" },
}

function ns.Squash(s) return (tostring(s or ""):lower():gsub("[%s%p]", "")) end

local function usable(s)
  return type(s) == "string" and s ~= "" and not ns.IsSecret(s)
end
ns.Usable = usable

-- Realm name -> ruleset label. Unknown names are shown as they are.
function ns.Ruleset(realm)
  if not usable(realm) then return nil end
  local s = ns.Squash(realm)
  for _, r in ipairs(RULESETS) do
    local token = r[1]
    if s == token or s:sub(1, #token) == token or s:sub(-#token) == token then return r[2] end
  end
  return realm
end

function ns.MyRealm() return GetRealmName and GetRealmName() or "" end
function ns.MyRuleset() return ns.Ruleset(ns.MyRealm()) end

-- "Name-Realm" -> "Name", "Realm" (realm defaults to yours)
function ns.SplitName(full)
  full = tostring(full or "")
  local name, realm = full:match("^([^%-]+)%-(.+)$")
  if not name then return full, ns.MyRealm() end
  return name, realm
end

function ns.CharKey(name, realm)
  if not realm or realm == "" then name, realm = ns.SplitName(name) end
  return "char:" .. tostring(name or "?"):lower() .. "-" .. ns.Squash(realm)
end

-- Your own id: your BattleTag, or your character if Battle.net is unavailable.
local selfTag
function ns.SelfID()
  if selfTag then return selfTag end
  if BNGetInfo then
    local ok, _, tag = pcall(BNGetInfo)
    if ok and usable(tag) then selfTag = tag; return tag end
  end
  return ns.CharKey(ns.PlayerName(), ns.MyRealm())
end

-- The name on its own ("Grommash Ironhide", or a followed player's public
-- name) and the rest for a second line: "RP-PvP", or "Thrall Hellscream, RP-PvP"
-- for a followed player.
function ns.NameParts(ev)
  local handle = ev.id and ns.db and ns.db.following and ns.db.following[ev.id]
  if handle then
    local char = ev.who and (ev.rs and (ev.who .. ", " .. ev.rs) or ev.who) or nil
    return handle, char
  end
  return ev.who or "?", ev.rs
end

-- "Grommash (RP-PvP)", optionally with the name in gold. People you follow
-- (id "pub:...") show their public name first: "StreamerName (Thrall, RP-PvP)".
function ns.Label(ev, gold)
  local handle = ev.id and ns.db and ns.db.following and ns.db.following[ev.id]
  if handle then
    local name = gold and ("|cffffd200" .. handle .. "|r") or handle
    local char = ev.who and (ev.rs and (ev.who .. ", " .. ev.rs) or ev.who)
    if char then name = name .. " |cff9d9d9d(" .. char .. ")|r" end
    return name
  end
  local name = ev.who or "?"
  if gold then name = "|cffffd200" .. name .. "|r" end
  if ev.rs then name = name .. " |cff9d9d9d(" .. ev.rs .. ")|r" end
  return name
end

---------------------------------------------------------------------------
-- The log
---------------------------------------------------------------------------
-- A character name is unique within a ruleset, so name + ruleset identifies
-- the event no matter which channel (Battle.net, whisper, inbox) it came by.
local function uid(ev)
  return table.concat({ ev.who:lower() .. "-" .. ns.Squash(ev.rs or "?"), ev.t or 0, ev.k or "?", ev.v or 0 }, ":")
end

-- the uid of a milestone from its parts, the same one ns:AddEvent gives it
function ns.EventUID(who, rs, t, k, v)
  return uid({ who = who, rs = rs, t = t, k = k, v = v })
end

function ns:AddEvent(ev, source)
  if type(ev) ~= "table" or not usable(ev.who) or not ns.KINDS[ev.k] then return end
  -- text from other players: drop "|" so nobody can sneak WoW color or link codes in
  -- names can have a first and last name in Forever: keep one space between them
  ev.who = ev.who:gsub("|", ""):gsub("%s+", " "):match("^%s*(.-)%s*$"):sub(1, 48)
  if type(ev.n) == "string" then ev.n = ev.n:gsub("|", "") end
  if type(ev.rs) == "string" then ev.rs = ev.rs:gsub("|", "") end
  -- s = where it came from ("Baron Rivendare, Stratholme"), display text only
  if type(ev.s) == "string" then
    ev.s = ev.s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|", "")
      :gsub("%s+", " "):match("^%s*(.-)%s*$"):sub(1, ns.MAX_SUB)
  end
  if not usable(ev.s) then ev.s = nil end
  if not usable(ev.who) then return end
  if not usable(ev.id) then ev.id = ev.who end
  -- someone you stopped tracking (Friends tab > Removed): ignored until you add them back
  if not ev.self and ns:IsRemoved(ev.id) then return end
  if not usable(ev.rs) then ev.rs = nil end
  ev.t = tonumber(ev.t) or ns.Now()
  ev.v = tonumber(ev.v) or 0
  ev.q = tonumber(ev.q)
  -- d: the game's running total, sent with a death (total deaths, v0.8.4)
  -- or a world PvP kill (lifetime honorable kills, v0.9.1)
  ev.d = (ev.k == "death" or ev.k == "kill") and tonumber(ev.d) or nil
  if ev.d and (ev.d < 1 or ev.d > 1000000 or ev.d % 1 ~= 0) then ev.d = nil end
  local db = ns.db
  local id = uid(ev)
  if db.seen[id] then return end
  db.seen[id] = true
  ev.uid = id
  ev.recv = ns.Now()

  -- keep the log sorted by time (almost always an append)
  local log = db.log
  local i = #log
  while i > 0 and (log[i].t or 0) > ev.t do i = i - 1 end
  table.insert(log, i + 1, ev)
  while #log > db.settings.maxLog do
    local old = table.remove(log, 1)
    if old and old.uid then db.seen[old.uid] = nil end
  end

  if not ev.self and not ev.demo then ns:NoteCharacter(ev.id, ev.who, ev.rs, ev.t) end
  ns:Fire("EVENT_ADDED", ev, source)
  return ev
end

-- New = happened since you were last online, and arrived after you last
-- looked at that friend's history.
function ns:IsNew(ev)
  if ev.self then return false end
  if not ev.demo and ev.t <= (ns.prevLogout or 0) then return false end
  if ns:IsViewed(ev) then return false end
  return ns:SinceLastLook(ev)
end

---------------------------------------------------------------------------
-- Seen: you've looked at that friend's history (or All friends) since the
-- milestone arrived, or hovered it in the feed. The history window puts what
-- you haven't seen on top, then an "Already seen" divider, then the rest faded,
-- so after logging back in it's clear what you missed.
---------------------------------------------------------------------------
function ns:LastLook(id)
  local db = ns.db
  return math.max(db.readAll or 0, db.read[id] or 0)
end

-- arrived after you last looked at this friend's history
function ns:SinceLastLook(ev)
  if ev.self then return false end
  return (ev.recv or ev.t or 0) > ns:LastLook(ev.id)
end

function ns:IsViewed(ev)
  return ev.uid ~= nil and ns.db.viewed[ev.uid] ~= nil
end

-- Hovered in the feed. Returns true the first time.
function ns:MarkViewed(ev)
  if not (ev and ev.uid and not ev.self) or ns.db.viewed[ev.uid] then return false end
  ns.db.viewed[ev.uid] = ns.Now()
  return true
end

function ns:IsSeen(ev)
  return ev.self or not ns:SinceLastLook(ev) or ns:IsViewed(ev)
end

-- forget hovers and likes of milestones that are no longer in the log
function ns:PruneViewed()
  local db = ns.db
  for _, t in ipairs({ db.viewed, db.likes, db.liked, db.heard }) do
    for uid in pairs(t) do
      if not db.seen[uid] then t[uid] = nil end
    end
  end
end

---------------------------------------------------------------------------
-- Likes: a heart on each friend's row. Clicking it sends the like to the
-- milestone's owner (straight away when they're online, otherwise when they
-- next come online). The owner's addon keeps who liked what, one like per
-- person (who sent it comes from the game's channel, never the message), and
-- sends the count to all their friends, so everyone sees the same number.
-- That only works while the owner is online and on 0.8.7 or later, so since
-- 0.9.5 a like also goes to all of the liker's own friends online ("F"):
-- friends who have the milestone too count it straight away, and an owner
-- the direct message couldn't reach still hears it.
---------------------------------------------------------------------------
ns.MAX_LIKES = 100000

-- Who a like is from, for telling people apart across channels: the same
-- friend can reach you by Battle.net and by the guild channel, under two
-- ids. Their first name and ruleset are the same on both (names are only
-- unique within a ruleset).
local function likerKey(from)
  local who = from and ns.Usable(from.who) and from.who:lower():match("^(%S+)")
  if not who then return from and from.id end
  return who .. "-" .. ns.Squash(from.rs or "?")
end

-- how many people liked it: your own from the list you keep, a friend's from
-- the count their addon sent, or the likes you heard about yourself when
-- that's more (the owner may be offline, or hasn't counted yours yet)
function ns:LikeCount(ev)
  if not ev then return 0 end
  if ev.self then
    local n = 0
    for _ in pairs(ns.db.likes[ev.uid or ""] or {}) do n = n + 1 end
    return n
  end
  local n = tonumber(ev.likes) or 0
  local heard = ns.db.heard[ev.uid or ""]
  if heard then
    local m = ns:Liked(ev) and 1 or 0
    for _ in pairs(heard) do m = m + 1 end
    if m > n then n = m end
  end
  return n
end

function ns:Liked(ev)
  return (ev and ev.uid and ns.db.liked[ev.uid] ~= nil) and true or false
end

-- who liked one of your milestones, newest first: { { n = label, t = time }, ... }
function ns:LikedBy(ev)
  local out = {}
  for _, l in pairs(ns.db.likes[ev and ev.uid or ""] or {}) do out[#out + 1] = l end
  table.sort(out, function(a, b) return (a.t or 0) > (b.t or 0) end)
  return out
end

-- a milestone by its owner (nil = yours) and t/k/v, newest first
function ns:FindEvent(id, t, k, v)
  local log = ns.db.log
  for i = #log, 1, -1 do
    local e = log[i]
    if e.t == t and e.k == k and e.v == v then
      if id == nil and e.self then return e end
      if id ~= nil and not e.self and e.id == id then return e end
    end
  end
  return nil
end

-- what a like is about, for "liked your [Shiny Sword]"
function ns:LikeWhat(ev)
  if ev.k == "death" then return "death" end
  if ev.k == "kill" then return "PvP kill" end
  local _, desc = ns:Describe(ev)
  for _, verb in ipairs({ "looted ", "reached ", "earned ", "got the mount ", "collected the pet ", "found the toy " }) do
    if desc:sub(1, #verb) == verb then return desc:sub(#verb + 1) end
  end
  return "milestone"
end

-- You click the heart on a friend's milestone. Returns true when it's now liked.
function ns:ToggleLike(ev)
  if not ev or ev.self or not ev.uid then return false end
  local on = not ns:Liked(ev)
  ns.db.liked[ev.uid] = on and ns.Now() or nil
  -- shown straight away; the owner's count replaces it when it arrives
  ev.likes = math.max(0, (tonumber(ev.likes) or 0) + (on and 1 or -1))
  if not ev.demo and ns.Sync and ns.Sync.SendLike then ns.Sync:SendLike(ev, on) end
  ns:Fire("LIKES_CHANGED", ev)
  return on
end

-- A friend liked (on) or unliked one of your milestones. Returns the
-- milestone when that changed something.
function ns:ReceiveLike(from, t, k, v, on)
  if not (from and from.id) then return nil end
  local ev = ns:FindEvent(nil, t, k, v)
  if not (ev and ev.uid) then return nil end
  local db = ns.db
  local list = db.likes[ev.uid]
  -- the same person by another channel (their like comes direct and to
  -- everyone) is still one like
  local key = likerKey(from)
  local have
  if list then
    if list[from.id] then have = from.id end
    for id, l in pairs(list) do
      if not have and key and l.w == key then have = id end
    end
  end
  if on then
    if have then return nil end
    if not list then list = {}; db.likes[ev.uid] = list end
    list[from.id] = { n = (ns.Label(from):gsub("|", "")), t = ns.Now(), w = key }
  else
    if not have then return nil end
    list[have] = nil
    if not next(list) then db.likes[ev.uid] = nil end
  end
  ns:Fire("LIKES_CHANGED", ev)
  if on then ns:Fire("LIKED", ev, from) end
  return ev
end

-- A friend told everyone they liked (or unliked) a milestone (0.9.5). It's
-- one of yours: counted like a direct like. Another friend's that you have
-- too: remembered, so your count goes up without waiting for its owner.
-- Returns the milestone when that changed something.
function ns:HearLike(from, who, rs, t, k, v, on)
  if not (from and from.id and usable(who)) then return nil end
  local id = ns.EventUID(who, rs, t, k, v)
  if not ns.db.seen[id] then return nil end
  local ev
  local log = ns.db.log
  for i = #log, 1, -1 do
    if log[i].uid == id then ev = log[i]; break end
  end
  if not ev then return nil end
  if ev.self then return ns:ReceiveLike(from, ev.t, ev.k, ev.v, on) end
  local key = likerKey(from)
  local heard = ns.db.heard
  local list = heard[id]
  if on then
    if list and list[key] then return nil end
    if not list then list = {}; heard[id] = list end
    list[key] = ns.Now()
  else
    if not (list and list[key]) then return nil end
    list[key] = nil
    if not next(list) then heard[id] = nil end
  end
  ns:Fire("LIKES_CHANGED", ev)
  return ev
end

-- A friend's addon says how many people liked their milestone. Found by
-- their id, or by their character's name when they reached you under
-- another id than the milestone came with (Battle.net vs the guild channel).
function ns:SetLikeCount(id, t, k, v, count, who, rs)
  count = tonumber(count)
  if not (id and count and count >= 0 and count <= ns.MAX_LIKES) then return nil end
  local ev = ns:FindEvent(id, t, k, v)
  if not ev and usable(who) then
    local log, name = ns.db.log, who:lower()
    for i = #log, 1, -1 do
      local e = log[i]
      if e.t == t and e.k == k and e.v == v and not e.self and type(e.who) == "string" and e.who:lower() == name
        and not (usable(rs) and e.rs and ns.Squash(e.rs) ~= ns.Squash(rs)) then
        ev = e; break
      end
    end
  end
  if not ev then return nil end
  count = math.floor(count)
  if ev.likes == count then return ev end
  ev.likes = count > 0 and count or nil
  ns:Fire("LIKES_CHANGED", ev)
  return ev
end

-- Guildmates who aren't friends, as heard on the guild channel (Sync.lua).
-- They get the Guild tab's alert settings instead of the Friends ones.
function ns:NoteGuildmate(id)
  if usable(id) and ns.db then ns.db.guildmates[id] = ns.Now() end
end

function ns:IsGuildmate(id)
  return id ~= nil and ns.db ~= nil and ns.db.guildmates[id] ~= nil
end

-- The notify settings that apply to one person: their custom ones, the
-- guild ones for a guildmate who isn't a friend, or yours. `guild` says the
-- event in hand came over the guild channel.
function ns:NotifyFor(id, guild)
  local s = ns.db.settings
  if id and s.perFriend[id] then return s.perFriend[id] end
  if guild or ns:IsGuildmate(id) then return s.guildNotify end
  return s.notify
end

function ns:HasCustomAlerts(id)
  return id ~= nil and ns.db.settings.perFriend[id] ~= nil
end

-- Give a friend their own alert settings (starting from yours), or remove them.
function ns:SetCustomAlerts(id, custom)
  local s = ns.db.settings
  if custom then
    if not s.perFriend[id] then
      local copy = {}
      for k, v in pairs(ns:NotifyFor(id)) do copy[k] = v end -- start from the guild or normal settings
      s.perFriend[id] = copy
    end
  else
    s.perFriend[id] = nil
  end
  if ns.UI then ns.UI:RequestRefresh() end
  return s.perFriend[id]
end

-- Does this event pass the player's "notify me about" filters and friend list?
function ns:Wants(ev)
  if not ev.self and ns:IsMuted(ev.id) then return false end
  local n = ev.self and ns.db.settings.notify or ns:NotifyFor(ev.id, ev.guild)
  local k = ev.k
  if k == "loot" then
    if (n.loot or 0) <= 0 then return false end
    local q = ev.q
    if not q and C_Item and C_Item.GetItemInfo and ev.v > 0 then q = select(3, C_Item.GetItemInfo(ev.v)) end
    return q == nil or q >= n.loot
  elseif k == "level" then
    local maxLevel = (GetMaxPlayerLevel and GetMaxPlayerLevel()) or 60
    if n.level == "all" then return true
    elseif n.level == "ten" then return ev.v % 10 == 0 or ev.v >= maxLevel
    elseif n.level == "max" then return ev.v >= maxLevel end
    return false
  end
  return n[k] ~= false
end

-- Everyone you might want alerts from: friends whose activity you've seen,
-- your Battle.net friends and your character friends. { id, label, sub }
-- Remember that friend `id` plays character `who` on ruleset `rs`.
local MAX_CHARS = 20
function ns:NoteCharacter(id, who, rs, t)
  if not (ns.db and usable(id) and usable(who)) then return end
  local all = ns.db.chars
  local list = all[id]
  if not list then list = {}; all[id] = list end
  local key = who:lower() .. "-" .. ns.Squash(rs or "")
  local seen = math.max(tonumber(t) or 0, list[key] and list[key].seen or 0)
  if not t then seen = ns.Now() end
  list[key] = { who = who, rs = rs, seen = seen }
  -- keep the most recent few
  local n, oldestKey, oldest = 0, nil, math.huge
  for k, c in pairs(list) do
    n = n + 1
    if c.seen < oldest then oldest, oldestKey = c.seen, k end
  end
  if n > MAX_CHARS and oldestKey then list[oldestKey] = nil end
end

-- A friend's characters, most recently seen first.
function ns:CharactersOf(id)
  local out = {}
  for _, c in pairs(ns.db.chars[id] or {}) do out[#out + 1] = c end
  table.sort(out, function(a, b) return (a.seen or 0) > (b.seen or 0) end)
  return out
end

function ns:KnownFriends()
  local by, list = {}, {}
  local function add(id, label, sub)
    if not usable(id) or by[id] or ns:IsRemoved(id) or ns.IsDemoID(id) then return end
    local f = { id = id, label = label, sub = sub }
    by[id] = f
    list[#list + 1] = f
  end
  local charFriends = {}
  if C_FriendList and C_FriendList.GetNumFriends then
    for i = 1, C_FriendList.GetNumFriends() do
      local info = C_FriendList.GetFriendInfoByIndex(i)
      if info and usable(info.name) then charFriends[ns.CharKey(info.name)] = true end
    end
  end
  -- guildmates who aren't friends belong to the Guild tab, not here
  local function guildOnly(id)
    return ns:IsGuildmate(id) and not charFriends[id] and not (ns.db.bnFriends or {})[id] and not (ns.db.following or {})[id]
  end
  -- from history, newest first, so each friend gets their latest character
  local log = ns.db.log
  for i = #log, 1, -1 do
    local e = log[i]
    if not e.self and not e.demo and not guildOnly(e.id) then
      local sub
      if e.id:find("#", 1, true) then sub = e.id
      elseif e.id:sub(1, 5) == "char:" then sub = "character friend" end
      add(e.id, ns.Label(e), sub)
    end
  end
  for id, name in pairs(ns.db.following or {}) do
    if by[id] then by[id].sub = "following" else add(id, name, "following") end
  end
  for tag in pairs(ns.db.bnFriends or {}) do
    add(tag, (tag:match("^(.-)#") or tag), tag)
  end
  if C_FriendList and C_FriendList.GetNumFriends then
    for i = 1, C_FriendList.GetNumFriends() do
      local info = C_FriendList.GetFriendInfoByIndex(i)
      if info and usable(info.name) then
        local name, realm = ns.SplitName(info.name)
        add(ns.CharKey(info.name), ns.Label({ who = name, rs = ns.Ruleset(realm) }), "character friend")
      end
    end
  end
  -- characters each friend has been seen on; Battle.net friends are labelled
  -- with the character they were last seen on (the BattleTag goes underneath)
  for _, f in ipairs(list) do
    f.chars = ns:CharactersOf(f.id)
    local latest = f.chars[1]
    if latest and f.id:find("#", 1, true) then
      f.label = ns.Label({ who = latest.who, rs = latest.rs })
      f.sub = f.id
    end
  end
  local function plain(s) return (s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):lower()) end
  table.sort(list, function(a, b) return plain(a.label) < plain(b.label) end)
  return list
end

-- Guildmates who aren't friends, labelled with their latest character (Guild tab).
function ns:KnownGuildmates()
  local list = {}
  for id in pairs(ns.db.guildmates or {}) do
    if not (ns:IsRemoved(id) or ns.IsDemoID(id)) then
      local chars = ns:CharactersOf(id)
      local latest = chars[1]
      local label = latest and ns.Label({ who = latest.who, rs = latest.rs }) or (id:gsub("^char:", ""))
      list[#list + 1] = { id = id, label = label, sub = "guild", chars = chars }
    end
  end
  local function plain(s) return (s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):lower()) end
  table.sort(list, function(a, b) return plain(a.label) < plain(b.label) end)
  return list
end

function ns:IsMuted(id)
  return id ~= nil and ns.db.settings.muted[id] == true
end

function ns:SetMuted(id, muted)
  ns.db.settings.muted[id] = muted and true or nil
  if ns.UI then ns.UI:RequestRefresh() end
end

---------------------------------------------------------------------------
-- Removing people: stop tracking someone altogether (Friends or Guild tab,
-- the X on their row). Their saved milestones are deleted, anything new from
-- them is ignored, and they leave the lists. "Removed" on the same tab lists
-- them with an Add back button. Sharing your own milestones isn't affected.
---------------------------------------------------------------------------
local function plainText(s)
  return (tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

function ns:IsRemoved(id)
  return id ~= nil and ns.db ~= nil and ns.db.settings.removed[id] ~= nil
end

function ns:RemoveFriend(id, label, guild)
  if not usable(id) then return false end
  local db = ns.db
  db.settings.removed[id] = { label = plainText(label or id), t = ns.Now(), guild = guild and true or nil }
  local keep = {}
  for _, e in ipairs(db.log) do
    if e.id == id and not e.self then
      if e.uid then db.seen[e.uid] = nil end
    else
      keep[#keep + 1] = e
    end
  end
  db.log = keep
  db.read[id] = nil
  if ns.UI then ns.UI:RequestRefresh() end
  return true
end

function ns:RestoreFriend(id)
  local r = ns.db.settings.removed[id]
  if not r then return false end
  ns.db.settings.removed[id] = nil
  if ns.UI then ns.UI:RequestRefresh() end
  return true
end

-- The people you removed, newest first. guild: true for the Guild tab's, false for the Friends tab's
function ns:RemovedPeople(guild)
  local list = {}
  for id, r in pairs(ns.db.settings.removed) do
    if type(r) == "table" and (r.guild == true) == (guild == true) then
      list[#list + 1] = { id = id, label = r.label or id, t = r.t or 0 }
    end
  end
  table.sort(list, function(a, b) return a.t > b.t end)
  return list
end

function ns:DeleteAll()
  local db = self.db
  wipe(db.log); wipe(db.seen); wipe(db.outbox); wipe(db.read); wipe(db.viewed)
  wipe(db.likes); wipe(db.liked); wipe(db.likeOut); wipe(db.heard)
  db.readAll, db.feedClearedAt = 0, 0
  if ns.UI then ns.UI:RequestRefresh() end
  ns.Print("All saved history deleted.")
end

function ns:MarkRead(id)
  if id then self.db.read[id] = ns.Now() else self.db.readAll = ns.Now() end
end

-- s = where it came from, e.g. "Baron Rivendare, Stratholme" (see Tracker.lua)
-- d = total deaths, for a death
function ns:RecordSelf(k, v, q, n, s, d)
  local ev = {
    id = ns.SelfID(), who = ns.PlayerName(), rs = ns.MyRuleset(),
    t = ns.Now(), k = k, v = v, q = q, n = n, s = s, d = d, self = true,
  }
  if not ns:AddEvent(ev, "self") then return end
  local out = ns.db.outbox
  out[#out + 1] = { id = ev.id, who = ev.who, rs = ev.rs, t = ev.t, k = k, v = ev.v, q = q, n = n, s = ev.s, d = ev.d }
  while #out > 500 do table.remove(out, 1) end
  if ns.Sync then ns.Sync:Broadcast(ev) end
end

-- A death's counter, "Total deaths: 37": the game's own Total deaths
-- statistic, read by the player's addon when they died and sent with the
-- death (ev.d). Nothing when it didn't come (an older version, the app, or a
-- client without the statistic): only the game's number is ever shown.
-- Kills work the same way (v0.9.1): the game's lifetime honorable kills,
-- read when the kill was recorded, so battleground kills are in it too.
-- Returns the text and its colour (hex).
function ns:TotalText(ev)
  if not (ev and ev.d) then return nil end
  if ev.k == "death" then return "Total deaths: " .. ev.d, "ff6060" end
  if ev.k == "kill" then return "Total honorable kills: " .. ev.d, "ff9050" end
  return nil
end
-- deaths only, as before (tests and older callers)
function ns:DeathCountText(ev)
  if not (ev and ev.k == "death") then return nil end
  return (ns:TotalText(ev))
end

---------------------------------------------------------------------------
-- Display text and icons for an event
---------------------------------------------------------------------------
local ICONS = {
  loot  = "Interface\\Icons\\INV_Misc_QuestionMark",
  level = "Interface\\Icons\\Spell_Holy_SurgeOfLight",
  ach   = "Interface\\Icons\\Achievement_General",
  mount = "Interface\\Icons\\Ability_Mount_RidingHorse",
  pet   = "Interface\\Icons\\INV_Box_PetCarrier_01",
  toy   = "Interface\\Icons\\INV_Misc_Toy_10",
  death = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_01",
  kill  = "Interface\\Icons\\Ability_DualWield",
}
ns.ICONS = ICONS

-- Journal "source" text comes with colour codes and line breaks:
-- "|cFFFFFFFFDrop:|r Baron Rivendare|n|cFFFFFFFFZone:|r Stratholme"
-- -> "Drop: Baron Rivendare, Stratholme"
function ns.CleanJournalText(s)
  if not usable(s) then return nil end
  s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|n", ", "):gsub("\n", ", ")
  s = s:gsub("|", ""):gsub("Zone: ", ""):gsub("%s+", " "):gsub(",%s*,", ","):match("^[%s,]*(.-)[%s,]*$")
  if s == "" then return nil end
  return s:sub(1, ns.MAX_SUB)
end

-- Where it came from, as raw text. The sender's own note (ev.s) wins;
-- otherwise the mount and pet journals and the achievement description fill
-- it in on this side, since that data is the same for everyone.
function ns:SourceText(ev)
  if usable(ev.s) then return ev.s end
  local k, v = ev.k, ev.v
  if not (v and v > 0) then return nil end
  if k == "mount" and C_MountJournal and C_MountJournal.GetMountInfoExtraByID then
    local ok, _, _, source = pcall(C_MountJournal.GetMountInfoExtraByID, v)
    if ok then return ns.CleanJournalText(source) end
  elseif k == "pet" and C_PetJournal and C_PetJournal.GetPetInfoBySpeciesID then
    local ok, _, _, _, _, source = pcall(C_PetJournal.GetPetInfoBySpeciesID, v)
    if ok then return ns.CleanJournalText(source) end
  elseif k == "ach" and GetAchievementInfo then
    local ok, _, _, _, _, _, _, _, desc = pcall(GetAchievementInfo, v)
    if ok then return ns.CleanJournalText(desc) end
  end
  return nil
end

-- How an item was got, as a short coloured tag in front of the source line.
-- The game has no drop chances for addons, so this is the next best thing:
-- the sender's tracker writes "Boss drop: " or "Rare mob: " in front of ev.s
-- (Tracker.lua), quest rewards already start "Quest: ", and quest items are
-- recognised here from the item itself. Older versions just show the text.
local SOURCE_TAGS = {
  { prefix = "Boss drop: ", tag = "Boss drop", color = "ff8000" },
  { prefix = "Rare mob: ", tag = "Rare mob", color = "c0c0ff" },
  { prefix = "Quest: ", tag = "Quest reward", color = "ffd200" },
}
ns.SOURCE_TAGS = SOURCE_TAGS

-- A quest item (item class 12), or one bound to a quest (bind type 4)
function ns.IsQuestItem(id)
  id = tonumber(id)
  if not (id and id > 0 and C_Item) then return false end
  if C_Item.GetItemInfoInstant then
    local ok, _, _, _, _, _, classID = pcall(C_Item.GetItemInfoInstant, id)
    if ok and classID == 12 then return true end
  end
  if C_Item.GetItemInfo then
    local r = { pcall(C_Item.GetItemInfo, id) }
    if r[1] and r[15] == 4 then return true end -- bindType, the 14th return
  end
  return false
end

-- tag ("Boss drop"), its colour (hex), and the rest ("Baron Rivendare, Stratholme")
function ns:SourceParts(ev)
  local s = ns:SourceText(ev)
  local tag, color
  if s then
    for _, t in ipairs(SOURCE_TAGS) do
      if s:sub(1, #t.prefix) == t.prefix then
        tag, color, s = t.tag, t.color, s:sub(#t.prefix + 1)
        break
      end
    end
    if s == "" then s = nil end
  end
  if not tag and ev.k == "loot" and ns.IsQuestItem(ev.v) then tag, color = "Quest item", "ffd200" end
  return tag, color, s
end

-- The grey line under an event: the tag in colour, then where it came from
-- (deaths and kills add their counter at the end: "Killed by Gahz'rilla · Total deaths: 41")
function ns:Subtext(ev)
  local tag, color, rest = ns:SourceParts(ev)
  local line = rest
  if tag then line = "|cff" .. color .. tag .. "|r" .. (rest and (" \194\183 " .. rest) or "") end
  local total, hex = ns:TotalText(ev)
  if total then
    total = "|cff" .. hex .. total .. "|r"
    line = line and (line .. " \194\183 " .. total) or total
  end
  return line
end

-- How many other people in your history got the same thing, and whether
-- this one was the first. Only for things worth comparing (gear, mounts...).
function ns:HowMany(ev)
  if not (ev and (tonumber(ev.v) or 0) > 0) or ev.k == "level" or ev.k == "death" or ev.k == "kill" then return nil end
  local others, first = {}, true
  for _, e in ipairs(ns.db.log) do
    if e.k == ev.k and e.v == ev.v and e.id ~= ev.id and not e.demo == not ev.demo then
      others[e.id] = true
      if (e.t or 0) < (ev.t or 0) then first = false end
    end
  end
  local n = 0
  for _ in pairs(others) do n = n + 1 end
  return n, first
end

-- icon, text ("looted [Thunderfury]"), quality (for colours), subtext (where from)
function ns:Describe(ev)
  local k, v = ev.k, ev.v
  local sub = ns:Subtext(ev)
  if k == "loot" then
    local name, link, quality, icon
    if v > 0 and C_Item and C_Item.GetItemInfo then
      local r1, r2, r3, _, _, _, _, _, _, r10 = C_Item.GetItemInfo(v)
      name, link, quality, icon = r1, r2, r3, r10
      if not name and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(v) end
      icon = icon or (C_Item.GetItemIconByID and C_Item.GetItemIconByID(v))
    end
    local q = quality or ev.q
    local label = link or (ns.QualityHex(q) .. "[" .. (ev.n or "an item") .. "]|r")
    return icon or ICONS.loot, "looted " .. label, q, sub
  elseif k == "level" then
    return ICONS.level, "reached |cffffd200level " .. v .. "|r", (v >= 60) and 4 or nil, sub
  elseif k == "ach" then
    local name, icon
    if GetAchievementInfo and v > 0 then
      local ok, _, n, _, _, _, _, _, _, _, ic = pcall(GetAchievementInfo, v)
      if ok then name, icon = n, ic end
    end
    return icon or ICONS.ach, "earned |cffffff00[" .. (name or ev.n or "an achievement") .. "]|r", 4, sub
  elseif k == "mount" then
    local name, icon
    if v > 0 and C_MountJournal and C_MountJournal.GetMountInfoByID then
      local n, _, ic = C_MountJournal.GetMountInfoByID(v)
      name, icon = n, ic
    end
    return icon or ICONS.mount, "got the mount |cffa335ee" .. (name or ev.n or "a new mount") .. "|r", 4, sub
  elseif k == "pet" then
    local icon
    if v > 0 and C_PetJournal and C_PetJournal.GetPetInfoBySpeciesID then
      local _, ic = C_PetJournal.GetPetInfoBySpeciesID(v)
      icon = ic
    end
    return icon or ICONS.pet, "collected the pet |cff1eff00" .. (ev.n or "a new pet") .. "|r", 2, sub
  elseif k == "toy" then
    local name, icon
    if v > 0 and C_ToyBox and C_ToyBox.GetToyInfo then
      local _, n, ic = C_ToyBox.GetToyInfo(v)
      name, icon = n, ic
    end
    return icon or ICONS.toy, "found the toy |cff0070dd" .. (name or ev.n or "a new toy") .. "|r", 3, sub
  elseif k == "death" then
    local text = "|cffff4040died|r"
    if v > 0 then text = text .. " at level " .. v end
    if ev.n then text = text .. " in " .. ev.n end
    return ICONS.death, text, nil, sub
  elseif k == "kill" then
    -- v = how many players, n = who (when the game said who died)
    local count = math.max(1, v)
    local who = count == 1 and (ev.n or "an enemy player") or (count .. " players")
    local text = "killed |cffff8040" .. who .. "|r"
    if count > 1 and ev.n then text = text .. ": " .. ev.n end
    return ICONS.kill, text .. " in world PvP", nil, sub
  end
  return ICONS.loot, "did something cool", nil, sub
end

---------------------------------------------------------------------------
-- Companion app inbox (Inbox.lua)
---------------------------------------------------------------------------
function ns:IngestInbox()
  local inbox = FriendFeedInbox
  if type(inbox) ~= "table" then return 0 end
  -- the newest addon version the app has seen (app 0.3.4+); told at login, like one heard from a friend
  if type(inbox.addonLatest) == "string" then ns:RememberVersion(inbox.addonLatest) end
  -- people you follow (read first, so their events are labelled with their public name)
  if type(inbox.following) == "table" then
    local following = {}
    for _, f in ipairs(inbox.following) do
      if type(f) == "table" and type(f.id) == "string" and f.id:match("^pub:[%w_]+$")
        and type(f.name) == "string" and f.name:match("^[%w_]+$") then
        following[f.id] = f.name
      end
    end
    ns.db.following = following
  end
  local myID, myName, myRs, added = ns.SelfID(), ns.PlayerName(), ns.MyRuleset(), 0
  for _, e in ipairs(type(inbox.events) == "table" and inbox.events or {}) do
    if type(e) == "table" and usable(e.who) then
      local rs = usable(e.rs) and e.rs or nil
      local mine = (e.id == myID) or (e.who == myName and (rs == nil or rs == myRs))
      if not mine and ns:AddEvent({
        id = e.id, who = e.who, rs = rs, t = e.t, k = e.k, v = e.v, q = e.q, n = e.n, s = e.s,
      }, "inbox") then
        added = added + 1
      end
    end
  end
  -- drop outbox events the server has (ackedUntil) or would refuse as too old
  -- (it only keeps 60 days), so they aren't uploaded again forever
  local acked = tonumber(inbox.ackedUntil) or 0
  local tooOld = ns.Now() - 59 * 86400
  local keep = {}
  for _, e in ipairs(ns.db.outbox) do
    local t = e.t or 0
    if t > acked and t > tooOld then keep[#keep + 1] = e end
  end
  ns.db.outbox = keep
  return added
end

---------------------------------------------------------------------------
-- Demo data so you can see the UI without friends running the addon
---------------------------------------------------------------------------
-- The demo is a short preview: its pretend friends live only for this session,
-- go away by themselves after DEMO_SECONDS, and are wiped before the game saves
-- (and on load, for demos saved by older versions), so they never end up in
-- your saved data, the Friends tab or the companion app.
local DEMO_SECONDS = 180
ns.DEMO_SECONDS = DEMO_SECONDS

function ns.IsDemoID(id) return type(id) == "string" and id:sub(1, 5) == "demo:" end

function ns:ClearDemo()
  local db = self.db
  if not db then return end
  local keep = {}
  for _, e in ipairs(db.log) do
    if e.demo or ns.IsDemoID(e.id) then db.seen[e.uid or ""] = nil else keep[#keep + 1] = e end
  end
  db.log = keep
  local s = db.settings
  for _, t in ipairs({ db.read, db.chars, db.guildmates, s.muted, s.perFriend, s.removed }) do
    for id in pairs(t) do
      if ns.IsDemoID(id) then t[id] = nil end
    end
  end
  ns.demoUntil = nil
  ns.demoGen = (ns.demoGen or 0) + 1 -- live demo events still waiting won't arrive
  ns:PruneViewed()
  if ns.UI then
    if ns.UI.ClearDemo then ns.UI:ClearDemo() end
    ns.UI:RequestRefresh()
  end
end

function ns:IsDemoRunning() return ns.demoUntil ~= nil end

-- the demo ends by itself
C_Timer.NewTicker(5, function()
  if ns.demoUntil and GetTime() >= ns.demoUntil then
    ns:ClearDemo()
    ns.Print("The demo has ended and its pretend friends are gone. Type |cffffd200/ff demo|r to see it again.")
  end
end)

function ns:Demo()
  self:ClearDemo()
  ns.demoUntil = GetTime() + DEMO_SECONDS
  local gen = ns.demoGen
  local now = ns.Now()
  -- two different friends both called Grommash, on different rulesets
  local thrall = { id = "demo:Thrallina#1111", who = "Thrallina Stormcaller", rs = "Normal" }
  local grom1  = { id = "demo:Grom#2222", who = "Grommash Ironhide", rs = "RP-PvP" }
  local grom2  = { id = "demo:Hellscream#3333", who = "Grommash Ashborn", rs = "Normal" }
  local jaina  = { id = "demo:Jaina#4444", who = "Jaina Brightwater", rs = "RP" }
  local varian = { id = "demo:Varian#5555", who = "Varian Holt", rs = "PvP" }
  local function as(p, e) e.id, e.who, e.rs = p.id, p.who, p.rs; return e end

  local past = {
    as(thrall, { t = now - 3600 * 20, k = "level", v = 60, s = "Eastern Plaguelands" }),
    as(grom1,  { t = now - 3600 * 9,  k = "loot",  v = 19019, q = 5, n = "Thunderfury, Blessed Blade of the Windseeker", s = "Quest: Rise, Thunderfury!" }),
    as(thrall, { t = now - 3600 * 5,  k = "mount", v = 0, n = "Deathcharger", s = "Baron Rivendare, Stratholme" }),
    as(grom2,  { t = now - 3600 * 3,  k = "level", v = 40, s = "Stranglethorn Vale" }),
    as(varian, { t = now - 3600 * 2.5, k = "death", v = 38, n = "Stranglethorn Vale", s = "Killed by Zanzil the Outcast", d = 12 }),
    as(grom1,  { t = now - 3600 * 2.2, k = "kill", v = 3, n = "Anduin Vale, Tess Holt, Brann Stone", s = "Tarren Mill", d = 214 }),
    as(jaina,  { t = now - 3600 * 2,  k = "ach",   v = 0, n = "Molten Core", s = "Defeat the bosses in Molten Core" }),
    as(grom1,  { t = now - 1800,      k = "loot",  v = 18803, q = 4, n = "Finkle's Lava Dredger", s = "Majordomo Executus, Molten Core" }),
  }
  for _, e in ipairs(past) do e.demo = true; self:AddEvent(e, "catchup") end

  local live = {
    as(jaina,  { k = "loot",  v = 17182, q = 5, n = "Sulfuras, Hand of Ragnaros", s = "Crafted" }),
    as(varian, { k = "mount", v = 0, n = "Swift Razzashi Raptor", s = "Bloodlord Mandokir, Zul'Gurub" }),
    as(grom2,  { k = "ach",   v = 0, n = "Onyxia's Lair", s = "Defeat Onyxia" }),
  }
  for i, e in ipairs(live) do
    C_Timer.After(4 + i * 2.5, function()
      if ns.demoGen ~= gen then return end -- the demo was cleared meanwhile
      e.demo = true
      e.t = ns.Now()
      self:AddEvent(e, "demo")
    end)
  end
  ns.Print("Demo loaded. It clears itself in " .. math.floor(DEMO_SECONDS / 60)
    .. " minutes and is never saved. Type |cffffd200/ff cleardemo|r to end it now.")
end

---------------------------------------------------------------------------
-- Lifecycle
---------------------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("PLAYER_LOGOUT")
-- "FriendFeed has been blocked from an action only available to the Blizzard UI":
-- remember which function it was and where it was called from, for /ff blocked
f:RegisterEvent("ADDON_ACTION_FORBIDDEN")
f:RegisterEvent("ADDON_ACTION_BLOCKED")
local reported = {}
f:SetScript("OnEvent", function(_, event, a1, a2)
  if event == "ADDON_LOADED" and a1 == ADDON then
    FriendFeedDB = FriendFeedDB or {}
    applyDefaults(FriendFeedDB, defaults)
    ns.db = FriendFeedDB
    -- events saved before v0.4 have no friend id; fall back to the name
    for _, e in ipairs(ns.db.log) do
      if type(e) == "table" and not e.id then e.id = e.who end
    end
    -- v0.5 replaced the sound on/off switch with a volume
    local st = ns.db.settings
    if st.sound == false then st.soundVolume = 0 end
    st.sound = nil
    st.soundVolume = math.max(0, math.min(300, tonumber(st.soundVolume) or 100))
    -- v0.7.15 shares everything by default (green+ gear, guild on). Installs
    -- still on the old defaults (blue+, guild off) move over once; anything
    -- else was someone's own choice and stays.
    if (tonumber(st.shareDefaults) or 0) < 2 then
      if st.minQuality == 3 then st.minQuality = 2 end
      if st.includeGuild == false then st.includeGuild = true end
      st.shareDefaults = 2
    end
    -- gear is always shared from green up since v0.8.7 (the user's call: the
    -- quality choice is gone from settings)
    st.minQuality = 2
    -- 0.8.9 shows your own milestones by default (likes on them were
    -- invisible otherwise); everyone moves over once, then it's their choice
    if (tonumber(st.selfDefaults) or 0) < 1 then
      st.showSelf = true
      st.selfDefaults = 1
    end
    -- 0.8.0 saved the pop-up spot from GetPoint, which could be relative to
    -- the feed and so land somewhere else; those go back to under the feed once
    -- (2 = from the bottom-left, 0.8.1; 3 = from the nearest corner, 0.9.3)
    if st.toastPoint and st.toastPointV ~= 2 and st.toastPointV ~= 3 then st.toastPoint = nil end
    -- demo friends saved by versions before 0.8 (they're session-only now)
    ns:ClearDemo()
    ns:PruneViewed()
    ns:Fire("DB_READY")
  elseif event == "PLAYER_ENTERING_WORLD" then
    if ns.entered then return end
    ns.entered = true
    local isInitialLogin = a1
    -- PLAYER_LOGOUT also fires on /reload, so remember the real logout time per session
    if isInitialLogin or (ns.db.sessionPrevLogout or 0) == 0 then
      ns.db.sessionPrevLogout = ns.db.lastLogout or 0
    end
    ns.prevLogout = ns.db.sessionPrevLogout
    local tag = ns.SelfID()
    ns.db.me = {
      battleTag = (tag:sub(1, 5) ~= "char:") and tag or nil,
      name = ns.PlayerName(), ruleset = ns.MyRuleset(), addonVersion = ns.VERSION,
    }
    ns:IngestInbox()
    ns:Fire("LOGIN", isInitialLogin)
  elseif event == "PLAYER_LOGOUT" then
    if ns.db then
      ns.db.lastLogout = ns.Now()
      ns:ClearDemo() -- never saved
    end
  elseif event == "ADDON_ACTION_FORBIDDEN" or event == "ADDON_ACTION_BLOCKED" then
    if a1 ~= ADDON then return end
    local func = tostring(a2)
    local rec = {
      t = ns.Now(), version = ns.VERSION, func = func,
      kind = (event == "ADDON_ACTION_FORBIDDEN") and "forbidden" or "blocked",
      during = ns.registering, -- the game event being registered for, if that's what was refused
      stack = (debugstack and debugstack(2, 15, 3)) or "(no stack available)",
    }
    if ns.db then
      ns.db.blocked = ns.db.blocked or {}
      table.insert(ns.db.blocked, rec)
      while #ns.db.blocked > 10 do table.remove(ns.db.blocked, 1) end
      -- a refused event registration is remembered and never tried again
      if rec.during then
        ns.db.forbidden = ns.db.forbidden or {}
        ns.db.forbidden[rec.during] = true
      end
    end
    local what = rec.during and ("registering for the game event |cffff8040" .. rec.during .. "|r")
      or ("a call to |cffff8040" .. func .. "|r")
    if not reported[what] then
      reported[what] = true
      ns.Print("The game " .. rec.kind .. " " .. what .. ". Type |cffffd200/ff blocked|r to see the details and send them to the addon author."
        .. (rec.during and " Friend Feed won't ask for that event again." or ""))
    end
  end
end)

-- /ff blocked: the forbidden or blocked calls the game reported, newest last
function ns:PrintBlocked()
  local list = ns.db and ns.db.blocked or {}
  if #list == 0 then
    ns.Print("The game hasn't blocked anything from Friend Feed.")
    return
  end
  ns.Print("Calls the game blocked (send this to the addon author):")
  for _, rec in ipairs(list) do
    print("  v" .. tostring(rec.version) .. "  " .. tostring(rec.kind) .. "  |cffff8040" .. tostring(rec.func) .. "|r  "
      .. (rec.during and ("while registering for |cffff8040" .. rec.during .. "|r  ") or "")
      .. (date and pcall(date, "%d %b %H:%M", rec.t) and date("%d %b %H:%M", rec.t) or tostring(rec.t)))
    for line in tostring(rec.stack):gmatch("[^\n]+") do print("    " .. line) end
  end
  local skipped = {}
  for event in pairs(ns.db.forbidden or {}) do skipped[#skipped + 1] = event end
  table.sort(skipped)
  if #skipped > 0 then ns.Print("Game events Friend Feed no longer asks for: " .. table.concat(skipped, ", ")) end
end

---------------------------------------------------------------------------
-- /ff names: how does the game report first and last names?
---------------------------------------------------------------------------
local function show(label, ...)
  local parts = {}
  for i = 1, select("#", ...) do
    local v = select(i, ...)
    if ns.IsSecret(v) then v = "(hidden)" end
    parts[#parts + 1] = v == nil and "nil" or ('"' .. tostring(v) .. '"')
  end
  print("  " .. label .. ": " .. table.concat(parts, ", "))
end

local function try(label, fn, ...)
  if type(fn) ~= "function" then print("  " .. label .. ": |cff888888not in this client|r"); return end
  local res = { pcall(fn, ...) }
  if not res[1] then print("  " .. label .. ": |cffff4040error|r"); return end
  show(label, select(2, (unpack or table.unpack)(res)))
end

function ns:PrintNames()
  ns.Print("How the game reports names (send this to the addon author):")
  try("UnitName", UnitName, "player")
  try("UnitFullName", UnitFullName, "player")
  try("GetUnitName", GetUnitName, "player", true)
  try("UnitPVPName", UnitPVPName, "player")
  try("UnitNameUnmodified", UnitNameUnmodified, "player")
  if UnitExists and UnitExists("target") and UnitIsPlayer and UnitIsPlayer("target") then
    try("Target UnitName", UnitName, "target")
    try("Target UnitFullName", UnitFullName, "target")
  else
    print("  |cff888888(target another player and run this again to see their name too)|r")
  end
  show("Name Friend Feed uses for you", ns.PlayerName())
  try("GetRealmName", GetRealmName)
  try("GetNormalizedRealmName", GetNormalizedRealmName)
  show("Last addon message came from", ns.Sync and ns.Sync.lastSender)
  -- how friends' names come through (these are what the addon reads)
  local shown = 0
  if BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo then
    for i = 1, (BNGetNumFriends()) do
      local acc = C_BattleNet.GetFriendAccountInfo(i)
      local g = acc and acc.gameAccountInfo
      if g and g.isOnline and ns.Usable(g.characterName) and shown < 5 then
        shown = shown + 1
        show("Battle.net friend " .. shown .. " characterName / realmName / realmDisplayName",
          g.characterName, g.realmName, g.realmDisplayName)
      end
    end
  end
  if shown == 0 then print("  |cff888888(no Battle.net friends online in a game right now)|r") end
  local cf = 0
  if C_FriendList and C_FriendList.GetNumFriends then
    for i = 1, C_FriendList.GetNumFriends() do
      local info = C_FriendList.GetFriendInfoByIndex(i)
      if info and info.name and cf < 5 then
        cf = cf + 1
        show("Character friend " .. cf .. " name", info.name)
      end
    end
  end
  if cf == 0 then print("  |cff888888(no character friends)|r") end
  -- look for any game function that mentions a surname or last name
  local found = {}
  local function scan(tbl, prefix)
    for k, v in pairs(tbl) do
      if type(k) == "string" then
        local lk = k:lower()
        if lk:find("surname") or lk:find("lastname") or lk:find("familyname") then
          found[#found + 1] = prefix .. k .. " (" .. type(v) .. ")"
        end
      end
    end
  end
  scan(_G, "")
  for k, v in pairs(_G) do
    if type(k) == "string" and k:sub(1, 2) == "C_" and type(v) == "table" then scan(v, k .. ".") end
  end
  table.sort(found)
  if #found == 0 then
    print("  No surname functions found.")
  else
    print("  Surname-related names in the game: " .. table.concat(found, ", ", 1, math.min(#found, 25)))
  end
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------
local function onOff(v) return v and "|cff00ff00on|r" or "|cffff4040off|r" end

SLASH_FRIENDFEED1 = "/ff"
SLASH_FRIENDFEED2 = "/friendfeed"
SlashCmdList.FRIENDFEED = function(msg)
  local cmd, arg = (msg or ""):lower():match("^%s*(%S*)%s*(.-)%s*$")
  local s = ns.db.settings
  if cmd == "" then
    ns.UI:ToggleFeed()
  elseif cmd == "details" or cmd == "d" then
    ns.UI:ToggleDetails()
  elseif cmd == "settings" or cmd == "options" or cmd == "config" then
    ns.Settings:Open(false)
  elseif cmd == "setup" then
    ns.Settings:Open(true)
  elseif cmd == "demo" then
    ns:Demo()
  elseif cmd == "cleardemo" then
    ns:ClearDemo(); ns.Print("Demo entries removed.")
  elseif cmd == "lock" then
    s.locked = not s.locked; ns.UI:ApplyLock(); ns.Print("Feed size and position locked:", onOff(s.locked))
  elseif cmd == "toasts" then
    s.toasts = not s.toasts; ns.Print("Pop-up toasts:", onOff(s.toasts))
  elseif cmd == "popups" or cmd == "move" then
    ns.UI:MoveToasts()
  elseif cmd == "minimap" then
    s.minimap.hide = not s.minimap.hide
    ns.UI:ApplyMinimapButton()
    ns.Print("Minimap button:", onOff(not s.minimap.hide))
    if ns.Settings and ns.Settings.Refresh then ns.Settings:Refresh() end
  elseif cmd == "sound" then
    local pct = tonumber((arg or ""):match("^(%d+)%%?$"))
    if pct then
      s.soundVolume = math.max(0, math.min(300, math.floor(pct / 10 + 0.5) * 10))
    elseif (s.soundVolume or 0) > 0 then
      s.lastSoundVolume, s.soundVolume = s.soundVolume, 0
    else
      s.soundVolume = (s.lastSoundVolume or 0) > 0 and s.lastSoundVolume or 100
    end
    if s.soundVolume > 0 then s.lastSoundVolume = s.soundVolume end
    ns.Print("Sound volume:", s.soundVolume > 0 and ("|cff00ff00" .. s.soundVolume .. "%|r") or onOff(false))
    if ns.Settings and ns.Settings.Refresh then ns.Settings:Refresh() end
  elseif cmd == "self" then
    s.showSelf = not s.showSelf; ns.Print("Show your own milestones:", onOff(s.showSelf)); ns.UI:RequestRefresh()
  elseif cmd == "guild" then
    s.includeGuild = not s.includeGuild; ns.Print("Share with guild too:", onOff(s.includeGuild))
  elseif cmd == "whoami" then
    local realm = ns.MyRealm()
    ns.Print("You are " .. ns.Label({ who = ns.PlayerName(), rs = ns.MyRuleset() }, true))
    print("  id: " .. ns.SelfID())
    print("  realm: \"" .. tostring(realm) .. "\"  (squashed: " .. ns.Squash(realm) .. ")")
    print("  normalized realm: " .. tostring(GetNormalizedRealmName and GetNormalizedRealmName()))
  elseif cmd == "friends" then
    ns.Sync:PrintTargets()
  elseif cmd == "names" then
    ns:PrintNames()
  elseif cmd == "blocked" then
    ns:PrintBlocked()
  elseif cmd == "pvp" then
    if ns.PrintPvP then ns.PrintPvP() end
  elseif cmd == "ping" then
    ns.Sync:Ping()
  elseif cmd == "clear" then
    ns.UI:ClearFeed()
  elseif cmd == "reset" then
    if arg == "confirm" then
      ns:DeleteAll()
    else
      ns.Print("This deletes all saved history. Type |cffffd200/ff reset confirm|r to do it.")
    end
  else
    ns.Print("v" .. ns.VERSION .. " commands:")
    print("  /ff - show the feed, or minimise it to the minimap button")
    print("  /ff details - open the friend history window")
    print("  /ff settings - choose what you get notified about")
    print("  /ff setup - run the first-time setup again")
    print("  /ff demo, /ff cleardemo - preview with fake friends")
    print("  /ff ping - check which online friends have Friend Feed working")
    print("  /ff lock - lock the feed's size and position")
    print("  /ff toasts - turn pop-ups on or off")
    print("  /ff popups - move where pop-ups appear")
    print("  /ff minimap - show or hide the minimap button")
    print("  /ff sound - mute or unmute sounds, /ff sound 150 - set the volume (0 to 300%)")
    print("  /ff self - show or hide your own milestones in the feed")
    print("  /ff guild - also share with your guild")
    print("  /ff clear - clear the feed (history is kept)")
    print("  /ff reset - delete all saved history")
    print("  /ff whoami, /ff friends - show how you and your online friends are identified")
    print("  /ff names - show how the game reports first and last names")
    print("  /ff blocked - show which call the game blocked, if it warned you about Friend Feed")
    print("  /ff pvp - check what the game tells Friend Feed about your PvP kills")
  end
end
