-- Friend Feed: accolades (0.9.17). Friend Feed's own achievements, earned per
-- character from numbers the game keeps (honorable kills, duels won, total
-- deaths, mounts) or Friend Feed counts (kill streaks). Crossing a tier
-- is a milestone of kind "acc" (n = accolade id, q = tier, v = the tier's
-- number, s = "500 honorable kills"), shared like any other. Each character's
-- accolades also go out as one short "B" message, so friends can show the
-- best one next to the name and list them all.
local ADDON, ns = ...
local usable = ns.Usable

-- Tiers are prestige levels, each with its colour (0.9.18, user: bronze,
-- silver, gold, emerald, diamond). An accolade's icon is drawn in its tier's
-- colour wherever it shows.
ns.TIERS = {
  { name = "I",   label = "Bronze",  hex = "cd7f32", rgb = { 0.80, 0.50, 0.20 } },
  { name = "II",  label = "Silver",  hex = "c7c7d1", rgb = { 0.78, 0.78, 0.82 } },
  { name = "III", label = "Gold",    hex = "ffd100", rgb = { 1.00, 0.82, 0.00 } },
  { name = "IV",  label = "Emerald", hex = "2fd97a", rgb = { 0.18, 0.85, 0.48 } },
  { name = "V",   label = "Diamond", hex = "b9f2ff", rgb = { 0.73, 0.95, 1.00 } },
}
ns.BLANK = "Interface\\AddOns\\FriendFeed\\Media\\Blank" -- a transparent texture (Media/Blank.tga)

function ns.Commas(n)
  local s = tostring(math.floor(tonumber(n) or 0))
  local out = s:reverse():gsub("(%d%d%d)", "%1,"):reverse()
  return (out:gsub("^,", ""))
end

local function call(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, a, b = pcall(fn, ...)
  if ok then return a, b end
  return nil
end

-- "name-ruleset" for a character, the way ns:NoteCharacter keys them
local function charKey(who, rs)
  if not usable(who) then return nil end
  return who:lower():gsub("%s+", " ") .. "-" .. ns.Squash(rs or "")
end
ns.AccoladeKey = charKey
local function myKey() return charKey(ns.PlayerName(), ns.MyRuleset()) end

local function store(name)
  local db = ns.db
  if type(db) ~= "table" then return nil end
  if type(db[name]) ~= "table" then db[name] = {} end
  return db[name]
end

---------------------------------------------------------------------------
-- What the game says about this character
---------------------------------------------------------------------------
local TOTAL_DEATHS_STAT, DUELS_WON_STAT = 60, 319

local function duelsWon()
  return tonumber((call(GetStatistic, DUELS_WON_STAT)))
end

local function mountCount()
  local J = C_MountJournal
  if not (J and J.GetMountIDs and J.GetMountInfoByID) then return nil end
  local ids = call(J.GetMountIDs)
  if type(ids) ~= "table" then return nil end
  local n = 0
  for _, id in ipairs(ids) do
    local ok, _, _, _, _, _, _, _, _, _, _, collected = pcall(J.GetMountInfoByID, id)
    if ok and collected == true then n = n + 1 end
  end
  return n
end

-- Your level, while this character has never died. The game shows "--" for a
-- statistic that is still zero, and also for one a client doesn't have, so
-- "--" is only believed once this install has read a real death count from
-- the game on some character (db.deathStat). A death Friend Feed saw itself
-- (db.died) ends it for good.
local function deathless()
  local key = myKey()
  local died = store("died")
  if not (key and died) or died[key] then return nil end
  local raw = call(GetStatistic, TOTAL_DEATHS_STAT)
  local n = tonumber(raw)
  if n and n > 0 then
    ns.db.deathStat = true
    died[key] = true
    return nil
  end
  if n == 0 or (raw == "--" and ns.db.deathStat) then
    return tonumber((call(UnitLevel, "player")))
  end
  return nil
end

---------------------------------------------------------------------------
-- The accolades. jump: the most a number can rise between two looks and
-- still be announced; a bigger rise (the addon was off for a month, or the
-- game's count read 0 at login and then caught up) is granted quietly.
-- fresh: Friend Feed's own count, which starts at nothing, so there is no
-- history to grant quietly.
---------------------------------------------------------------------------
ns.ACCOLADES = {
  { id = "hk", name = "Slayer", icon = "Interface\\Icons\\INV_Sword_27",
    tiers = { 100, 500, 1000, 5000, 10000 }, jump = 25, unit = "honorable kills",
    about = "Honorable kills on this character.",
    desc = function(n) return ns.Commas(n) .. " honorable kills" end,
    value = function() return ns.HonorableKills and ns.HonorableKills() end },
  { id = "ram", name = "Rampage", icon = "Interface\\Icons\\Ability_Warrior_Rampage",
    tiers = { 3, 5, 10 }, fresh = true, unit = "kills in a row",
    about = "World PvP kills in a row, each within a minute of the last.",
    desc = function(n) return n .. " kill streak" end },
  { id = "du", name = "Duelist", icon = "Interface\\Icons\\Ability_Parry",
    tiers = { 10, 50, 100, 500 }, jump = 5, unit = "duels won",
    about = "Duels won on this character.",
    desc = function(n) return ns.Commas(n) .. " duels won" end,
    value = duelsWon },
  { id = "dl", name = "Deathless", icon = "Interface\\Icons\\Spell_Holy_GuardianSpirit",
    tiers = { 20, 40, 60 }, jump = 2, unit = "(level, without dying)",
    about = "Levels reached without ever dying.",
    desc = function(n) return "Level " .. n .. " without dying" end,
    value = deathless },
  { id = "mt", name = "Collector", icon = "Interface\\Icons\\Ability_Mount_RidingHorse",
    tiers = { 10, 25, 50 }, jump = 3, unit = "mounts",
    about = "Mounts collected.",
    desc = function(n) return n .. " mounts collected" end,
    value = mountCount },
}
local byId = {}
for i, def in ipairs(ns.ACCOLADES) do def.order = i; byId[def.id] = def end
function ns.AccoladeDef(id) return byId[id] end

-- the highest tier a number reaches (0 = none)
local function tierFor(def, value)
  local tier = 0
  for i, need in ipairs(def.tiers) do
    if value >= need then tier = i end
  end
  return tier
end
ns.AccoladeTier = tierFor

-- "Slayer II", coloured by tier
function ns.AccoladeName(def, tier, plain)
  local t = ns.TIERS[tier]
  if not (def and t) then return def and def.name or "an accolade" end
  if plain then return def.name .. " " .. t.name end
  return "|cff" .. t.hex .. def.name .. " " .. t.name .. "|r"
end

---------------------------------------------------------------------------
-- Mine: FriendFeedDB.accolades["name-ruleset"][id] = { tier, v, t }
---------------------------------------------------------------------------
function ns:MyAccolades()
  local all, key = store("accolades"), myKey()
  if not (all and key) then return nil end
  if type(all[key]) ~= "table" then all[key] = {} end
  return all[key]
end

local function changed(tierChanged)
  ns:Fire("ACCOLADES_CHANGED")
  if tierChanged and ns.Sync and ns.Sync.QueueBadges then ns.Sync:QueueBadges(true) end
end

-- A number for one accolade. Returns true when a tier was announced.
function ns:CheckAccolade(id, value)
  local def = byId[id]
  value = tonumber(value)
  if not (def and value and value == value and value >= 0 and value <= 2147483647) then return false end
  value = math.floor(value)
  local mine = ns:MyAccolades()
  if not mine then return false end
  local rec = mine[id]
  local tier = tierFor(def, value)
  local now = ns.Now()
  if type(rec) ~= "table" then
    if def.fresh then
      rec = { tier = 0, v = 0 }
      mine[id] = rec
    else
      -- the first look on this character: what's already earned is granted quietly
      mine[id] = { tier = tier, v = value, t = tier > 0 and now or nil }
      changed(tier > 0)
      return false
    end
  end
  local before = tonumber(rec.v) or 0
  if value <= before then return false end
  rec.v = value
  if tier <= (tonumber(rec.tier) or 0) then
    changed(false)
    return false
  end
  local announce = def.fresh or (value - before) <= (def.jump or 1)
  rec.tier, rec.t = tier, now
  if announce then ns:RecordSelf("acc", def.tiers[tier], tier, def.id, def.desc(def.tiers[tier])) end
  changed(true)
  return announce and true or false
end

local function look(def)
  if not def.value then return end
  local ok, v = pcall(def.value)
  if ok and v ~= nil then ns:CheckAccolade(def.id, v) end
end

-- Read every number the game keeps (login, and after things that move them)
function ns:CheckAccolades(id)
  if not ns.db then return end
  if id then
    if byId[id] then look(byId[id]) end
    return
  end
  for _, def in ipairs(ns.ACCOLADES) do look(def) end
end
ns.CheckAccolades = ns.Perf.Wrap("accolades", ns.CheckAccolades)

-- Looks are tied to the milestones that move the numbers, a moment later so
-- the game has counted them
local record = ns.RecordSelf
function ns:RecordSelf(k, v, q, ...)
  record(self, k, v, q, ...)
  if not (C_Timer and C_Timer.After) then return end
  if k == "kill" then
    -- Rampage counts the streak (a kill's q), which is never less than the fight
    local n = math.max(tonumber(v) or 0, tonumber(q) or 0)
    C_Timer.After(1, function() ns:CheckAccolade("ram", n); ns:CheckAccolades("hk") end)
  elseif k == "duel" then
    C_Timer.After(1, function() ns:CheckAccolades("du") end)
  elseif k == "level" then
    C_Timer.After(1, function() ns:CheckAccolades("dl") end)
  elseif k == "mount" then
    C_Timer.After(1, function() ns:CheckAccolades("mt") end)
  end
end

-- a death ends Deathless for this character, shared or not
local watch = CreateFrame("Frame")
pcall(watch.RegisterEvent, watch, "PLAYER_DEAD")
watch:SetScript("OnEvent", function()
  local died, key = store("died"), myKey()
  if died and key then died[key] = true end
end)

ns:On("LOGIN", function()
  if C_Timer and C_Timer.After then
    C_Timer.After(7, function() ns:CheckAccolades() end)
    -- friends who are online hear what this character has
    C_Timer.After(12, function()
      if ns.Sync and ns.Sync.QueueBadges then ns.Sync:QueueBadges(false) end
    end)
  end
end)

---------------------------------------------------------------------------
-- Other people's: FriendFeedDB.badges[friend id]["name-ruleset"] =
-- { t, list = { [id] = { tier, v } } }. The friend id and the character come
-- from the channel, never from the message; the tier is worked out here from
-- the number, so a message can't claim a tier its number doesn't reach.
---------------------------------------------------------------------------
local MAX_BADGE_PEOPLE = 600
local MAX_BADGE_CHARS = 20

-- "B<TAB>hk:2:734,du:1:12" for this character, or nil when there is nothing yet
function ns:BadgeMessage()
  local mine = ns:MyAccolades()
  if not mine then return nil end
  local parts = {}
  for _, def in ipairs(ns.ACCOLADES) do
    local rec = mine[def.id]
    if type(rec) == "table" and (tonumber(rec.tier) or 0) > 0 then
      parts[#parts + 1] = def.id .. ":" .. rec.tier .. ":" .. math.floor(tonumber(rec.v) or 0)
    end
  end
  if #parts == 0 then return nil end
  return "B\t" .. table.concat(parts, ",")
end

local function prune(all)
  local n = 0
  for _ in pairs(all) do n = n + 1 end
  if n <= MAX_BADGE_PEOPLE then return end
  local ages = {}
  for id, chars in pairs(all) do
    local newest = 0
    for _, c in pairs(chars) do newest = math.max(newest, tonumber(c.t) or 0) end
    ages[#ages + 1] = { id = id, t = newest }
  end
  table.sort(ages, function(a, b) return a.t < b.t end)
  for i = 1, n - (MAX_BADGE_PEOPLE - 100) do all[ages[i].id] = nil end
end

local function entry(id, who, rs, make)
  local all, key = store("badges"), charKey(who, rs)
  if not (all and key and usable(id)) then return nil end
  local chars = all[id]
  if type(chars) ~= "table" then
    if not make then return nil end
    chars = {}
    all[id] = chars
    prune(all)
  end
  local e = chars[key]
  if type(e) ~= "table" or type(e.list) ~= "table" then
    if not make then return nil end
    local n = 0
    for _ in pairs(chars) do n = n + 1 end
    if n >= MAX_BADGE_CHARS then return nil end
    e = { t = ns.Now(), list = {} }
    chars[key] = e
  end
  return e
end

-- a friend's "B" message: everything their current character has
function ns:SetBadges(from, text)
  if type(from) ~= "table" or type(text) ~= "string" or from.id == ns.SelfID() then return false end
  local list, n = {}, 0
  for id, _, v in text:gmatch("(%a+):(%d+):(%d+)") do
    local def = byId[id]
    v = tonumber(v)
    if def and v and v == v and v <= 2147483647 and not list[id] then
      local tier = tierFor(def, v)
      if tier > 0 then
        list[id] = { tier = tier, v = math.floor(v) }
        n = n + 1
        if n >= 12 then break end
      end
    end
  end
  local e = entry(from.id, from.who, from.rs, n > 0)
  if not e then return false end
  e.list, e.t = list, ns.Now()
  ns:Fire("BADGES_CHANGED", from.id)
  return true
end

-- a friend's accolade milestone says one of them too (and reaches people a
-- "B" message didn't, like the app's inbox one day)
ns:On("EVENT_ADDED", function(ev)
  if not (ev and ev.k == "acc" and not ev.self and not ev.demo) then return end
  local def = byId[ev.n or ""]
  local v = tonumber(ev.v) or 0
  local tier = def and tierFor(def, v) or 0
  if tier < 1 then return end
  local e = entry(ev.id, ev.who, ev.rs, true)
  if not e then return end
  local have = e.list[def.id]
  if not have or (tonumber(have.v) or 0) < v then
    e.list[def.id] = { tier = tier, v = v }
    e.t = ns.Now()
    ns:Fire("BADGES_CHANGED", ev.id)
  end
end)

-- everything a character has: { [id] = { tier, v } } or nil.
-- who: a milestone or { id, who, rs, self }
function ns:AccoladesOf(who)
  if type(who) ~= "table" or not ns.db then return nil end
  if who.self or who.id == ns.SelfID() then
    local all, key = store("accolades"), charKey(who.who, who.rs)
    return all and key and all[key] or nil
  end
  local e = entry(who.id, who.who, who.rs, false)
  return e and e.list or nil
end

-- the one to show next to a name: the highest tier, the earlier accolade on a tie
function ns:TopAccolade(who)
  local list = ns:AccoladesOf(who)
  if type(list) ~= "table" then return nil end
  local best, bestTier
  for _, def in ipairs(ns.ACCOLADES) do
    local rec = list[def.id]
    local tier = type(rec) == "table" and tonumber(rec.tier) or 0
    if tier > 0 and tier <= #def.tiers and (not bestTier or tier > bestTier) then best, bestTier = def, tier end
  end
  return best, bestTier
end

-- The badge a row shows for its character, if any: the accolade, its tier and
-- the number behind it (0.9.18: also what the badge's tooltip is made from)
function ns:BadgeOf(who)
  if type(who) ~= "table" or who.demo then return nil end
  if ns.db and ns.db.settings.badges == false then return nil end
  local def, tier = ns:TopAccolade(who)
  if not def then return nil end
  local list = ns:AccoladesOf(who)
  local rec = type(list) == "table" and list[def.id] or nil
  return def, tier, type(rec) == "table" and tonumber(rec.v) or nil
end

-- The room a badge takes at the start of a row's text: a transparent inline
-- texture. The icon itself is a real texture laid over it (row.badge in
-- UI.lua), because only a real texture can be drawn in grey and then
-- coloured by tier, and hovered.
function ns:BadgeText(who, size)
  local def = ns:BadgeOf(who)
  if not def then return "" end
  size = size or 13
  return ("|T%s:%d:%d|t "):format(ns.BLANK, size, size)
end
